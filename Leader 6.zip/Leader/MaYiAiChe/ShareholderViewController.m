//
//  Shareholder ViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "ShareholderViewController.h"
#import "ShareTableViewCell.h"
#import "Madeshare1ViewController.h"
#import "ShareinputViewController.h"
#import "ShareViewController.h"
#import "InshareViewController.h"
#import "SharecutViewController.h"
#import "CashViewController.h"
#import "ShareoutViewController.h"

@interface ShareholderViewController ()<UITableViewDelegate,UITableViewDataSource,CellCustomDelegate>
{
    UIView *_mynavigationBar;
    UIButton * _backLabel;
    UILabel * _titleLabel;
    UITextField * menuTextField;
    UIView * _headView;
    UITableView * _listtableView;
}
@end

@implementation ShareholderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor lightGrayColor];
    self.navigationController.navigationBar.hidden = YES;
    //自定义navigationbar
    _mynavigationBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 64)];
    _mynavigationBar.backgroundColor = [UIColor greenColor];
    [self.view addSubview:_mynavigationBar];
    //返回item
    _backLabel = [[UIButton alloc]initWithFrame:CGRectMake(5, 25, 30, 30)];
    _backLabel.backgroundColor = [UIColor clearColor];
    [_backLabel setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [_backLabel addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigationBar addSubview:_backLabel];
    
    //title
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-100, 22, 200, 40)];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text =@"成为股东";
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.font = [UIFont systemFontOfSize:25];
    [_mynavigationBar addSubview:_titleLabel];

    [self creadteHaedView];
    [self creadtelistTableView];
    
    // Do any additional setup after loading the view.
}
//返回上一页
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}

//创建headview
-(void)creadteHaedView
{
    _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, 200)];
    _headView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_headView];
    
    NSArray * imageArray = [NSArray arrayWithObjects:@"1",@"2",@"3", nil];
    NSArray * titleArray = [NSArray arrayWithObjects:@"成为股东",@"股东增资",@"分红", nil];
    for (int i = 0; i<3; i++) {
        UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(self.view.frame.size.width/3*i+30, 40, 80, 80)];
        NSString * title =[imageArray objectAtIndex:i];
        btn.backgroundColor = [UIColor redColor];
        btn.layer.masksToBounds = YES;
        btn.layer.cornerRadius = 40;
        [btn setImage:[UIImage imageNamed:title]forState:UIControlStateNormal];
        btn.tag =100+i;
        [btn addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
        [_headView addSubview:btn];
        
        UILabel * headLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/3*i+30, 130, 80, 30)];
        headLabel.backgroundColor = [UIColor clearColor];
        headLabel.textAlignment = NSTextAlignmentCenter;
        headLabel.textColor = [UIColor blackColor];
        headLabel.text = [titleArray objectAtIndex:i];
        [_headView addSubview:headLabel];
        
        
        
    }
}
//点击事件
-(void)btnclick:(UIButton *)btn
{
    switch (btn.tag - 100) {
        case 0:
        {
            self.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:[MadeShare1ViewController new] animated:YES];
            self.hidesBottomBarWhenPushed = NO;
        }
            break;
        case 1:
        {
            self.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:[ShareinputViewController new] animated:YES];
            self.hidesBottomBarWhenPushed = NO;
        }
            break;
        case 2 :
        {
           
            [self.navigationController pushViewController:[ShareViewController new] animated:YES];
           
        }
            break;
        default:
            break;
    }
}
//创建tableview
-(void)creadtelistTableView
{
    _listtableView  = [[UITableView alloc]initWithFrame:CGRectMake(20, 300, self.view.frame.size.width-40, 200)];
    _listtableView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_listtableView];
    _listtableView.delegate = self;
    _listtableView.dataSource = self;
    _listtableView.bounces = NO;
    _listtableView.showsVerticalScrollIndicator = NO;
    
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma  mark -- 数据源
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cellId = @"cellCusId";
    ShareTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[ShareTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    NSString *headLabel;
    NSString * nameLabel;
    UIImage * headImageView;
    NSArray * headArray = [NSArray arrayWithObjects:@"已入股", @"股东减资", @"分红提现", @"股东撤资", nil];
    NSArray * imageArray = [NSArray arrayWithObjects:@"",@"",@"",@"", nil];
    for (int i =0; i<4; i++) {
        if (indexPath.row == 0) {
            headLabel = [headArray objectAtIndex:0];
            headImageView = [UIImage imageNamed:[imageArray objectAtIndex:0]];
             nameLabel = @"天天飞车4s店";
        }else if (indexPath.row ==1)
        {
            headLabel = [headArray objectAtIndex:1];
            headImageView = [UIImage imageNamed:[imageArray objectAtIndex:1]];
        }else if (indexPath.row ==2)
        {
            headLabel = [headArray objectAtIndex:2];
            headImageView = [UIImage imageNamed:[imageArray objectAtIndex:2]];
        }else if (indexPath.row ==3)
        {
            headLabel = [headArray objectAtIndex:3];
            headImageView = [UIImage imageNamed:[imageArray objectAtIndex:3]];
        }
       
    }
    if (indexPath.row == 0) {
       
    }
    int showstatus;
    if (indexPath.row == 0) {
        showstatus =0;
    }else{
        showstatus =1;
    }
    [cell reloadViewWithName:headLabel headImageView:headImageView nameLabel:nameLabel showStatus:showstatus];
    return cell;
}
//设置每行的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
//监听页面跳转
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:[InshareViewController new] animated:YES];
        self.hidesBottomBarWhenPushed = NO;
    }else if (indexPath.row == 1)
    {
        [self.navigationController pushViewController:[SharecutViewController new] animated:YES];
    }else if (indexPath.row == 2)
    {
        [self.navigationController pushViewController:[CashViewController new] animated:YES];
    }else
    {
        [self.navigationController pushViewController:[ShareoutViewController new] animated:YES];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
