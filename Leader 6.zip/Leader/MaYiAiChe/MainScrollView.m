//
//  MainScrollView.m
//  MaYiAiChe
//
//  Created by xc on 17/1/16.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "MainScrollView.h"
#import "StoreTableViewCell.h"
#import "AFNetworking.h"
#import "HomeModel.h"
#import "FinishCommTableViewCell.h"
#import "FinishServiceTableViewCell.h"
#import "uiwebViewControl.h"
#import "DataCenter.h"
#import "ScheduleModel.h"


@interface MainScrollView ()<cellCusDelegate,MyCellDelegate>
//@property (nonatomic,strong) NSMutableArray * dataArray;
//@property (nonatomic,strong) NSMutableArray * eDataArray;

@property (strong,nonatomic)   NSMutableArray * eDataArray;

@property (nonatomic,strong) UITableView * tableView;
@property (nonatomic,strong) UITableView * etableView;


@property (nonatomic,strong) DataCenter * data;     //  单利

@end


@implementation MainScrollView
{
    UIView * _topView;
    UIView * _selectedView;
    UIButton * _selectedBtn;
    UIView * _headView;
    UILabel * _titleLabel;
    UIImageView * _headImageView;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
//        [self initUI];
        _data      =  [DataCenter shareDataCenter];
//        _dataArray = [NSMutableArray new];
        _eDataArray = [NSMutableArray new];
//        [self createAFNetworking];          //  数据源
    }
    return self ;
}
-(void)initUI
{
    _topView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, kRelativeHeight(40))];
    [_topView setBackgroundColor:[UIColor colorWithRed:230/256.0 green:230/256.0 blue:230/256.0 alpha:1]];
    [self addSubview:_topView];
    NSArray *array = [[NSArray alloc]initWithObjects:@"已完成服务",@"已完成商品", nil];
    float  width = ScreenWidth/2;
     for (int i =0; i<array.count; i++) {
        NSString * title = [array objectAtIndex:i];
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(width*i, kRelativeHeight(5), width, kRelativeHeight(30));
        [btn setTitle:title forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor colorWithRed: 94/256.0 green:207/256.0 blue:80/256.0 alpha:1] forState:UIControlStateSelected];
        [btn addTarget:self action:@selector(topbtnclick:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = 100+i;
        [_topView addSubview:btn];
        if (i == 0) {
            _selectedBtn = btn;
            _selectedBtn.selected = YES;
        }
    }
    
    _bigScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(50), [UIScreen mainScreen].bounds.size.width, kRelativeHeight(ScreenHeight-250))];
    [self addSubview:_bigScrollView];
    _bigScrollView.backgroundColor = [UIColor lightGrayColor];
    _bigScrollView.contentSize = CGSizeMake(ScreenWidth*2, 0);
    _bigScrollView.pagingEnabled = YES;
    _bigScrollView.scrollEnabled = NO;
    //    _bigSrollView.directionalLockEnabled = YES;
    _bigScrollView.bounces = NO;
    _bigScrollView.delegate = self;
    
    for (int i = 0 ; i<2; i++) {
        UITableView* tableView = [[UITableView alloc]initWithFrame:CGRectMake(ScreenWidth*i, 0, ScreenWidth,_bigScrollView.frame.size.height) style:UITableViewStylePlain];
        tableView.tag = i+200;
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.tableFooterView = [UIView new];
        tableView.showsHorizontalScrollIndicator = NO;
        [_bigScrollView addSubview:tableView];
        if (i == 0) {
            self.tableView = tableView;
        }else{
            self.etableView = tableView;
        }
        
    }
    
}


#pragma  mark -- scrollViewDelegate
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if ([scrollView isEqual:_bigScrollView]) {
        int contentoffset = scrollView.contentOffset.x;
        int numOfTable = contentoffset/ScreenWidth;
        UIButton * btn  = (UIButton *)[self viewWithTag:100+numOfTable];
        [self topbtnclick:btn];
    }
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.contentOffset.y<0) {
        return;
    }
}
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if (scrollView.contentOffset.y<0) {
        return;
    }
}
-(void)topbtnclick:(UIButton *)sender
{
    if (_selectedBtn == sender) {
        return;
    }
    _selectedBtn.selected = NO;
    _selectedBtn = sender;
    _selectedBtn.selected = YES;
    float width = 100;
    [_bigScrollView setContentOffset:CGPointMake(ScreenWidth*(sender.tag-100), 0) animated:YES];
    [UIView animateWithDuration:0.3 animations:^{
        _selectedView.frame = CGRectMake(width*(sender.tag-100), 80-1, width, 1);
        
    }];
}

#pragma mark -- tableviewdelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    switch (tableView.tag -200) {
        case 0:
        {
            return 3;
        }
            break;
        case 1:
        {
            return 3;
        }
            
        default:
            return 0;
            break;
    }
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag == 200) {
        return self.dataArray.count;
    }else
    {
        return self.dataArray.count;
    }
    
}

#pragma mark=================== cell 回调
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (tableView.tag - 200) {
        case 0:
        {
            static NSString * cellId = @"cellCusID";
            FinishServiceTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[FinishServiceTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
            }
            cell.model = _dataArray[indexPath.row];
            cell.selectionStyle  = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
        case 1:
        {
            static NSString * cellId = @"cellCusID";
            FinishCommTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[FinishCommTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
            }
            return cell;
            
        }
            
        default:
            return 0;
            break;
    }
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (tableView.tag-200) {
        case 0:
            return 180;
            break;
        case 1:
            return 300;
            break;
        default:
            return 0;
            break;
    }
    
}

#pragma mark=================== 选中cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [_tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
    
}

#pragma mark===================  数据请求
-(void)createAFNetworking{
    
    if (_data.UIDs.length == 0) {
        NSLog(@"登录失败 ");
    }else{
        
        //            //    、获取时间
        NSDate * date = [NSDate date];
        NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"M/d/Y"];
        NSString *dateString = [dateFormatter stringFromDate:date];
        
        
        NSDictionary * dic  = @{@"s_time":dateString,@"s_userid":_data.UIDs};
        AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        
        // NSString * urlString = @"http://106.15.0.128/working/index.php/Admin/ApiS/s_rili_sorder";
        NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_rili_sorder";
        
        [manager POST:urlString parameters:dic progress:^(NSProgress * _Nonnull uploadProgress) {
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            //        NSString * str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
            //        NSLog(@"%@",str);
            NSDictionary * array = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            for (NSDictionary * dic  in array) {
                ScheduleModel *  model  = [[ScheduleModel alloc]initWithDic:dic];
                [_dataArray addObject:model];
            }
            [_tableView reloadData];
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"%@",error);
        }];
    }
}



@end
