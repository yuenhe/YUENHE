//
//  SonServiceViewController.h
//  MaYiAiChe
//
//  Created by xc on 17/1/5.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SonServiceViewController : UIViewController

@property(nonatomic,strong)NSString *  orderStr;                 // 订单号
@property(nonatomic,strong)NSString *  headImageStr;         // 图片
@property(nonatomic,strong)NSString *  fuwuStr;                  // 上门服务
@property(nonatomic,strong)NSString *  titleStr;                    // 标题
@property(nonatomic,strong)NSString *  phoneStr;                // 电话
@property(nonatomic,strong)NSString *  addressStr;              // 地址
@property(nonatomic,strong)NSString *  lat;                           // 纬度
@property(nonatomic,strong)NSString *  lng;                          // 经度

@property(nonatomic,strong)NSString * status;                      // 判断是否显示导航 服务 状态 3
@property(nonatomic,strong)NSArray  * before_ImageArry;    // 服务前 图片
@property(nonatomic,strong)NSArray  * after_ImageArry;       // 服务后 图片

@end
