//
//  HomeModel.m
//  MaYiAiChe
//
//  Created by xc on 17/1/16.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "HomeModel.h"

@implementation HomeModel

@end
