//
//  EmployeeModel.h
//  MaYiAiChe
//
//  Created by xc on 17/1/17.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EmployeeModel : NSObject

@property (nonatomic,copy) NSString * picUrl;
@property (nonatomic,copy) NSString * title;
@property (nonatomic,copy) NSString * time;

@end
