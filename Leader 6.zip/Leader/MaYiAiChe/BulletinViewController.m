//
//  BulletinViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "BulletinViewController.h"
//#import "HeadScrollView.h"
//#import "FootScrollView.h"
#import "MainScrollView.h"
#import "MJRefresh.h"
#import "HomeModel.h"
#import "AFNetworking.h"
#import "EmployeeModel.h"
#import "ImageScrollView.h"
#import "uiwebViewControl.h"
#import "WebImageControl.h"
#import "WebView.h"
#import "ImageScrollView.h"



@interface BulletinViewController ()<UITableViewDelegate,UITableViewDataSource,MyScrollViewDelegate>
{
    NSMutableArray * NetImageArray;
    NSMutableArray  * footImageArray;
    NSMutableArray * dataArray;
    NSMutableArray * eDataArray;
    UIScrollView * _bigSrollView;
    UIView *  _topView;
    UIView *  _headView;
    UIView * _selectedView;
    UIButton * _selectedBtn;
    UILabel * _titleLabel;
    UIImageView * _headImageView;
    UITableView * _listTableView;
    MainScrollView * _mainscrollView;
    
}
@property (nonatomic,strong) ImageScrollView * headScrollView;//头轮播图
@property (nonatomic,strong) ImageScrollView * footScrollView;//脚轮播图
@property (nonatomic,strong) UIScrollView * mainScrollView;//底层view
@property (nonatomic,strong) UITableView * tableView;//左tableview
@property (nonatomic,strong) UITableView * etableView;//右tablewview
@end

#define c_width self.view.frame.size.width
#define c_heigth self.view.frame.size.heigth
@implementation BulletinViewController
{
    
    UIView * _titleView;
    UIView * _footView;
    UIView * _weatherView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];
    self.navigationController.navigationBar.hidden = YES;
    //[self createNetworking];
//    [self createtitleView];
//    [self createFootView];

    
    NetImageArray = [NSMutableArray new];
    footImageArray = [NSMutableArray new];
    [self initUi];
//    [self initHeadView];
//    [self initFootView];
//    //主视图
//    _listTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
//    //    _listTableView.tag =  101;
//    _listTableView.delegate = self;
//    _listTableView.dataSource = self;
//    _listTableView.bounces = NO;
//    _listTableView.showsVerticalScrollIndicator = NO;
//   
//    [self.view addSubview:_listTableView];
////    [_listTableView reloadData];
//    //头视图
//    _titleView  = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, kRelativeHeight(300))];
//    _titleView.backgroundColor = [UIColor clearColor];
//    _listTableView.tableHeaderView = _titleView;
//    //脚视图
//    _footView = [[UIView alloc]initWithFrame:CGRectMake(0, ScreenHeight-kRelativeHeight(44), ScreenWidth, kRelativeHeight(300))];
//    _footView.backgroundColor = [UIColor clearColor];
//    _listTableView.tableFooterView = _footView;
    

    // Do any additional setup after loading the view.
}
-(void)initUi
{
    _mainScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    _mainScrollView.backgroundColor = [UIColor whiteColor];
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, kRelativeHeight(639+49));
    _mainScrollView.pagingEnabled = NO;
    _mainScrollView.bounces = YES;
    _mainScrollView.showsVerticalScrollIndicator = NO;
    _mainScrollView.scrollEnabled = YES;
    _mainScrollView.showsHorizontalScrollIndicator = NO;
    _mainScrollView.delegate = self;
    [self.view addSubview:_mainScrollView];
    //创建天气view
    UIView * weatherView = [[UIView alloc]initWithFrame:CGRectMake(0, 0,ScreenWidth , kRelativeHeight(80))];
    weatherView.backgroundColor = [UIColor greenColor];
//    [_mainScrollView addSubview:weatherView];
    
//    [self initmain];
    [self createScrollview];
 }

#pragma mark=================== lunbo
-(void)createScrollview{
    
    UIView * scrollview = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, kRelativeHeight(220))];
    scrollview.backgroundColor = [UIColor clearColor];
     [_mainScrollView addSubview:scrollview];
    
    NSArray * array = @[@"http://106.15.0.128/working/Public/Uploads/image/2017-03-19/58ce2fcb1dff3.jpg",@"http://106.15.0.128/working/Public/Uploads/image/2017-03-19/58ce2fee4e9f7.jpg",@"http://106.15.0.128/working/Public/Uploads/image/2017-03-19/58ce35529f0c3.jpg"];
    
    //创建头轮播图
    _headScrollView= [[ImageScrollView alloc]initWithFrame:CGRectMake(0,0,ScreenWidth,kRelativeHeight(220))];
    _headScrollView.backgroundColor = [UIColor grayColor];
    _headScrollView.pics = array;
    [_headScrollView returnIndex:^(NSInteger index) {
        NSLog(@"%ld",(long)index);
        //        [self.navigationController pushViewController:[WebImageControl new] animated:YES];
    }];
    [_headScrollView reloadView];
    [scrollview addSubview:_headScrollView];

    UIImageView * image  = [[UIImageView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(scrollview.frame)+10, ScreenWidth, 200)];
    image.userInteractionEnabled = YES;
    image.image = [UIImage imageNamed:@"首页.jpg"];
    [_mainScrollView addSubview:image];

    
    UIImageView * image2  = [[UIImageView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(image.frame)+5, ScreenWidth, 200)];
    image2.userInteractionEnabled = YES;
    image2.image = [UIImage imageNamed:@"首页2.jpg"];
    [_mainScrollView addSubview:image2];

    
    
    
}




-(void)initmain
{
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(310), ScreenWidth, kRelativeHeight(480))];
    [_mainScrollView addSubview:view];
    view.backgroundColor = [UIColor clearColor];
    
    UIView * headview = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, kRelativeHeight(40))];
    [view addSubview:headview];
    headview.backgroundColor = [UIColor greenColor];
    
    UILabel * titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(([UIScreen mainScreen].bounds.size.width)/2-kRelativeWidth(100), kRelativeHeight(5), kRelativeWidth(200), kRelativeHeight(30))];
    titleLabel.text = @"门店公告";
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [UIColor blackColor];
    [headview addSubview:titleLabel];
    
    UIImageView * headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(([UIScreen mainScreen].bounds.size.width/2-kRelativeWidth(80)), kRelativeHeight(5), kRelativeWidth(30), kRelativeHeight(30))];
    headImageView.backgroundColor = [UIColor whiteColor];
    headImageView.image = [UIImage imageNamed:@""];
    [headview addSubview:headImageView];
    
    _topView = [[UIView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(40), [UIScreen mainScreen].bounds.size.width, kRelativeHeight(40))];
    [_topView setBackgroundColor:[UIColor whiteColor]];
    [view addSubview:_topView];
    NSArray * array = [[NSArray alloc]initWithObjects:@"门店公告",@"员工奖惩", nil];
    float  width = 100;
    _selectedView = [[UIView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(78), width, kRelativeHeight(1))];
    _selectedView.backgroundColor = [UIColor greenColor];
    [view addSubview:_selectedView];
    for (int i =0; i<array.count; i++) {
        NSString * title = [array objectAtIndex:i];
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(width*i, kRelativeHeight(5), width, kRelativeHeight(35));
        [btn setTitle:title forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor greenColor] forState:UIControlStateSelected];
        [btn addTarget:self action:@selector(topbtnclick:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = 100+i;
        [_topView addSubview:btn];
        if (i == 0) {
            _selectedBtn = btn;
            _selectedBtn.selected = YES;
        }
    }
    
    _bigSrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(80), [UIScreen mainScreen].bounds.size.width, kRelativeHeight(400))];
    [view addSubview:_bigSrollView];
    _bigSrollView.backgroundColor = [UIColor whiteColor];
    _bigSrollView.contentSize = CGSizeMake(ScreenWidth*2, 0);
    _bigSrollView.pagingEnabled = YES;
    _bigSrollView.scrollEnabled = NO;
    //    _bigSrollView.directionalLockEnabled = YES;
    _bigSrollView.bounces = NO;
    _bigSrollView.delegate = self;
    
    for (int i = 0 ; i<2; i++) {
        UITableView* tableView = [[UITableView alloc]initWithFrame:CGRectMake(ScreenWidth*i, 0, ScreenWidth,_bigSrollView.frame.size.height) style:UITableViewStylePlain];
        tableView.tag = i+200;
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.showsHorizontalScrollIndicator = NO;
        [_bigSrollView addSubview:tableView];
        if (i == 0) {
            self.tableView = tableView;
            tableView.backgroundColor = [UIColor greenColor];
        }else{
            self.etableView = tableView;
            tableView.backgroundColor = [UIColor redColor];
        }
        
    }
}
-(void)initHeadView
{
    //    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, 80, ScreenWidth, 220)];
    //    view.backgroundColor = [UIColor whiteColor];
    //    [_mainScrollView addSubview:view];
    
    UIScrollView * scrollview = [[UIScrollView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(80), ScreenWidth, kRelativeHeight(220))];
    scrollview.backgroundColor = [UIColor clearColor];
    scrollview.contentSize = CGSizeMake(ScreenWidth, kRelativeHeight(220));
    [_mainScrollView addSubview:scrollview];
    
    NSArray * array = @[@"http://106.15.0.128/working/Public/Uploads/image/2017-03-19/58ce2fcb1dff3.jpg",@"http://106.15.0.128/working/Public/Uploads/image/2017-03-19/58ce2fee4e9f7.jpg",@"http://106.15.0.128/working/Public/Uploads/image/2017-03-19/58ce35529f0c3.jpg"];
    //创建头轮播图
    _headScrollView= [[ImageScrollView alloc]initWithFrame:CGRectMake(0,0,ScreenWidth,kRelativeHeight(220))];
    _headScrollView.backgroundColor = [UIColor grayColor];
    _headScrollView.pics = array;
    [_headScrollView returnIndex:^(NSInteger index) {
        NSLog(@"%ld",(long)index);
        //        [self.navigationController pushViewController:[WebImageControl new] animated:YES];
    }];
    [_headScrollView reloadView];
    [scrollview addSubview:_headScrollView];
    
}
-(void)initFootView{
    //公告
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(800), ScreenWidth, kRelativeHeight(40))];
    view.backgroundColor = [UIColor greenColor];
    [_mainScrollView addSubview:view];
    
    UILabel * headLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, kRelativeHeight(40))];
    headLabel.text = @"App公告";
    headLabel.textAlignment = NSTextAlignmentCenter;
    [view addSubview:headLabel];
    headLabel.backgroundColor = [UIColor greenColor];
    UIImageView * headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth/2-kRelativeWidth(80), kRelativeHeight(5) , kRelativeWidth(30), kRelativeHeight(30))];
    [view addSubview:headImageView];
    headImageView.backgroundColor = [UIColor redColor];
    headImageView.image = [UIImage imageNamed:@""];
    
    
    NSArray * array = @[@"http://106.15.0.128/working/Public/Uploads/image/2017-03-19/58ce2fcb1dff3.jpg",@"http://106.15.0.128/working/Public/Uploads/image/2017-03-19/58ce2fee4e9f7.jpg",@"http://106.15.0.128/working/Public/Uploads/image/2017-03-19/58ce35529f0c3.jpg"];
    UIScrollView * scrollview = [[UIScrollView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(840), ScreenWidth, kRelativeHeight(220))];
    scrollview.backgroundColor = [UIColor clearColor];
    scrollview.contentSize = CGSizeMake(ScreenWidth, kRelativeHeight(220));
    [_mainScrollView addSubview:scrollview];
    //创建脚轮播图
    _headScrollView= [[ImageScrollView alloc]initWithFrame:CGRectMake(0,0,ScreenWidth,kRelativeHeight(220))];
    _headScrollView.backgroundColor = [UIColor grayColor];
    _headScrollView.pics = array;
    [_headScrollView returnIndex:^(NSInteger index) {
        NSLog(@"%ld",(long)index);
        //[self.navigationController pushViewController:[WebImageControl new] animated:YES];
    }];
    [_headScrollView reloadView];
//    [scrollview addSubview:_headScrollView];
}
#pragma  mark -- scrollViewDelegate
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if ([scrollView isEqual:_bigSrollView]) {
        int contentoffset = scrollView.contentOffset.x;
        int numOfTable = contentoffset/ScreenWidth;
        UIButton * btn  = (UIButton *)[self.view viewWithTag:100+numOfTable];
        [self topbtnclick:btn];
    }
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.contentOffset.y<0) {
        return;
    }
}
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if (scrollView.contentOffset.y<0) {
        return;
    }
}
-(void)topbtnclick:(UIButton *)sender
{
    if (_selectedBtn == sender) {
        return;
    }
    _selectedBtn.selected = NO;
    _selectedBtn = sender;
    _selectedBtn.selected = YES;
    float width = 100;
    [_bigSrollView setContentOffset:CGPointMake(ScreenWidth*(sender.tag-100), 0) animated:YES];
    [UIView animateWithDuration:0.3 animations:^{
        _selectedView.frame = CGRectMake(width*(sender.tag-100), 80-1, width, 1);
        
    }];
}

#pragma mark -- tableviewdelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    static NSString * cellId = @"cellCusId";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    return cell;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

//- (void)didReceiveMemoryWarning {
//    [super didReceiveMemoryWarning];
//    // Dispose of any resources that can be recreated.
//}
////-(void)createNetworking
////{
////    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
////    NSString * usename = [userDefaults objectForKey:@"c_name"];
////    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
//////    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/html", nil];
//////    manager.responseSerializer = []
////    NSDictionary * dic = @{@"s_username":usename,@"type":@"json"};
//////    NSMutableDictionary * dic = [NSMutableDictionary new];
//////    [dic setObject:@"user" forKey:@"s_username"];
//////    [dic setObject:@"json" forKey:@"tpye"];
//////    [dic setObject:@"10" forKey:@"pagesize"];
//////    [dic setObject:@"0" forKey:@"pageIndex"];
//////    [dic setObject:@"1" forKey:@"sessionKey"];
//////    [dic setObject:@"2" forKey:@"rtype"];
////    NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_notice";
////    [manager POST:urlString parameters:dic progress:^(NSProgress * _Nonnull uploadProgress) {
////        
////    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
////        NSLog(@"－－1－－－－%@",responseObject);
//////        NSString * str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
//////        NSLog(@"%@",str);
////        
////        NSArray * array1 = [responseObject objectForKey:@"banner_top"];
////        for (NSDictionary * dic in array1) {
////            NSString * pic1 = dic[@"notice_pic"];
////            [NetImageArray addObject:pic1];
////            
////        }
////        NSArray * array2 = [responseObject objectForKey:@"app_notice"];
////        for (NSDictionary * dic in array2) {
////            NSString * pic1 = dic[@"notice_pic"];
////            [footImageArray addObject:pic1];
////        }
////        
////        [self createtitleView];
////        [self createFootView];
////        [_listTableView reloadData];
////    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
////        NSLog(@"%@",error);
////    }];
////}
//
//-(void)createtitleView
//{
//    
//    _weatherView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth,kRelativeHeight(80))];
//    [_titleView addSubview:_weatherView];
//    _weatherView.backgroundColor = [UIColor greenColor];
//   
//
////    HeadScrollView * headView = [[HeadScrollView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(80), ScreenWidth , kRelativeHeight(220))];
////    
////    headView.AutoScrollDelay = 3;
////    headView.netDelagate = self;
////    headView.backgroundColor = [UIColor lightGrayColor];
////    [_titleView addSubview:headView];
//     _imageScrollView= [[ImageScrollView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(80), ScreenWidth, kRelativeHeight(220))];
//    _imageScrollView.backgroundColor = [UIColor grayColor];
//    _imageScrollView.pics = NetImageArray;
//    [_imageScrollView returnIndex:^(NSInteger index) {
//        NSLog(@"%ld",(long)index);
//        [self.navigationController pushViewController:[WebImageControl new] animated:YES];
//    }];
//    [_imageScrollView reloadView];
//    [_titleView addSubview:_imageScrollView];
//    
//}
//-(void)createFootView
//{
//   
//    UILabel * headLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, kRelativeHeight(40))];
//    headLabel.text = @"App公告";
//    headLabel.textAlignment = NSTextAlignmentCenter;
//    [_footView addSubview:headLabel];
//    headLabel.backgroundColor = [UIColor greenColor];
//    UIImageView * headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth/2-kRelativeWidth(80), kRelativeHeight(5) , kRelativeWidth(30), kRelativeHeight(30))];
//    [_footView addSubview:headImageView];
//    headImageView.backgroundColor = [UIColor redColor];
//    headImageView.image = [UIImage imageNamed:@""];
//    
//
////    FootScrollView * footImageView = [[FootScrollView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(40), ScreenWidth, kRelativeHeight(260)) WithNetImages:self.footImageArray];
////    footImageView.AutoScrollDelay = 2;
////    footImageView.netDelagate = self;
////    [_footView addSubview:footImageView];
//    _imageScrollView = [[ImageScrollView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(40), ScreenWidth, kRelativeHeight(260))];
//    _imageScrollView.backgroundColor = [UIColor grayColor];
//    _imageScrollView.pics = footImageArray;
//    [_imageScrollView returnIndex:^(NSInteger index) {
//        NSLog(@"%ld",(long)index);
//        [self.navigationController pushViewController:[WebView new] animated:YES];
//    }];
//    [_imageScrollView reloadView];
//    [_footView addSubview:_imageScrollView];
//    
//}
//
//#pragma  mark ----- 数据源
//-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
//{
//    return 1;
//}
//-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
//{
//    return 1;
//}
//-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    static NSString * cellID = @"cellCusID";
//    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellID];
//    if (!cell) {
//        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
//        _mainscrollView = [[MainScrollView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth*2, 500)];
//        _mainscrollView.backgroundColor = [UIColor whiteColor];
//        [cell.contentView addSubview:_mainscrollView];
//    }
//    return cell;
//}
//-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return 500;
//}
//-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
//{
//    return 10;
//}
//-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
//{
//    return 10;
//}
//#pragma mark --- cell点击

//-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
//{
//   [self.navigationController pushViewController:[uiwebViewControl new] animated:YES];
//}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
