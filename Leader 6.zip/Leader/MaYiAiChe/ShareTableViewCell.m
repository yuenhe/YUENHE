//
//  ShareTableViewCell.m
//  MaYiAiChe
//
//  Created by xc on 16/12/23.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "ShareTableViewCell.h"

@implementation ShareTableViewCell
{
    UILabel * _headLabel;
    UILabel * _nameLabel;
    UIImageView * _headImageView;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _headLabel = [[UILabel alloc]initWithFrame:CGRectMake(40, 5, 80, 30)];
        _headLabel.backgroundColor = [UIColor clearColor];
        _headLabel.textAlignment = NSTextAlignmentLeft;
        _headLabel.textColor = [UIColor blackColor];
        _headLabel.font = [UIFont systemFontOfSize:20];
        [self.contentView addSubview:_headLabel];
        
        _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(130, 5, 150, 30)];
        _nameLabel.textAlignment = NSTextAlignmentCenter;
        _nameLabel.textColor = [UIColor lightGrayColor];
        _nameLabel.font = [UIFont systemFontOfSize:18];
        [self.contentView addSubview:_nameLabel];
        
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(5, 5, 30, 30)];
        _headImageView.backgroundColor = [UIColor redColor];
        [self.contentView addSubview:_headImageView];
    }
    return self;
}
//0显示第一行，1显示第二行，
-(void)reloadViewWithName:(NSString *)headLabel headImageView:(UIImage *)headImageView nameLabel:(NSString *)nameLabel showStatus:(NSInteger)showstatus
{
    if (showstatus == 0) {
        _nameLabel.hidden = NO;
        _nameLabel.text = nameLabel;
    }else{
        _nameLabel.hidden = YES;
    }
    _headLabel.text = headLabel;
    _headImageView.image = headImageView;
}
@end
