//
//  VideoViewController.h
//  MaYiAiChe
//
//  Created by xc on 16/12/28.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoViewController : UIViewController

@end
