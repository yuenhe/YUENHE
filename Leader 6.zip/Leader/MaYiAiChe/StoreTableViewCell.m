//
//  StoreTableViewCell.m
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "StoreTableViewCell.h"


@implementation StoreTableViewCell
{
    UILabel * _textLabel;
    UILabel * _timeLabel;
    UIImageView * _headImageView;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _textLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(20), kRelativeWidth(200), kRelativeHeight(40))];
        _textLabel.backgroundColor = [UIColor clearColor];
        _textLabel.numberOfLines = 3;
        _textLabel.textAlignment = NSTextAlignmentLeft;
        _textLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:_textLabel];
        
        _timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(70), kRelativeWidth(200), kRelativeHeight(20))];
        _timeLabel.backgroundColor = [UIColor clearColor];
        _timeLabel.textAlignment = NSTextAlignmentLeft;
        _timeLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:_timeLabel];
        
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-kRelativeWidth(120), kRelativeHeight(120), kRelativeWidth(100), kRelativeHeight(60))];
        _headImageView.backgroundColor = [UIColor grayColor];
        [self.contentView addSubview:_headImageView];
        
    }
    return self;
}
//-(void)foleData:(HomeModel *)model
//{
//    _textLabel.text = model.itemName;
//    _timeLabel.text = model.time;
//}
-(void)reloadWithName:(NSString *)textLabel timeLabel:(NSString *)timeLabel headIamgeView:(UIImage *)headIamge
{
    _textLabel.text = textLabel;
    _timeLabel.text = timeLabel;
    _headImageView.image = headIamge;
}

@end
