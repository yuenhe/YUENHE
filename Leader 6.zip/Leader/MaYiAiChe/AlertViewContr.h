//
//  AlertViewContr.h
//  UIAlertView
//
//  Created by yuenhe on 16/11/19.
//  Copyright © 2016年 yuenhe. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^AlertResult)(NSInteger index);


@interface AlertViewContr : UIView

@property (nonatomic,copy) AlertResult resultIndex;

- (instancetype)initWithTitle:(NSString *)title message:(NSString *)message sureBtn:(NSString *)sureTitle cancleBtn:(NSString *)cancleTitle;

- (void)showXLAlertView;


/**
 AlertViewContr * alert = [[AlertViewContr alloc]initWithTitle:@"你好啊" message:@"试试就急急急和刷卡机安检点发货后打开就安静的及的撒娇读文件都忘记" sureBtn:@"确定" cancleBtn:@"取消"];
 [alert showXLAlertView];
 alert.resultIndex = ^(NSInteger index){
 //回调---处理一系列动作
 NSLog(@"点击了 ");
 
 };

 */
@end
