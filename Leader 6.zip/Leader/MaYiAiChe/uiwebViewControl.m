//
//  uiwebViewControl.m
//  MaYiAiChe
//
//  Created by xc on 17/2/20.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "uiwebViewControl.h"

@implementation uiwebViewControl
{
    UIView *_mynavigationBar;
    UIButton * _backLabel;
    UILabel * _titleLabel;
}
-(void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:238.0/255 green:238.0/255 blue:238.0/255 alpha:1];
    self.navigationController.navigationBarHidden = YES;
    
    //自定义navigationbar
    _mynavigationBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 64)];
    _mynavigationBar.backgroundColor = [UIColor greenColor];
    [self.view addSubview:_mynavigationBar];
    //返回item
    _backLabel = [[UIButton alloc]initWithFrame:CGRectMake(5, 25, 30, 30)];
    _backLabel.backgroundColor = [UIColor clearColor];
    [_backLabel setImage:[UIImage imageNamed:@"backwhite"] forState:UIControlStateNormal];
    [_backLabel addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigationBar addSubview:_backLabel];
    
    //title
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-100, 22, 200, 40)];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text =@"我的资产";
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.font = [UIFont systemFontOfSize:25];
    [_mynavigationBar addSubview:_titleLabel];
//    [self initUI];
}
//返回上一页
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
