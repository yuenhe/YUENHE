//
//  uiwebViewControl.h
//  MaYiAiChe
//
//  Created by xc on 17/2/20.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface uiwebViewControl : UIViewController

@end
