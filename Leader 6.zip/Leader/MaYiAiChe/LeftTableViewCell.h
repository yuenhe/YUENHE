//
//  LeftTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 17/2/15.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>
#define kCellIdentifier_Left @"LeftTableViewCell"
@interface LeftTableViewCell : UITableViewCell

@property (nonatomic, strong) UILabel *name;
@end
