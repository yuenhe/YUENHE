//
//  ScheduleViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "ScheduleViewController.h"
#import "FinishServiceTableViewCell.h"
#import "FinishCommTableViewCell.h"

#import "XFDaterView.h"
#import "DataView.h"
#import "GetOneDay.h"

#import "MainScrollView.h"
#import "DataCenter.h"

#import "UITableView+LSEmpty.h"
#import "TBRefresh.h"



#define Width [UIScreen mainScreen].bounds.size.width
#define Height [UIScreen mainScreen].bounds.size.height
#define mainTone [UIColor colorWithRed:73.0/255.0 green:196.0/255.0 blue:51.0/255.0 alpha:1.0]

@interface ScheduleViewController ()<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate,dateViewDelegate,XFDaterViewDelegate>
{
    UIView *_topView;
    UIView *_selectedView;
    //    UIScrollView *_bigScrollview;
    UIButton * _selectedBtn;
    UIView * _mainView;
    UIPickerView * _pickView;
    UILabel * _datalabel;
    UILabel * _dayLabel;
}
//声明一个日期的View属性
//@property(nonatomic,strong)DataView * date;

@property (nonatomic,strong) UISegmentedControl * segmentedControl;

@property(nonatomic,strong)DataCenter * data;                               //  单利
@property(nonatomic,strong)UITableView *  tableView;    //
@property(nonatomic,strong)NSMutableArray *  dataSource;            //  数据源
@property (nonatomic,strong) UITableView * etableView;                  // 商品

@property(nonatomic,strong)NSString  *  tempMonth;       //  监听当前的月份
@property(nonatomic,strong)NSString  *  tempYear;          //  监听当前的年份

@end

@implementation ScheduleViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    //        //            //    、获取时间
    NSDate * date = [NSDate date];
    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"M/d/Y"];
    NSString *dateString = [dateFormatter stringFromDate:date];
    
    [self createAFNetworking:dateString];    //  数据请求
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBarHidden = YES;
    
    _data = [DataCenter shareDataCenter];
    _dataSource  = [NSMutableArray  new];
    
    [self initheadView];
    [self initUI];                      // 创建表格
    // Do any additional setup after loading the view.
    
    self.tableView.startTip = YES;
    self.tableView.tipTitle = @"没有订单!";
    //可以不设置 默认图片为nomessage 可以到分类中修改默认图片名
    self.tableView.tipImage=[UIImage imageNamed:@"nomessage"];
    
    //     self.tableView.retryBlock=^(){
    //        NSLog(@"重接加载回调 ");
    //    };
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)initheadView
{
    UIView * headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Width, kRelativeHeight(150))];
    headView.backgroundColor = [UIColor colorWithRed: 94/256.0 green:207/256.0 blue:80/256.0 alpha:1];
    [self.view addSubview:headView];
    
    
    //获取当前时间
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"YYYY年MM月"];
    NSString *string1 = [dateFormatter stringFromDate:[NSDate date]];
    [dateFormatter setDateFormat:@"EEE"];
    NSString * weekString = [dateFormatter stringFromDate:[NSDate date]];
    [dateFormatter setDateFormat:@"DD"];
    NSString * daystring = [dateFormatter stringFromDate:[NSDate date]];
    NSLog(@"%@",weekString);
    //    NSString *  weekStr = [self weekdayStringFromDate:dateFormatter];
    NSLog(@"%@",string1);
    NSLog(@"%@",daystring);
    
    //获取当前几号
    NSDate *currentDate = [NSDate date];//获取当前时间，日期
    NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc] init];
    [dateFormatter1 setDateFormat:@"dd"];
    NSString *dateString = [dateFormatter1 stringFromDate:currentDate];
    int currentDate1 = [dateString intValue];
    NSLog(@"--日期--%d",currentDate1);
    
    _datalabel = [[UILabel alloc]init];
    _datalabel.center = CGPointMake(ScreenWidth/2, kRelativeHeight(45));
    _datalabel.bounds = CGRectMake(0, 0, 150, kRelativeHeight(40));
    _datalabel.backgroundColor = [UIColor clearColor];
    _datalabel.text = [NSString stringWithFormat:@"%@",string1];
    _datalabel.textColor = [UIColor whiteColor];
    //    _datalabel.textAlignment = NSTextAlignmentLeft;
    _datalabel.layer.masksToBounds = YES;
    _datalabel.layer.cornerRadius = 5;
    _datalabel.layer.borderWidth = 1;
    _datalabel.layer.borderColor = [[UIColor whiteColor]CGColor];
    _datalabel.userInteractionEnabled = YES;
    [headView addSubview:_datalabel];
    
    // 获取当前日期 用于刷新
    NSArray *temp=[_datalabel.text componentsSeparatedByString:@"年"];
    NSArray *temp1=[temp[1] componentsSeparatedByString:@"月"];
    _tempYear = [NSString stringWithFormat:@"%@/%d/%@",temp1[0],currentDate1,temp[0]];
    
    
    // 选择日期
    UIButton * datebtn = [UIButton buttonWithType:UIButtonTypeCustom];
    datebtn.center = CGPointMake(130, 20);
    datebtn.bounds = CGRectMake(0, 0, 40, 40);
    datebtn.backgroundColor = [UIColor whiteColor];
    [datebtn addTarget:self action:@selector(btnpushAlert) forControlEvents:UIControlEventTouchUpInside];
    [_datalabel addSubview:datebtn];
    
    
    
    self.segmentedControl = [[UISegmentedControl alloc]initWithFrame:CGRectMake(10,kRelativeHeight(70),Width-20,kRelativeHeight(40))];
    [self.segmentedControl insertSegmentWithTitle:[NSString stringWithFormat:@"%d",currentDate1-2] atIndex:0 animated:NO];
    [self.segmentedControl insertSegmentWithTitle:[NSString stringWithFormat:@"%d",currentDate1-1]  atIndex:1 animated:NO];
    [self.segmentedControl insertSegmentWithTitle:[NSString stringWithFormat:@"%d",currentDate1-0]  atIndex:2 animated:NO];
    [self.segmentedControl insertSegmentWithTitle:[NSString stringWithFormat:@"%d",currentDate1+1]  atIndex:3 animated:NO];
    [self.segmentedControl insertSegmentWithTitle:[NSString stringWithFormat:@"%d",currentDate1+2] atIndex:4 animated:NO];
    [self.segmentedControl insertSegmentWithTitle:[NSString stringWithFormat:@"%d",currentDate1+3] atIndex:5 animated:NO];
    [self.segmentedControl insertSegmentWithTitle:[NSString stringWithFormat:@"%d",currentDate1+4] atIndex:6 animated:NO];
    
    //    NSArray *temp=[string1 componentsSeparatedByString:@"年"];
    //    NSArray *temp1=[temp[1] componentsSeparatedByString:@"月"];
    NSInteger days = [NSCalendar getDaysWithYear:[temp[0] integerValue] month:[temp1[0] integerValue]];
    NSInteger dayss = [NSCalendar getDaysWithYear:[temp[0] integerValue] month:[temp1[0] integerValue]-1];
    
    if ([weekString isEqualToString:@"Sun"]||[weekString isEqualToString:@"周日"]) {
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1] forSegmentAtIndex:0];
        if (currentDate1 == days-5) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+3] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+4] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:6];
        }else if (currentDate1 == days-4) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+4] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:6];
        }else if (currentDate1 == days-3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:6];
        }else if (currentDate1 == days-2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",4] forSegmentAtIndex:6];
        }else if (currentDate1 == days-1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",4] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",5] forSegmentAtIndex:6];
        }else if (currentDate1 == days) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",4] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",5] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",6] forSegmentAtIndex:6];
        } else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+4] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+5] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+6] forSegmentAtIndex:6];
        }
        
        self.segmentedControl.selectedSegmentIndex = 0;
    }
    else if ([weekString isEqualToString:@"Mon"]||[weekString isEqualToString:@"周一"]) {
        if (currentDate1 == 1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-1+dayss] forSegmentAtIndex:0];
        }else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:0];
        }
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1] forSegmentAtIndex:1];
        if (currentDate1 == days-4) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+3] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+4] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:6];
        }else if (currentDate1 == days-3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+3] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:6];
        }else if (currentDate1 == days-2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:6];
        }else if (currentDate1 == days-1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",4] forSegmentAtIndex:6];
        }else if (currentDate1 == days) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",4] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",5] forSegmentAtIndex:6];
        } else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+3] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+4] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+5] forSegmentAtIndex:6];
        }
        
        self.segmentedControl.selectedSegmentIndex = 1;
    }
    else if ([weekString isEqualToString:@"Tue"]||[weekString isEqualToString:@"周二"]) {
        if (currentDate1 == 2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-2+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:1];
        }else if (currentDate1 == 1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-2+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-1+dayss] forSegmentAtIndex:1];
        }else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:0];
        }
        
        
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1] forSegmentAtIndex:2];
        if (currentDate1 == days-3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+3] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:6];
        }else if (currentDate1 == days-2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:6];
        }else if (currentDate1 == days-1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:6];
        }else if (currentDate1 == days) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",4] forSegmentAtIndex:6];
        } else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+3] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+4] forSegmentAtIndex:6];
        }
        
        
        self.segmentedControl.selectedSegmentIndex = 2;
    }
    else if ([weekString isEqualToString:@"Wed"]||[weekString isEqualToString:@"周三"]) {
        if (currentDate1 == 3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-3+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:2];
        }else if (currentDate1 == 2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-3+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-2+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:2];
        }else if (currentDate1 == 1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-3+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-2+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-1+dayss] forSegmentAtIndex:2];
        }else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-3] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:2];
        }
        
        
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1] forSegmentAtIndex:3];
        if (currentDate1 == days-2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:6];
        }else if (currentDate1 == days-1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:6];
        }else if (currentDate1 == days) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:6];
        } else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+3] forSegmentAtIndex:6];
        }
        
        self.segmentedControl.selectedSegmentIndex = 3;
    }
    else if ([weekString isEqualToString:@"Thu"]||[weekString isEqualToString:@"周四"]) {
        if (currentDate1 == 4) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-4+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-3] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:3];
        }else if (currentDate1 == 3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-4+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-3+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:3];
        }else if (currentDate1 == 2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-4+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-3+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-2+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:3];
        }else if (currentDate1 == 1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-4+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-3+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-2+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-1+dayss] forSegmentAtIndex:3];
        }else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-4] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-3] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:3];
        }
        
        
        
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1] forSegmentAtIndex:4];
        if (currentDate1 == days-1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:6];
        }else if (currentDate1 == days) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:6];
        } else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+2] forSegmentAtIndex:6];
        }
        
        
        self.segmentedControl.selectedSegmentIndex = 4;
    }
    else if ([weekString isEqualToString:@"Fri"]||[weekString isEqualToString:@"周五"]) {
        if (currentDate1 == 5) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-5+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-4] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-3] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:4];
        } else if (currentDate1 == 4) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-5+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-4+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-3] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:4];
        }else if (currentDate1 == 3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-5+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-4+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-3+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:4];
        }else if (currentDate1 == 2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-5+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-4+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-3+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-2+dayss] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:4];
        }else if (currentDate1 == 1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-5+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-4+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-3+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-2+dayss] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-1+dayss] forSegmentAtIndex:4];
        }else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-5] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-4] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-3] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:4];
        }
        
        
        
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1] forSegmentAtIndex:5];
        
        if (currentDate1 == days) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:6];
        } else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1+1] forSegmentAtIndex:6];
        }
        
        self.segmentedControl.selectedSegmentIndex = 5;
    }
    else if ([weekString isEqualToString:@"Sat"]||[weekString isEqualToString:@"周六"]) {
        if (currentDate1 == 6) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-6+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-5] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-4] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:5];
        }else if (currentDate1 == 5) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-6+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-5+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-4] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:5];
        } else if (currentDate1 == 4) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-6+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-5+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-4+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:5];
        }else if (currentDate1 == 3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-6+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-5+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-4+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-3+dayss] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:5];
        }else if (currentDate1 == 2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-6+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-5+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-4+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-3+dayss] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-2+dayss] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:5];
        }else if (currentDate1 == 1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-6+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-5+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-4+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-3+dayss] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-2+dayss] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",currentDate1-1+dayss] forSegmentAtIndex:5];
        }else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-6] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-5] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-4] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1-1] forSegmentAtIndex:5];        }
        
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",currentDate1] forSegmentAtIndex:6];
        self.segmentedControl.selectedSegmentIndex = 6;
    }
    self.segmentedControl.backgroundColor = [UIColor clearColor];
    self.segmentedControl.tintColor = [UIColor orangeColor];
    NSDictionary * selectedTextAttributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:14],NSForegroundColorAttributeName:[UIColor whiteColor]};
    [self.segmentedControl setTitleTextAttributes:selectedTextAttributes forState:UIControlStateSelected];
    NSDictionary* unselectedTextAttributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:14], NSForegroundColorAttributeName: [UIColor grayColor]};
    [self.segmentedControl setTitleTextAttributes:unselectedTextAttributes forState:UIControlStateNormal];
    [self.segmentedControl addTarget:self action:@selector(segmentedChanged:) forControlEvents:UIControlEventValueChanged];
    [headView addSubview:self.segmentedControl];
    //    [self segmentedChanged:0];
    NSArray * weekArray = [NSArray arrayWithObjects:@"周日",@"周一",@"周二",@"周三",@"周四",@"周五",@"周六", nil];
    for (int i = 0; i<weekArray.count ; i++) {
        //        float w = 58.5;
        UILabel * weekLabel = [[UILabel alloc]initWithFrame:CGRectMake(10+self.segmentedControl.frame.size.width/7*i, kRelativeHeight(110), self.segmentedControl.frame.size.width/7, kRelativeHeight(20))];
        weekLabel.textAlignment = NSTextAlignmentCenter;
        weekLabel.textColor = [UIColor whiteColor];
        weekLabel.font = [UIFont systemFontOfSize:kRelativeWidth(16)];
        weekLabel.text = [weekArray objectAtIndex:i];
        weekLabel.backgroundColor = [UIColor clearColor];
        [headView addSubview: weekLabel];
    }
}


#pragma mark=================== 分段选择 点击事件
-(void)segmentedChanged:(UISegmentedControl *)sender
{
    // 获取当前日
    NSString * text  = [self.segmentedControl titleForSegmentAtIndex:sender.selectedSegmentIndex];
    
    // 获取当前年 月
    NSLog(@"-------%@",_datalabel.text);
    NSArray *temp=[_datalabel.text componentsSeparatedByString:@"年"];
    NSArray *temp1=[temp[1] componentsSeparatedByString:@"月"];
    
     NSString *  Riqi_date = [NSString stringWithFormat:@"%@/%@/%@",temp1[0],text,temp[0]];
    
    _tempYear = Riqi_date;      //  刷新用
    [self.tableView.header beginRefreshing];
    
    [self createAFNetworking:Riqi_date];    //  数据请求
    
    [_tableView reloadData];
    
}


#pragma mark===================日期按钮   XFDaterView*dater;
-(void)btnpushAlert
{
    NSLog(@"日期按钮");
    //    [self.view addSubview:self.date];
    XFDaterView * dater=[[XFDaterView alloc]initWithFrame:CGRectZero];
    dater.delegate=self;
    [dater showInView:self.view animated:YES];
    
}


#pragma mark=================== 日历选择时间
- (void)daterViewDidClicked:(XFDaterView *)daterView{
    //    NSLog(@"dateString=%@ timeString=%@",dater.dateString,dater.timeString);
    
    // 监听当前的年月(刷新时时使用)
    _tempYear = [NSString stringWithFormat:@"%d/%d/%d",daterView.month,daterView.day,daterView.year];
    [self.tableView.header beginRefreshing];
    
    _datalabel.text = [NSString stringWithFormat:@"%d年%d月",daterView.year,daterView.month];
    _dayLabel.text = [NSString stringWithFormat:@"%d",daterView.day];
    NSLog(@"%@",_datalabel.text);
    NSLog(@"%@", _dayLabel.text);
    int day = daterView.day;
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [dateFormatter dateFromString:[NSString stringWithFormat:@"%d-%d-%d",daterView.year,daterView.month,daterView.day]];
    
    NSString *dayStr = [self weekdayStringFromDate:date];
    NSInteger days = [NSCalendar getDaysWithYear:daterView.year month:daterView.month ];
    NSInteger dayss = [NSCalendar getDaysWithYear:daterView.year month:daterView.month-1];
    
    
    
    if ([dayStr isEqualToString:@"周日"]) {
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day] forSegmentAtIndex:0];
        if (day == days-5) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+3] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+4] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:6];
        }else if (day == days-4) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+4] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:6];
        }else if (day == days-3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:6];
        }else if (day == days-2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",4] forSegmentAtIndex:6];
        }else if (day == days-1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",4] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",5] forSegmentAtIndex:6];
        }else if (day == days) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",4] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",5] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",6] forSegmentAtIndex:6];
        } else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+4] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+5] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+6] forSegmentAtIndex:6];
        }
        
        
        self.segmentedControl.selectedSegmentIndex = 0;
    }
    else if ([dayStr isEqualToString:@"周一"]) {
        if (day == 1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-1+dayss] forSegmentAtIndex:0];
        }else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:0];
        }
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day] forSegmentAtIndex:1];
        if (day == days-4) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+3] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+4] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:6];
        }else if (day == days-3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+3] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:6];
        }else if (day == days-2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:6];
        }else if (day == days-1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",4] forSegmentAtIndex:6];
        }else if (day == days) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",4] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",5] forSegmentAtIndex:6];
        } else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+3] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+4] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+5] forSegmentAtIndex:6];
        }
        
        self.segmentedControl.selectedSegmentIndex = 1;
    }
    else if ([dayStr isEqualToString:@"周二"]) {
        if (day == 2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-2+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:1];
        }else if (day == 1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-2+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-1+dayss] forSegmentAtIndex:1];
        }else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:0];
        }
        
        
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day] forSegmentAtIndex:2];
        if (day == days-3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+3] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:6];
        }else if (day == days-2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:6];
        }else if (day == days-1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:6];
        }else if (day == days) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",4] forSegmentAtIndex:6];
        } else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+3] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+4] forSegmentAtIndex:6];
        }
        
        
        self.segmentedControl.selectedSegmentIndex = 2;
    }
    else if ([dayStr isEqualToString:@"周三"]) {
        if (day == 3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-3+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:2];
        }else if (day == 2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-3+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-2+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:2];
        }else if (day == 1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-3+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-2+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-1+dayss] forSegmentAtIndex:2];
        }else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-3] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:2];
        }
        
        
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day] forSegmentAtIndex:3];
        if (day == days-2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:6];
        }else if (day == days-1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:6];
        }else if (day == days) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",3] forSegmentAtIndex:6];
        } else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+3] forSegmentAtIndex:6];
        }
        
        self.segmentedControl.selectedSegmentIndex = 3;
    }
    else if ([dayStr isEqualToString:@"周四"]) {
        if (day == 4) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-4+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-3] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:3];
        }else if (day == 3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-4+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-3+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:3];
        }else if (day == 2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-4+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-3+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-2+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:3];
        }else if (day == 1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-4+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-3+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-2+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-1+dayss] forSegmentAtIndex:3];
        }else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-4] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-3] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:3];
        }
        
        
        
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day] forSegmentAtIndex:4];
        if (day == days-1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:6];
        }else if (day == days) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",2] forSegmentAtIndex:6];
        } else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:5];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+2] forSegmentAtIndex:6];
        }
        
        
        self.segmentedControl.selectedSegmentIndex = 4;
    }
    else if ([dayStr isEqualToString:@"周五"]) {
        if (day == 5) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-5+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-4] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-3] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:4];
        } else if (day == 4) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-5+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-4+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-3] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:4];
        }else if (day == 3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-5+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-4+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-3+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:4];
        }else if (day == 2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-5+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-4+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-3+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-2+dayss] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:4];
        }else if (day == 1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-5+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-4+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-3+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-2+dayss] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-1+dayss] forSegmentAtIndex:4];
        }else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-5] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-4] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-3] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:4];
        }
        
        
        
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day] forSegmentAtIndex:5];
        
        if (day == days) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",1] forSegmentAtIndex:6];
        } else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day+1] forSegmentAtIndex:6];
        }
        
        self.segmentedControl.selectedSegmentIndex = 5;
    }
    else if ([dayStr isEqualToString:@"周六"]) {
        if (day == 6) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-6+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-5] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-4] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:5];
        }else if (day == 5) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-6+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-5+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-4] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:5];
        } else if (day == 4) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-6+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-5+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-4+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:5];
        }else if (day == 3) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-6+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-5+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-4+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-3+dayss] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:5];
        }else if (day == 2) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-6+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-5+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-4+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-3+dayss] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-2+dayss] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:5];
        }else if (day == 1) {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-6+dayss] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-5+dayss] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-4+dayss] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-3+dayss] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-2+dayss] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%ld",day-1+dayss] forSegmentAtIndex:5];
        }else {
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-6] forSegmentAtIndex:0];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-5] forSegmentAtIndex:1];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-4] forSegmentAtIndex:2];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-3] forSegmentAtIndex:3];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-2] forSegmentAtIndex:4];
            [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day-1] forSegmentAtIndex:5];
        }
        
        [self.segmentedControl setTitle:[NSString stringWithFormat:@"%d",day] forSegmentAtIndex:6];
        self.segmentedControl.selectedSegmentIndex = 6;
    }
    
    [self createAFNetworking:[NSString stringWithFormat:@"%d/%d/%d",daterView.month,daterView.day,daterView.year]];
    [_tableView reloadData];
}


//  将英文转换成 中文
- (NSString*)weekdayStringFromDate:(NSDate*)inputDate {
    
    NSArray *weekdays = [NSArray arrayWithObjects: [NSNull null], @"周日", @"周一", @"周二", @"周三", @"周四", @"周五", @"周六", nil];
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    
    NSTimeZone *timeZone = [[NSTimeZone alloc] initWithName:@"Asia/Shanghai"];
    
    [calendar setTimeZone: timeZone];
    
    NSCalendarUnit calendarUnit = NSCalendarUnitWeekday;
    
    NSDateComponents *theComponents = [calendar components:calendarUnit fromDate:inputDate];
    
    return [weekdays objectAtIndex:theComponents.weekday];
    
}

#pragma mark===================  数据请求
-(void)createAFNetworking:(NSString *)time{
    if (_data.UIDs.length == 0) {
        NSLog(@"登录失败 ");
        //         self.tableView.badNetwork=YES;
    }else{
        //        NSDictionary * dic  = @{@"s_time":@"28",@"s_userid":_data.UIDs};
        NSDictionary * dic  = @{@"s_time":time,@"s_userid":_data.UIDs};
        AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        
        // NSString * urlString = @"http://106.15.0.128/working/index.php/Admin/ApiS/s_rili_sorder";
        NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_rili_sorder";
        
        [manager POST:urlString parameters:dic progress:^(NSProgress * _Nonnull uploadProgress) {
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSString * str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
            NSDictionary * array = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            
            if ([str isEqualToString:@"null"]) {
                NSLog(@"无数据");
                [_dataSource removeAllObjects];
                
            }else{
                [_dataSource removeAllObjects];
                for (NSDictionary * dic  in array) {
                    ScheduleModel *  model  = [[ScheduleModel alloc]initWithDic:dic];
                    [_dataSource addObject:model];
                }
            }
            [_tableView reloadData];
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"%@",error);
            
        }];
    }
}


#pragma mark===================  创建表格

-(void)initUI
{
    _topView = [[UIView alloc]initWithFrame:CGRectMake(0,kRelativeHeight(150), [UIScreen mainScreen].bounds.size.width, kRelativeHeight(40))];
    [_topView setBackgroundColor:[UIColor colorWithRed:230/256.0 green:230/256.0 blue:230/256.0 alpha:1]];
    [self.view addSubview:_topView];
    NSArray *array = [[NSArray alloc]initWithObjects:@"已完成服务",@"已完成商品", nil];
    float  width = ScreenWidth/2;
    for (int i =0; i<array.count; i++) {
        NSString * title = [array objectAtIndex:i];
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(width*i, kRelativeHeight(5), width, kRelativeHeight(30));
        [btn setTitle:title forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor colorWithRed: 94/256.0 green:207/256.0 blue:80/256.0 alpha:1] forState:UIControlStateSelected];
        [btn addTarget:self action:@selector(topbtnclick:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = 100+i;
        [_topView addSubview:btn];
        if (i == 0) {
            _selectedBtn = btn;
            _selectedBtn.selected = YES;
        }
    }
    
    _bigScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(190), [UIScreen mainScreen].bounds.size.width, kRelativeHeight(ScreenHeight-250))];
    [self.view addSubview:_bigScrollView];
    _bigScrollView.backgroundColor = [UIColor lightGrayColor];
    _bigScrollView.contentSize = CGSizeMake(ScreenWidth*2, 0);
    _bigScrollView.pagingEnabled = YES;
    _bigScrollView.scrollEnabled = NO;
    //    _bigSrollView.directionalLockEnabled = YES;
    _bigScrollView.bounces = NO;
    _bigScrollView.delegate = self;
    __weak ScheduleViewController * weakself = self;
    for (int i = 0 ; i<2; i++) {
        UITableView* tableView = [[UITableView alloc]initWithFrame:CGRectMake(ScreenWidth*i, 0, ScreenWidth,_bigScrollView.frame.size.height) style:UITableViewStylePlain];
        tableView.tag = i+200;
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.tableFooterView = [UIView new];
        tableView.showsHorizontalScrollIndicator = NO;
        [_bigScrollView addSubview:tableView];
        if (i == 0) {
            self.tableView = tableView;
        }else{
            self.etableView = tableView;
        }
        
    } // 刷新
    [_tableView addRefreshHeaderWithBlock:^{
        [weakself LoadDatas];
    }];
    [self.tableView.header beginRefreshing];
    
}


#pragma  mark -- scrollViewDelegate
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if ([scrollView isEqual:_bigScrollView]) {
        int contentoffset = scrollView.contentOffset.x;
        int numOfTable = contentoffset/ScreenWidth;
        UIButton * btn  = (UIButton *)[self.view viewWithTag:100+numOfTable];
        [self topbtnclick:btn];
    }
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.contentOffset.y<0) {
        return;
    }
}
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if (scrollView.contentOffset.y<0) {
        return;
    }
}
-(void)topbtnclick:(UIButton *)sender
{
    if (_selectedBtn == sender) {
        return;
    }
    _selectedBtn.selected = NO;
    _selectedBtn = sender;
    _selectedBtn.selected = YES;
    float width = 100;
    [_bigScrollView setContentOffset:CGPointMake(ScreenWidth*(sender.tag-100), 0) animated:YES];
    [UIView animateWithDuration:0.3 animations:^{
        _selectedView.frame = CGRectMake(width*(sender.tag-100), 80-1, width, 1);
        
    }];
}

#pragma mark -- tableviewdelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    switch (tableView.tag -200) {
        case 0:
        {
            return 1;
        }
            break;
        case 1:
        {
            return 3;
        }
            
        default:
            return 0;
            break;
    }
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag == 200) {
        return self.dataSource.count;
    }else
    {
        return self.dataSource.count;
    }
    
}

#pragma mark=================== cell 回调
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (tableView.tag - 200) {
        case 0:
        {
            static NSString * cellId = @"cellCusID";
            FinishServiceTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[FinishServiceTableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellId];
            }
            cell.model = _dataSource[indexPath.row];
            cell.selectionStyle  = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
        case 1:
        {
            static NSString * cellId = @"cellCusID";
            FinishCommTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellId];
            if (!cell) {
                cell = [[FinishCommTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
            }
            return cell;
            
        }
            
        default:
            return 0;
            break;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (tableView.tag-200) {
        case 0:
            return kRelativeHeight(180);
            break;
        case 1:
            return 300;
            break;
        default:
            return 0;
            break;
    }
    
}

#pragma mark=================== 选中cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [_tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
    
}


#pragma mark--------下拉 加载数据

-(void)LoadDatas
{
    [self.tableView.footer ResetNomoreData];
    
    if (_data.UIDs.length == 0) {
        NSLog(@"还没登录成功");
    }else{
        NSLog(@"%@-----年月日=====-------",_tempYear);
        NSDictionary * dic  = @{@"s_time":_tempYear,@"s_userid":_data.UIDs};
        AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        
        // NSString * urlString = @"http://106.15.0.128/working/index.php/Admin/ApiS/s_rili_sorder";
        NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_rili_sorder";
        
        [manager POST:urlString parameters:dic progress:^(NSProgress * _Nonnull uploadProgress) {
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSString * str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
            NSDictionary * array = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            
            if ([str isEqualToString:@"null"]) {
                NSLog(@"无数据");
//                [_dataSource removeAllObjects];
            }else{
                [_dataSource removeAllObjects];
                for (NSDictionary * dic  in array) {
                    ScheduleModel *  model  = [[ScheduleModel alloc]initWithDic:dic];
                    [_dataSource addObject:model];
                }
            }
            NSLog(@"---未接单-新的数量----------%ld------",_dataSource.count);
            //                [_tableView reloadData];
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"%@",error);
        }];
    }
    
    // 模拟延时设置
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        [_tableView reloadData];
        
        [self.tableView.header endHeadRefresh];
        
    });
}



/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
