//
//  BulletinViewController.h
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BulletinViewController : UIViewController

@end
