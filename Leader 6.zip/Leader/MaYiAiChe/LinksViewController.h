//
//  LinksViewController.h
//  MaYiAiChe
//
//  Created by xc on 17/1/3.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LinksViewController : UIViewController

@end
