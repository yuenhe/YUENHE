
//
//  MapView.m
//  MaYiAiChe
//
//  Created by xc on 17/2/8.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "MapView.h"
#import <MAMapKit/MAMapKit.h>
#import <AMapSearchKit/AMapSearchKit.h>
#import <AMapLocationKit/AMapLocationKit.h>

#define APIKey  @"a28f576d080354502a3e8a352130d7be"
@interface MapView ()<MAMapViewDelegate>
{
    MAMapView * _mapview;
    //初始化search对象
    AMapSearchAPI *_search;
    //声明一个变量
    CLLocation *_currentLocation;
}

@end

@implementation MapView
-(instancetype)initWithFrame:(CGRect)frame
{
    self  = [super initWithFrame:frame];
    if (self) {
        [self initUI];
    }
    return self;
}
-(void)initUI
{
//    [AMapServices sharedServices].apiKey = APIKey;
    _mapview = [[MAMapView alloc] initWithFrame:self.bounds];
    _mapview.delegate = self;
    [self addSubview:_mapview];
//    //开启定位
//    
//    _mapview.showsUserLocation = YES;
//    //追踪用户行踪
//    _mapview.userTrackingMode = MAUserTrackingModeFollow;
    
}

//-(void)mapView:(MAMapView *)mapView didUpdateUserLocation:(MAUserLocation *)userLocation
//updatingLocation:(BOOL)updatingLocation
//{
//    if (updatingLocation) {
//        NSLog(@"latitude : %f , longitude : %f",userLocation.coordinate.latitude,userLocation.coordinate.longitude);
//    }
//    _currentLocation = [userLocation.location copy];
//    //［self initsearchs］；
//    //[self initAction];
//}
//-(void)mapView:(MAMapView *)mapView didSelectAnnotationView:(MAAnnotationView *)view
//{
//    if ([view.annotation isKindOfClass:[MAUserLocation class]]) {
//        [self initAction];
//    }
//}
//-(void)initAction
//{
//    if (_currentLocation) {
//        AMapReGeocodeSearchRequest * request = [[AMapReGeocodeSearchRequest alloc]init];
//        request.location = [AMapGeoPoint locationWithLatitude:_currentLocation.coordinate.latitude longitude:_currentLocation.coordinate.longitude];//精度和纬度
//        [_search AMapReGoecodeSearch:request];
//        
//    }
//}
//- (void) onReGeocodeSearchDone:(AMapReGeocodeSearchRequest *)request response:(AMapReGeocodeSearchResponse *)response{
//    
//    NSLog(@"request:%@",request);
//    NSString *title = response.regeocode.addressComponent.city;
//    if (title.length == 0) {
//        title = response.regeocode.addressComponent.province;
//    }
//    _mapview.userLocation.title = title;
//    _mapview.userLocation.subtitle = response.regeocode.formattedAddress;
//    
//}
@end
