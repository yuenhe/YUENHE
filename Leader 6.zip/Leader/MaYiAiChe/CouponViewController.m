//
//  CouponViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "CouponViewController.h"

@interface CouponViewController ()
{
    UIView * _mynavigeationBar;
    UIButton * _backLabel;
    UILabel * _titleLabel;
    UIImageView * _couponImageView;
    NSArray * imageArray;
}

@end

@implementation CouponViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor lightGrayColor];
    self.navigationController.navigationBar.hidden = YES;
    //自定义navigationbar
    _mynavigeationBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, kRelativeHeight(64))];
    _mynavigeationBar.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_mynavigeationBar];
    
    _backLabel = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(5), kRelativeHeight(25), kRelativeWidth(30), kRelativeHeight(30))];
    _backLabel.backgroundColor = [UIColor whiteColor];
    [_backLabel setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [_backLabel addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigeationBar addSubview:_backLabel];
    
    
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-kRelativeWidth(100), kRelativeHeight(22), kRelativeWidth(200), kRelativeHeight(40))];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text =@"我的优惠券";
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor blackColor];
    _titleLabel.font = [UIFont systemFontOfSize:25];
    [_mynavigeationBar addSubview:_titleLabel];
    //利用for语句对控件布局
    for (int i = 0; i<2; i++) {
        imageArray = [NSArray arrayWithObjects:@"券底",@"券底2", nil];
        UIImageView * coImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(90)+kRelativeHeight(150)*i, self.view.frame.size.width-kRelativeWidth(40), kRelativeHeight(130))];
        coImageView.backgroundColor = [UIColor clearColor];
        [self.view addSubview: coImageView];
        coImageView.image = [UIImage imageNamed:[imageArray objectAtIndex:i]];
        NSLog(@"%@",coImageView);
        
        UILabel * firstLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(90), kRelativeHeight(20), kRelativeWidth(120), kRelativeHeight(30))];
        firstLabel.text = @"全场通用卷";
        firstLabel.backgroundColor = [UIColor clearColor];
        firstLabel.textAlignment = NSTextAlignmentCenter;
        firstLabel.textColor = [UIColor blackColor];
        firstLabel.font = [UIFont systemFontOfSize:18];
        [coImageView addSubview:firstLabel];
        
        UILabel * scdLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(90), kRelativeHeight(50), kRelativeWidth(120), kRelativeHeight(20))];
        scdLabel.text = @"满55元可用";
        scdLabel.backgroundColor = [UIColor clearColor];
        scdLabel.textAlignment = NSTextAlignmentCenter;
        scdLabel.textColor = [UIColor blackColor];
        scdLabel.font = [UIFont systemFontOfSize:15];
        [coImageView addSubview:scdLabel];
        
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setFrame:CGRectMake(self.view.frame.size.width-kRelativeWidth(110), kRelativeHeight(50), kRelativeWidth(60), kRelativeHeight(30))];
        [btn setTitle:@"转让" forState:UIControlStateNormal];
        [btn addTarget:self action:@selector(btnpushclick) forControlEvents:UIControlEventTouchUpInside];
        btn.backgroundColor = [UIColor orangeColor];
        [coImageView addSubview:btn];
        
        UILabel * menImageView =[[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width-kRelativeWidth(110), kRelativeHeight(25), kRelativeWidth(15), kRelativeHeight(20))];
        menImageView.backgroundColor = [UIColor clearColor];
        menImageView.text = @"¥";
        menImageView.textAlignment = NSTextAlignmentCenter;
        [coImageView addSubview:menImageView];
        
        NSArray * numArray = [NSArray arrayWithObjects:@"16",@"10", nil];
        UILabel * numLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width-kRelativeWidth(95), kRelativeHeight(20), kRelativeWidth(45), kRelativeHeight(25))];
        numLabel.text = [numArray objectAtIndex:i];
        numLabel.textAlignment = NSTextAlignmentCenter;
        numLabel.textColor = [UIColor blackColor];
        numLabel.backgroundColor = [UIColor clearColor];
//        numLabel.font = [UIFont systemFontOfSize:25];
        numLabel.font = [UIFont boldSystemFontOfSize:25];
        [coImageView addSubview:numLabel];
        
        UIImageView * timerImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(10), coImageView.frame.size.height-kRelativeHeight(30), kRelativeWidth(20), kRelativeHeight(20))];
        timerImageView.backgroundColor = [UIColor redColor];
        [coImageView addSubview:timerImageView];
        
        NSArray * titleArray = [NSArray arrayWithObjects:@"还有8天过期",@"已过期", nil];
        UILabel * lineLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(35), coImageView.frame.size.height-kRelativeHeight(27.5), kRelativeWidth(90), kRelativeHeight(15))];
        lineLabel.backgroundColor = [UIColor clearColor];
        lineLabel.textAlignment = NSTextAlignmentLeft;
        lineLabel.textColor =[UIColor blackColor];
        lineLabel.text =[titleArray objectAtIndex:i];
        lineLabel.font = [UIFont systemFontOfSize:12];
        [coImageView addSubview:lineLabel];
        
        UILabel *line2Label = [[UILabel alloc]initWithFrame:CGRectMake(coImageView.frame.size.width/2, coImageView.frame.size.height-kRelativeHeight(27.5), kRelativeWidth(40), kRelativeHeight(15))];
        line2Label.backgroundColor = [UIColor clearColor];
        line2Label.text = @"有效期:";
        line2Label.textAlignment = NSTextAlignmentCenter;
        line2Label.textColor = [UIColor blackColor];
        line2Label.font = [UIFont systemFontOfSize:12];
        [coImageView addSubview:line2Label];
        //日期
        NSArray * array1 = [NSArray arrayWithObjects:@"2016.10.03~2016.11.03",@"2016.09.03~2016.10.03", nil];
        UILabel *line3Label = [[UILabel alloc]initWithFrame:CGRectMake(coImageView.frame.size.width/2+kRelativeWidth(45), coImageView.frame.size.height-kRelativeHeight(27.7), kRelativeWidth(150), kRelativeHeight(15))];
        line3Label.backgroundColor = [UIColor clearColor];
        line3Label.text = [array1 objectAtIndex:i];
        line3Label.textAlignment = NSTextAlignmentCenter;
        line3Label.textColor = [UIColor blackColor];
        line3Label.font = [UIFont systemFontOfSize:12];
        [coImageView addSubview:line3Label];
        
    }
        
        
        
   
    
    

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)btnpushclick
{
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
