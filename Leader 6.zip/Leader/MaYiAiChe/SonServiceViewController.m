//
//  SonServiceViewController.m
//  MaYiAiChe
//
//  Created by xc on 17/1/5.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "SonServiceViewController.h"
#import "MainPhotoView.h"
#import "NaviController.h"
#import "Masonry.h"
#import "UIImageView+WebCache.h"
#import "WSImagePickerView.h"
#import "ImageBrowserViewController.h"




#define Width [UIScreen mainScreen].bounds.size.width
#define Height [UIScreen mainScreen].bounds.size.height

@interface SonServiceViewController ()
{
    UIView * _headView;
    UIImageView * _sexImageView;
    UILabel * _nameLabel;
    UILabel * _telLabel;
    UILabel * _adrLabel;
    UILabel * _fstrtLabel;
    UIImageView * _iamgeView;
    UIButton * _imageBtn;
    MainPhotoView * _phoneView;
}
@property (nonatomic, strong) WSImagePickerView *pickerView;             // 服务前
@property (nonatomic, strong) WSImagePickerView * after_pickerView;    // 服务后

@property (nonatomic, assign) BOOL isUpLoadImage;

@property (nonatomic, strong) NSMutableArray  * imageArray;            // 服务前图片 数组

@property (nonatomic, strong) NSMutableArray  * after_imageArray;    // 服务后数组

@end

@implementation SonServiceViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.frame = CGRectZero;
    self.navigationController.tabBarController.tabBar.hidden = YES;
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.tabBarController.tabBar.frame = CGRectMake(0, ScreenHeight - 49,ScreenWidth,49);
    self.navigationController.tabBarController.tabBar.hidden = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _imageArray = [NSMutableArray new];
    _after_ImageArry = [NSMutableArray  new];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBarHidden = YES;
    //    self.navigationItem.title = @"开始服务";
    //    self.navigationController.navigationBar.barTintColor = [UIColor orangeColor];
    
    
    _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Width, kRelativeHeight(80))];
    _headView.backgroundColor = [UIColor greenColor];
    [self.view addSubview:_headView];
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(40), kRelativeWidth(30), kRelativeHeight(30))];
    [btn setImage:[UIImage imageNamed:@"backwhite"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    [_headView addSubview:btn];
    
    UILabel * textLabel = [[UILabel alloc]init];
    textLabel.center = CGPointMake(Width/2, kRelativeHeight(50));
    textLabel.bounds = CGRectMake(0, 0, kRelativeWidth(200), kRelativeHeight(40));
    textLabel.textAlignment = NSTextAlignmentCenter;
    textLabel.textColor = [UIColor whiteColor];
    textLabel.text = @"开始服务";
    textLabel.font = [UIFont systemFontOfSize:25];
    [_headView addSubview:textLabel];
    [self createView];
    
    // Do any additional setup after loading the view.
}
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)createView
{
    UIView * mainView = [[UIView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(80), Width, Height-kRelativeHeight(80))];
    mainView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:mainView];
    
    UILabel * serviceLabel =[[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(5), kRelativeWidth(80), kRelativeHeight(30))];
    serviceLabel.textAlignment =NSTextAlignmentLeft;
    serviceLabel.textColor = [UIColor grayColor];
    serviceLabel.text = @"订单号:";
    serviceLabel.font = [UIFont systemFontOfSize:16];
    [mainView addSubview:serviceLabel];
    
    // 订单号
    UILabel * numLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(75), kRelativeHeight(5), kRelativeWidth(240), kRelativeHeight(30))];
    numLabel.textAlignment =NSTextAlignmentLeft;
    numLabel.textColor = [UIColor grayColor];
    numLabel.text = _orderStr;
    numLabel.font = [UIFont systemFontOfSize:16];
    [mainView addSubview:numLabel];
    
    UIImageView * headView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(40), kRelativeWidth(85), kRelativeHeight(100))];
    headView.backgroundColor = [UIColor redColor];
    NSURL * url = [NSURL URLWithString:_headImageStr];
    headView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
    [mainView addSubview:headView];
    
    UILabel  * nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(105), kRelativeHeight(40), kRelativeWidth(120), kRelativeHeight(30))];
    nameLabel.textAlignment =NSTextAlignmentLeft;
    nameLabel.textColor = [UIColor blackColor];
    nameLabel.text = _fuwuStr;
    //    nameLabel.backgroundColor = [UIColor redColor];
    nameLabel.font = [UIFont systemFontOfSize:kRelativeWidth(18)];
    [mainView addSubview:nameLabel];
    
    _fstrtLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(105), kRelativeHeight(75), kRelativeWidth(ScreenWidth-100), kRelativeHeight(20))];
    _fstrtLabel.textAlignment = NSTextAlignmentLeft;
    _fstrtLabel.textColor = [UIColor blackColor];
    //    _fstrtLabel.backgroundColor = [UIColor brownColor];
    _fstrtLabel.font = [UIFont systemFontOfSize:kRelativeWidth(16)];
    _fstrtLabel.text         = _titleStr;
    [mainView addSubview:_fstrtLabel];
    
    _sexImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(105), kRelativeHeight(100), kRelativeWidth(20), kRelativeHeight(20))];
    //    _sexImageView.backgroundColor = [UIColor grayColor];
    _sexImageView.image = [UIImage imageNamed:@"icon_teacher.png"];
    [mainView addSubview:_sexImageView];
    
    _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(125), kRelativeHeight(100), kRelativeWidth(50), kRelativeHeight(20))];
    _nameLabel.textAlignment = NSTextAlignmentLeft;
    _nameLabel.textColor = [UIColor blackColor];
    _nameLabel.font = [UIFont systemFontOfSize:kRelativeWidth(15)];
    [mainView addSubview:_nameLabel];
    
    _telLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(125), kRelativeHeight(100), kRelativeWidth(120), kRelativeHeight(20))];
    _telLabel.layer.masksToBounds = YES;
    _telLabel.layer.cornerRadius = kRelativeWidth(12);
    _telLabel.backgroundColor = [UIColor colorWithRed:0/256.0 green:234/256.0 blue:116/256.0 alpha:1];
    _telLabel.textAlignment = NSTextAlignmentCenter;
    _telLabel.textColor = [UIColor whiteColor];
    _telLabel.text          = _phoneStr;
    _telLabel.font = [UIFont systemFontOfSize:kRelativeWidth(14)];
    [mainView addSubview:_telLabel];
    
    UILabel * ddLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(105), kRelativeHeight(125), kRelativeWidth(80), kRelativeHeight(40))];
    ddLabel.textAlignment = NSTextAlignmentLeft;
    ddLabel.textColor = [UIColor blackColor];
    ddLabel.text = @"服务地址:";
    ddLabel.font = [UIFont systemFontOfSize:kRelativeWidth(16)];
    [mainView addSubview:ddLabel];
    
    _adrLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(175), kRelativeHeight(125), kRelativeWidth(ScreenWidth-170), kRelativeHeight(40))];
    _adrLabel.textAlignment = NSTextAlignmentLeft;
    _adrLabel.textColor =[UIColor blackColor];
    _adrLabel.numberOfLines = 2;
    _adrLabel.font = [UIFont systemFontOfSize:kRelativeWidth(16)];
    _adrLabel.text  = _addressStr;
    [mainView addSubview:_adrLabel];
    
    for (int i =0 ; i<2; i++)
    {
        float height = kRelativeHeight(112);
        NSArray * nameArray = [NSArray arrayWithObjects:@"服务前:",@"服务后:", nil];
        UILabel * servicebfLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(175)+height*i, kRelativeWidth(90), kRelativeHeight(40))];
        servicebfLabel.textAlignment = NSTextAlignmentLeft;
        servicebfLabel.textColor = [UIColor grayColor];
        servicebfLabel.backgroundColor = [UIColor clearColor];
        servicebfLabel.text = [nameArray objectAtIndex:i];
        servicebfLabel.font = [UIFont systemFontOfSize:kRelativeWidth(18)];
        [mainView addSubview:servicebfLabel];
        
        
        //        //1、得到默认布局高度（唯一获取高度方法）
        //        CGFloat height_Photo = [ACSelectMediaView defaultViewHeight];
        
        if (i == 0)
        {
            UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, kRelativeHeight(205), self.view.bounds.size.width, kRelativeHeight(80))];
            [mainView addSubview:bgView];
            
            if ([_status isEqualToString:@"3"])
            {
                for (int j = 0; j<_before_ImageArry.count; j++)
                {
                    UIImageView *  imageV = [[UIImageView alloc]initWithFrame:CGRectMake(10+kRelativeWidth(105)*j, 0, kRelativeWidth(75), kRelativeHeight(75))];
                    imageV.userInteractionEnabled = YES;
                    imageV.tag = 10+j;
                    [imageV sd_setImageWithURL:[NSURL URLWithString:_before_ImageArry[j]]];
                    [bgView addSubview:imageV];
                    UITapGestureRecognizer *  tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(picBrowster:)];
                    [imageV addGestureRecognizer:tap];
                }
            }
            else{
                WSImagePickerConfig *config = [WSImagePickerConfig new];
                config.itemSize = CGSizeMake(kRelativeWidth(75),kRelativeHeight(75));
                config.photosMaxCount = 4;
                WSImagePickerView *pickerView = [[WSImagePickerView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 0) config:config];
                //Height changed with photo selection
                __weak typeof(self) weakSelf = self;
                pickerView.viewHeightChanged = ^(CGFloat height) {
                    //        weakSelf.photoViewHieghtConstraint.constant = height;
                    _imageArray  = self.pickerView.photosArray;
                    NSLog(@"%@---1--",_imageArray);
                    
                    [weakSelf.view setNeedsLayout];
                    [weakSelf.view layoutIfNeeded];
                };
                pickerView.navigationController = self.navigationController;
                [bgView addSubview:pickerView];
                self.pickerView = pickerView;
                //refresh superview height
                [pickerView refreshImagePickerViewWithPhotoArray:nil];
            }
            
        }else if (i == 1){
            
            UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, kRelativeHeight(315), self.view.bounds.size.width, kRelativeHeight(80))];
            [mainView addSubview:bgView];
            
            WSImagePickerConfig *config = [WSImagePickerConfig new];
            config.itemSize = CGSizeMake(kRelativeWidth(75),kRelativeHeight(75));
            config.photosMaxCount = 4;
            WSImagePickerView *pickerView = [[WSImagePickerView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 0) config:config];
            //Height changed with photo selection
            __weak typeof(self) weakSelf = self;
            pickerView.viewHeightChanged = ^(CGFloat height) {
                //        weakSelf.photoViewHieghtConstraint.constant = height;
                _after_ImageArry  = self.after_pickerView.photosArray;
                NSLog(@"%@-2---",_after_ImageArry);
                
                [weakSelf.view setNeedsLayout];
                [weakSelf.view layoutIfNeeded];
            };
            pickerView.navigationController = self.navigationController;
            [bgView addSubview:pickerView];
            self.after_pickerView = pickerView;
            //refresh superview height
            [pickerView refreshImagePickerViewWithPhotoArray:nil];
            
        }
        
    }
    UIButton * serviceBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    serviceBtn.backgroundColor = [UIColor blueColor];
    [serviceBtn setTitle:@"开始服务" forState:UIControlStateNormal];
    [serviceBtn setTintColor:[UIColor whiteColor]];
    [serviceBtn setTitle:@"完成服务" forState:UIControlStateSelected];
    [serviceBtn setFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(430), Width-kRelativeWidth(20), kRelativeHeight(60))];
    [mainView addSubview:serviceBtn];
    [serviceBtn addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
    
    if ([_status isEqualToString:@"3"]) {
        serviceBtn.selected = YES;
    }
    
    
    UIButton * navigationBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    navigationBtn.backgroundColor = [UIColor blueColor];
    [navigationBtn setTitle:@"开始导航" forState:UIControlStateNormal];
    [navigationBtn setTintColor:[UIColor whiteColor]];
    [navigationBtn setFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(510), Width-kRelativeWidth(20), kRelativeHeight(60))];
    [mainView addSubview:navigationBtn];
    [navigationBtn addTarget:self action:@selector(btnnavigationclick) forControlEvents:UIControlEventTouchUpInside];
}

//、、  开始服务
-(void)btnclick:(UIButton *)btn
{
    //    if (_phoneView.tag == 100) {
    //        if (_isUpLoadImage == NO) {
    //            btn.selected = NO;
    //        }else
    //        {
    //            btn.selected = YES;
    //        }
    //    }else
    //    {
    //        if (_isUpLoadImage == NO) {
    //            btn.selected = NO;
    //        }else{
    //            btn.selected = YES;
    //        }
    //    }
    
    
    
    if ([_status isEqualToString:@"3"]) {
        NSLog(@"完成服务");
        
        if (_after_ImageArry.count == 0) {
            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"请至少上传一张图片" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alert show];
        }else{
            AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
            manager.responseSerializer = [AFHTTPResponseSerializer serializer];
            NSMutableDictionary * servicedic = [[NSMutableDictionary alloc]init];
            [servicedic setObject:_orderStr forKey:@"s_order_num"];
            
            //   NSString * urlString = @"http://106.15.0.128/working/index.php/Admin/ApiS/s_pic_after";
            NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_pic_after";
            
            [manager POST:urlString parameters:servicedic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                for (int i = 0; i < _after_ImageArry.count; i++) {
                    
                    NSData *imageData = UIImageJPEGRepresentation([_after_ImageArry objectAtIndex:i], 0.7f);
                    //            //    、获取时间
                    NSDate * date = [NSDate date];
                    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
                    [dateFormatter setDateFormat:@"yyyyMMddHHmmss"];
                    NSString *dateString = [dateFormatter stringFromDate:date];
                    NSString * picNmae = [NSString stringWithFormat:@"%@.png",dateString];
                    //、 拼接图片路径（代码写的）
                    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
                    //    NSLog(@"&&2&&path&&&%@",documentPath);
                    //最终路径
                    NSString * title  = [NSString stringWithFormat:@"图片%d",i];
                    NSString *imagePath = [documentPath stringByAppendingString:[NSString stringWithFormat:@"/%@",title]];
                    // 、 data写入沙盒
                    [imageData writeToFile:imagePath atomically:YES];
                    //、  生成路径URL
                    NSURL *url=[NSURL fileURLWithPath:imagePath];
                    [formData appendPartWithFileURL:url name:@"pic[]" fileName:picNmae mimeType:@"image/png" error:nil];
                }
                
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
                NSDictionary * Dict  = dic[@"status"];
                if ([Dict[@"status"] isEqualToString:@"上传图片成功"]) {
                    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"图片上传成功" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                    [alert show];
                    
                }else{
                    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"图片上传失败" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                    [alert show];                }
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error);
            }];
        }
        
    }else{
        NSLog(@"开始服务");
        
        if (_imageArray.count == 0) {
            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"请至少上传一张图片" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alert show];
        }else{
            AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
            manager.responseSerializer = [AFHTTPResponseSerializer serializer];
            NSMutableDictionary * servicedic = [[NSMutableDictionary alloc]init];
            [servicedic setObject:_orderStr forKey:@"s_order_num"];
            
            //  NSString * urlString = @"http://106.15.0.128/working/index.php/Admin/ApiS/s_pic_before";
            NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_pic_before";
            
            [manager POST:urlString parameters:servicedic constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                
                for (int i = 0; i < _imageArray.count; i++) {
                    
                    NSData *imageData = UIImageJPEGRepresentation([_imageArray objectAtIndex:i], 0.7f);
                    //            //    、获取时间
                    NSDate * date = [NSDate date];
                    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
                    [dateFormatter setDateFormat:@"yyyyMMddHHmmss"];
                    NSString *dateString = [dateFormatter stringFromDate:date];
                    NSString * picNmae = [NSString stringWithFormat:@"%@.png",dateString];
                    //、 拼接图片路径（代码写的）
                    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
                    //    NSLog(@"&&2&&path&&&%@",documentPath);
                    //最终路径
                    NSString * title  = [NSString stringWithFormat:@"图片%d",i];
                    NSString *imagePath = [documentPath stringByAppendingString:[NSString stringWithFormat:@"/%@",title]];
                    // 、 data写入沙盒
                    [imageData writeToFile:imagePath atomically:YES];
                    //、  生成路径URL
                    NSURL *url=[NSURL fileURLWithPath:imagePath];
                    [formData appendPartWithFileURL:url name:@"pic[]" fileName:picNmae mimeType:@"image/png" error:nil];
                }
            } progress:^(NSProgress * _Nonnull uploadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                //                NSString * str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
                //                NSLog(@"%@",str);
                NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
                NSDictionary * Dict  = dic[@"status"];
                if ([Dict[@"status"] isEqualToString:@"上传图片成功"]) {
                    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"图片上传成功" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                    [alert show];
                }else{
                    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"图片上传失败" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                    [alert show];
                }
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error);
            }];
            
        }
        
    }
    
}

//、 导航
-(void)btnnavigationclick
{
    self.hidesBottomBarWhenPushed = YES;
    NaviController * navi = [[NaviController alloc]init];
    navi.latitude  = [_lat doubleValue];
    navi.longitude = [_lng doubleValue];
    [self.navigationController pushViewController:navi animated:YES];
    self.hidesBottomBarWhenPushed = NO;
    
}
// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

-(void)picBrowster:(UITapGestureRecognizer*)tap{
    NSLog(@"%ld",tap.view.tag-10);
    __weak typeof(self) weakSelf = self;
    [ImageBrowserViewController show:self type:PhotoBroswerVCTypeModal index:tap.view.tag-10 imagesBlock:^NSArray *{
        return weakSelf.before_ImageArry;
    }];

    
}


#pragma mark=================== 返回
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (buttonIndex == 0) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}


@end
