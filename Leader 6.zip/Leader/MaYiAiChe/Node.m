//
//  Node.m
//  MaYiAiChe
//
//  Created by xc on 17/2/15.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "Node.h"

@implementation Node
-(instancetype)initWithParentId:(int)parentId nodeId:(int)nodeId name:(NSString *)name depath:(int)depath expand:(BOOL)expand
{
    self = [self init];
    if (self) {
        self.parenrId = parentId;
        self.nodeId = nodeId;
        self.name = name;
        self.depth = depath;
        self.expand = expand;
    }
    return self;
}
@end
