//
//  FinishServiceTableViewCell.m
//  MaYiAiChe
//
//  Created by xc on 17/1/9.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "FinishServiceTableViewCell.h"
#import "StarView.h"
#define Width [UIScreen mainScreen].bounds.size.width
#define Height [UIScreen mainScreen].bounds.size.height

@implementation FinishServiceTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        _fstLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(5), kRelativeWidth(120), kRelativeHeight(30))];
        _fstLabel.textAlignment = NSTextAlignmentLeft;
        _fstLabel.textColor = [UIColor grayColor];
        //        _fstLabel.adjustsFontSizeToFitWidth = YES;
        _fstLabel.text = @"完成时间：";
        _fstLabel.font = [UIFont systemFontOfSize:12];
        _fstLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_fstLabel];
        
        _timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(100), kRelativeHeight(5), kRelativeHeight(200), kRelativeHeight(30))];
        _timeLabel.textAlignment = NSTextAlignmentLeft;
        _timeLabel.textColor = [UIColor grayColor];
        //        _fstLabel.adjustsFontSizeToFitWidth = YES;
        // _fstLabel.text = @"添加时间：";
        _timeLabel.font = [UIFont systemFontOfSize:12];
        _timeLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_timeLabel];
        
        _headLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(140), kRelativeHeight(40), kRelativeWidth(150), kRelativeHeight(30))];
        _headLabel.textAlignment = NSTextAlignmentLeft;
        _headLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:_headLabel];
        
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(40), kRelativeWidth(100), kRelativeHeight(110))];
        _headImageView.backgroundColor = [UIColor grayColor];
        [self.contentView addSubview:_headImageView];
        
        _fstrtLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(140), kRelativeHeight(75), kRelativeWidth(ScreenWidth-130), kRelativeHeight(20))];
        _fstrtLabel.textAlignment = NSTextAlignmentLeft;
        _fstrtLabel.textColor = [UIColor blackColor];
        _fstrtLabel.font = [UIFont systemFontOfSize:14];
        _fstrtLabel.numberOfLines =2;
        [self.contentView addSubview:_fstrtLabel];
        
        _sexImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(140), kRelativeHeight(100), kRelativeWidth(20), kRelativeHeight(20))];
        //        _sexImageView.backgroundColor = [UIColor grayColor];
        _sexImageView.image = [UIImage imageNamed:@"icon_teacher.png"];
        [self.contentView addSubview:_sexImageView];
        
        _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(140), kRelativeHeight(130), kRelativeWidth(300), kRelativeHeight(20))];
        _nameLabel.textAlignment = NSTextAlignmentLeft;
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_nameLabel];
        
        _telLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(165), kRelativeHeight(100), kRelativeWidth(100), kRelativeHeight(20))];
        _telLabel.layer.masksToBounds = YES;
        _telLabel.layer.cornerRadius = 10;
        _telLabel.backgroundColor = [UIColor colorWithRed:0/256.0 green:234/256.0 blue:116/256.0 alpha:1];
        _telLabel.textAlignment = NSTextAlignmentCenter;
        _telLabel.textColor = [UIColor whiteColor];
        _telLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_telLabel];
        
        UILabel * ddLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(160), kRelativeWidth(40), kRelativeHeight(10))];
        ddLabel.textAlignment = NSTextAlignmentLeft;
        ddLabel.textColor = [UIColor blackColor];
        ddLabel.adjustsFontSizeToFitWidth = YES;
        ddLabel.text = @"地址:";
        ddLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:ddLabel];
        
        _adrLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(70), kRelativeHeight(155), kRelativeWidth(300), kRelativeHeight(20))];
        _adrLabel.textAlignment = NSTextAlignmentLeft;
        _adrLabel.textColor =[UIColor blackColor];
        _adrLabel.font = [UIFont systemFontOfSize:14];
        _adrLabel.numberOfLines = 2;
        [self.contentView addSubview:_adrLabel];
   
        /*
        _fstLabel = [[UILabel alloc]initWithFrame:CGRectMake(10,  5,  120,  30)];
        _fstLabel.textAlignment = NSTextAlignmentLeft;
        _fstLabel.textColor = [UIColor grayColor];
        //        _fstLabel.adjustsFontSizeToFitWidth = YES;
        _fstLabel.text = @"完成时间：";
        _fstLabel.font = [UIFont systemFontOfSize:12];

        [self.contentView addSubview:_fstLabel];
        
        _timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(70,  5,200, 30)];
        _timeLabel.textAlignment = NSTextAlignmentLeft;
        _timeLabel.textColor = [UIColor grayColor];
        //        _fstLabel.adjustsFontSizeToFitWidth = YES;
        // _fstLabel.text = @"添加时间：";
        _timeLabel.font = [UIFont systemFontOfSize:12];

        [self.contentView addSubview:_timeLabel];
        
        _headLabel = [[UILabel alloc]initWithFrame:CGRectMake(140,40,150,30)];
        _headLabel.textAlignment = NSTextAlignmentLeft;
        _headLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:_headLabel];
        
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(20,  40,  100,  110)];
        _headImageView.backgroundColor = [UIColor grayColor];
        [self.contentView addSubview:_headImageView];
        
        _fstrtLabel = [[UILabel alloc]initWithFrame:CGRectMake(140,  75,ScreenWidth-130,20)];
        _fstrtLabel.textAlignment = NSTextAlignmentLeft;
        _fstrtLabel.textColor = [UIColor blackColor];
        _fstrtLabel.font = [UIFont systemFontOfSize:14];
        _fstrtLabel.numberOfLines =2;
        [self.contentView addSubview:_fstrtLabel];
        
        _sexImageView = [[UIImageView alloc]initWithFrame:CGRectMake(140, 100,  20,20)];
        //        _sexImageView.backgroundColor = [UIColor grayColor];
        _sexImageView.image = [UIImage imageNamed:@"icon_teacher.png"];
        [self.contentView addSubview:_sexImageView];
        
        _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(140, 130,300,20)];
        _nameLabel.textAlignment = NSTextAlignmentLeft;
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_nameLabel];
        
        _telLabel = [[UILabel alloc]initWithFrame:CGRectMake(165, 100,100, 20)];
        _telLabel.layer.masksToBounds = YES;
        _telLabel.layer.cornerRadius = 10;
        _telLabel.backgroundColor = [UIColor colorWithRed:0/256.0 green:234/256.0 blue:116/256.0 alpha:1];
        _telLabel.textAlignment = NSTextAlignmentCenter;
        _telLabel.textColor = [UIColor whiteColor];
        _telLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_telLabel];
        
        UILabel * ddLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 160, 40,  10)];
        ddLabel.textAlignment = NSTextAlignmentLeft;
        ddLabel.textColor = [UIColor blackColor];
        ddLabel.adjustsFontSizeToFitWidth = YES;
        ddLabel.text = @"地址:";
        ddLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:ddLabel];
        
        _adrLabel = [[UILabel alloc]initWithFrame:CGRectMake(  70,155,  300 ,   20 )];
        _adrLabel.textAlignment = NSTextAlignmentLeft;
        _adrLabel.textColor =[UIColor blackColor];
        _adrLabel.font = [UIFont systemFontOfSize:14];
        _adrLabel.numberOfLines = 2;
        [self.contentView addSubview:_adrLabel];
         */
        
     }
    return self;
}


-(void)setModel:(ScheduleModel *)model{
    _model = model;
    _headLabel.text = model.fuwu_type;
    NSURL * url = [NSURL URLWithString:model.xg_logo];
    _headImageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
    _fstrtLabel.text = model.order_title;
    _nameLabel.text =model.consumer_car;
    _telLabel.text = model.phone;
    _adrLabel.text = model.address;
    //    _sexImageView.image = titleImageView;
    // 将时间戳转成时间
    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm"];
    NSDate * date = [NSDate dateWithTimeIntervalSince1970:[model.finish_service_time doubleValue]];
    //    NSLog(@"--%@--",date);
    NSString * stt = [dateFormatter stringFromDate:date];
    _timeLabel.text = stt;
//    NSLog(@"----------------%@-----------------%@--------------%@-------",model.xg_logo,model.order_status,model.lat);
    
}


//-(void)reloadViewWithName:(NSString *)OrderID srvnameLabel:(NSString *)srvnameLabel textLabel:(NSString *)textLabel nameLabel:(NSString *)nameLabel telLabel:(NSString *)telLabel adrLabel:(NSString *)adrLabel  OpinionLabel:(NSString *)opinionLabel headImage:(UIImage *)headImage
//{
////    _oradeId.text = OrderID;
////    _srvnameLabel.text = srvnameLabel;
////    _textLabel.text = textLabel;
////    _nameLabel.text = nameLabel;
////    _telLabel.text = textLabel;
////    _adrLabel.text = adrLabel;
////    _opinionLabel.text = opinionLabel;
////    _headImageView.image = headImage;
//}
@end
