//
//  LinkViewController.m
//  MaYiAiChe
//
//  Created by xc on 17/1/3.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "LinkViewController.h"
#import "LinkTableViewCell.h"
#import "LinksViewController.h"
#import "EwmViewController.h"
#import "BuyShareController.h"
#define Width [UIScreen mainScreen].bounds.size.width
#define Height [UIScreen mainScreen].bounds.size.height
@interface LinkViewController ()<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate,MyCellDelegate>
{
    UIView * _headView;
    UITableView * _listTableView;
    UITextField * _seachTextField;
}

@end

@implementation LinkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:238.0/255 green:238.0/255 blue:238.0/255 alpha:1];
    self.navigationController.navigationBar.hidden = YES;
    
    _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Width, kRelativeHeight(80))];
    _headView.backgroundColor = [UIColor greenColor];
    [self.view addSubview:_headView];
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(40), kRelativeWidth(30), kRelativeHeight(30))];
    [btn setImage:[UIImage imageNamed:@"backwhite"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = [UIColor clearColor];
    [_headView addSubview:btn];
    
    UIView * seachLabel = [[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(50), kRelativeHeight(40), Width-kRelativeWidth(60), kRelativeHeight(30))];
    seachLabel.backgroundColor = [UIColor whiteColor];
    seachLabel.layer.masksToBounds =YES;
    seachLabel.layer.cornerRadius = 5;
    [_headView addSubview:seachLabel];
    
    UIImageView * seachImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(5), kRelativeHeight(5), kRelativeWidth(30), kRelativeHeight(20))];
    seachImageView.backgroundColor = [UIColor redColor];
    seachImageView.image = [UIImage imageNamed:@""];
    [seachLabel addSubview:seachImageView];
    
    
    _seachTextField = [[UITextField alloc]initWithFrame:CGRectMake(kRelativeWidth(40), kRelativeHeight(5), Width-kRelativeWidth(100), kRelativeWidth(25))];
    _seachTextField.backgroundColor = [UIColor whiteColor];
    _seachTextField.layer.masksToBounds = YES;
    _seachTextField.layer.cornerRadius = 5;
    _seachTextField.placeholder = @"搜索";
    _seachTextField.font = [UIFont systemFontOfSize:18];
    _seachTextField.textColor =[UIColor blackColor];
    _seachTextField.adjustsFontSizeToFitWidth = YES;
    _seachTextField.textAlignment = NSTextAlignmentLeft;
    _seachTextField.keyboardType = UIKeyboardTypeDefault;
    _seachTextField.returnKeyType = UIReturnKeyDone;
    _seachTextField.clearButtonMode = UITextFieldViewModeAlways;
    _seachTextField.clearsOnBeginEditing = YES;
    _seachTextField.delegate = self;
    [seachLabel addSubview:_seachTextField];
    [self createTableView];
    
    UIButton * pushbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    pushbtn.backgroundColor = [UIColor clearColor];
    pushbtn.frame = CGRectMake(kRelativeHeight(25), ScreenHeight-kRelativeHeight(70), ScreenWidth-kRelativeWidth(50), kRelativeHeight(60));
    [pushbtn addTarget:self action:@selector(pushbclick) forControlEvents:UIControlEventTouchUpInside];
    UILabel * titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, pushbtn.frame.size.width, pushbtn.frame.size.height)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [UIColor grayColor];
    titleLabel.text = @"购买优惠券";
    titleLabel.font = [UIFont systemFontOfSize:20];
    titleLabel.backgroundColor = [UIColor clearColor];
    [pushbtn addSubview:titleLabel];
    [self.view addSubview:pushbtn];
    
    // Do any additional setup after loading the view.
}
-(void)pushbclick
{
    [self.navigationController pushViewController:[BuyShareController new] animated:YES];
}
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
    
}
-(void)createTableView
{
    _listTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(80), Width, Height-kRelativeHeight(200))];
    _listTableView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_listTableView];
    _listTableView.dataSource = self;
    _listTableView.delegate = self;
    _listTableView.bounces = NO;
    _listTableView.showsHorizontalScrollIndicator = YES;
    [_listTableView  reloadData];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cellId = @"cellCusID";
    LinkTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[LinkTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        for (int i = 0; i<2; i++) {
            NSArray * titleArray = [NSArray arrayWithObjects:@"获取二维码",@"获取链接", nil];
            UIColor *c1 = [UIColor orangeColor];
            UIColor * c2 = [UIColor whiteColor];
            NSArray * colorArray = [NSArray arrayWithObjects:c2,c1, nil];
            NSArray * clArray = [NSArray arrayWithObjects:c1,c2, nil];
            float height = 50;
            UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(Width-kRelativeWidth(110), kRelativeHeight(10)+height*i, kRelativeWidth(100), kRelativeHeight(30))];
            [btn setTitle:[titleArray objectAtIndex:i] forState:UIControlStateNormal];
            [btn setTitleColor:[colorArray objectAtIndex:i] forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
            btn.backgroundColor = [clArray objectAtIndex:i];
            btn.layer.masksToBounds = YES;
            btn.layer.cornerRadius = 2;
            btn.layer.borderColor = [[UIColor orangeColor]CGColor];
            btn.layer.borderWidth = 1;
            btn.tag = 100+i;
            [cell.contentView addSubview:btn];
            
        }
        

        cell.delegate = self;
    }
    NSString * headLabel;
    NSString * priceLabel;
    UIImage *  headImage;
    NSArray * headArray = [NSArray arrayWithObjects:@"xx商品代金券",@"xx商代金券",@"xx商品金券",@"xx商品代券", nil];
    NSArray * priceArray = [NSArray arrayWithObjects:@"¥XX",@"¥XXx",@"¥XqX",@"¥XwX", nil];
    NSArray * headImageArray = [NSArray arrayWithObjects:@"1",@"2", @"3", @"4",  nil];
    for (int i = 0; i<(indexPath.row+1); i++) {
        headLabel = [headArray objectAtIndex:i];
        priceLabel = [priceArray objectAtIndex:i];
        headImage = [UIImage imageNamed:[headImageArray objectAtIndex:i]];
    }
    [cell reloadViewName:headLabel priceLabel:priceLabel headImageView:headImage];
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}
-(void)btnclick:(UIButton *)btn
{
    if (btn.tag == 100) {
        [self.navigationController pushViewController:[EwmViewController new] animated:YES];
    }else
    {
        [self.navigationController pushViewController:[LinksViewController new] animated:YES];
    }
}
//-(void)cellDidClickWithBtn:(UIButton *)selectedBtn
//{
//    if (selectedBtn.tag == 100) {
//        [self.navigationController pushViewController:[EwmViewController new] animated:YES];
//    }else
//    {
//        [self.navigationController pushViewController:[LinksViewController new] animated:YES];
//    }
//}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
