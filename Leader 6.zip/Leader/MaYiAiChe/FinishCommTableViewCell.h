//
//  FinishCommTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 17/1/9.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FinishCommTableViewCell : UITableViewCell

@end
