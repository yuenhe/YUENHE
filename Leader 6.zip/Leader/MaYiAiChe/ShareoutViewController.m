//
//  ShareoutViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/23.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "ShareoutViewController.h"

@interface ShareoutViewController ()
{
    UIView *_mynavigationBar;
    UIButton * _backLabel;
    UILabel * _titleLabel;
}

@end

@implementation ShareoutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];
    self.navigationController.navigationBar.hidden = YES;
    //自定义navigationbar
    _mynavigationBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 64)];
    _mynavigationBar.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_mynavigationBar];
    //返回item
    _backLabel = [[UIButton alloc]initWithFrame:CGRectMake(5, 25, 30, 30)];
    _backLabel.backgroundColor = [UIColor clearColor];
    _backLabel.tag = 100;
    [_backLabel setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [_backLabel addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigationBar addSubview:_backLabel];
    
    //title
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-100, 22, 200, 40)];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text =@"股东撤资";
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor blackColor];
    _titleLabel.font = [UIFont systemFontOfSize:25];
    [_mynavigationBar addSubview:_titleLabel];
    //创建店铺图片
    UIImageView * potoImageView = [[UIImageView alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-50, 120, 100, 100)];
    potoImageView.backgroundColor = [UIColor lightGrayColor];
    potoImageView.layer.masksToBounds = YES;
    potoImageView.layer.cornerRadius = 50;
    [self.view addSubview:potoImageView];
    
    [self createMenuView];
    //确认按钮
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setFrame:CGRectMake(20, 550, self.view.frame.size.width-40, 40)];
    [btn setTitle:@"我要撤资" forState:UIControlStateNormal];
    [btn setTintColor:[UIColor whiteColor]];
    btn.backgroundColor = [UIColor greenColor];
    [btn addTarget:self action:@selector(btncutclick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];

    
    
    // Do any additional setup after loading the view.
}
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//创建view
-(void)createMenuView
{
    //创建view
    UIView * menuView = [[UIView alloc]initWithFrame:CGRectMake(20, 250, self.view.frame.size.width-40, 250)];
    menuView.backgroundColor = [UIColor whiteColor];
    menuView.layer.borderWidth = 1.0;
    menuView.layer.borderColor = [[UIColor greenColor]CGColor];
    [self.view addSubview:menuView];
    NSArray * titleArray = [NSArray arrayWithObjects:@"店铺名称",@"店铺地址",@"撤出资金", nil];
    NSArray * textArray = [NSArray arrayWithObjects:@"xxxxxxx",@"xxxxxxx",@"¥1000,000", nil];
    //创建店铺名称，地址，撤出资金
    for (int i = 0; i<3; i++) {
        float height = 80;
        UILabel * titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(40, 20+height*i, 80, 30)];
        titleLabel.textAlignment = NSTextAlignmentLeft;
        titleLabel.textColor = [UIColor lightGrayColor];
        titleLabel.font = [UIFont systemFontOfSize:20];
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.text = [titleArray objectAtIndex:i];
        [menuView addSubview:titleLabel];
        
        UILabel * textLabel = [[UILabel alloc]initWithFrame:CGRectMake(130, 20+height*i, 200, 30)];
        textLabel.textAlignment = NSTextAlignmentLeft;
        textLabel.backgroundColor = [UIColor clearColor];
        textLabel.font = [UIFont systemFontOfSize:20];
        if (i == 2) {
            textLabel.textColor = [UIColor orangeColor];
        }else{
            textLabel.textColor = [UIColor blackColor];
        }
        textLabel.text =[textArray objectAtIndex:i];
        [menuView addSubview:textLabel];
    }
    
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
