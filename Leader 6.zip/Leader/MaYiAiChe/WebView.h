//
//  WebView.h
//  MaYiAiChe
//
//  Created by xc on 17/3/7.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebView : UIViewController
@property(nonatomic,strong)NSDictionary * data;     // 数据源

@end
