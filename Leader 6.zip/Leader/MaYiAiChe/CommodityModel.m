//
//  CommodityModel.m
//  MaYiAiChe
//
//  Created by xc on 17/1/20.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "CommodityModel.h"

@implementation CommodityModel

@end
