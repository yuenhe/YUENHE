//
//  EditSelfViewController.m
//  MaYiAiChe
//
//  Created by xc on 17/1/4.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "EditSelfViewController.h"
#import "ConstellationView.h"
#define Width [UIScreen mainScreen].bounds.size.width
#define Height [UIScreen mainScreen].bounds.size.height
@interface EditSelfViewController ()<UITextFieldDelegate,MyBoxDelegate>
{
    UIView * _headView;
}

@end

@implementation EditSelfViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor lightGrayColor];
    
    mainScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(60), Width, Height-kRelativeWidth(80))];
    mainScrollView.delegate = self;
    mainScrollView.contentSize = CGSizeMake(Width, kRelativeHeight(640));
    mainScrollView.pagingEnabled = NO;
    mainScrollView.scrollEnabled = YES;
    mainScrollView.bounces = NO;
    mainScrollView.backgroundColor = [UIColor lightGrayColor];
    mainScrollView.showsHorizontalScrollIndicator = YES;
    [self.view addSubview:mainScrollView];
    
    _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Width, kRelativeHeight(80))];
    _headView.backgroundColor = [UIColor greenColor];
    [self.view addSubview:_headView];
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(40), kRelativeWidth(30), kRelativeHeight(30))];
    [btn setImage:[UIImage imageNamed:@"backwhite"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = [UIColor clearColor];
    [_headView addSubview:btn];
    
    UILabel * textLabel = [[UILabel alloc]init];
    textLabel.center = CGPointMake(Width/2, kRelativeHeight(50));
    textLabel.bounds = CGRectMake(0, 0, kRelativeWidth(200), kRelativeHeight(40));
    textLabel.textAlignment = NSTextAlignmentCenter;
    textLabel.textColor = [UIColor whiteColor];
    textLabel.text = @"编辑个人信息";
    textLabel.font = [UIFont systemFontOfSize:25];
    [_headView addSubview:textLabel];
    
    UIButton * backBtn = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(560), Width-kRelativeWidth(40), kRelativeHeight(60))];
    backBtn.backgroundColor = [UIColor colorWithRed:36.0/255.0 green:174.0/255.0 blue:237.0/255.0 alpha:1];
    [backBtn setTitle:@"提交" forState:UIControlStateNormal];
    backBtn.titleLabel.font = [UIFont systemFontOfSize:25];
    [backBtn setTintColor:[UIColor whiteColor]];
    [backBtn addTarget:self action:@selector(removeBack) forControlEvents:UIControlEventTouchUpInside];
    [mainScrollView addSubview:backBtn];


    [self createFstView];
    [self createSecView];
    
    // Do any additional setup after loading the view.
}
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)createFstView
{
    
    UIView * mainView = [[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(20), Width-kRelativeWidth(40), kRelativeHeight(240))];
    mainView.backgroundColor = [UIColor whiteColor];
    [mainScrollView addSubview:mainView];
    
    NSArray * nameArray = [NSArray arrayWithObjects:@"昵称",@"手机号",@"兴趣",@"星座",@"毕业学校",@"就职公司", nil];
    for (int i = 0; i<6; i++) {
        float height = kRelativeHeight(40);
        UILabel * nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(5, 5+height*i, kRelativeWidth(80), kRelativeHeight(30))];
        nameLabel.textAlignment  = NSTextAlignmentLeft;
        nameLabel.textColor = [UIColor lightGrayColor];
        nameLabel.backgroundColor = [UIColor clearColor];
        nameLabel.font = [UIFont systemFontOfSize:20];
        nameLabel.text = [nameArray objectAtIndex:i];
        [mainView addSubview:nameLabel];
        
    }
    for (int t =0; t<5; t++) {
        float height = kRelativeHeight(40);
        UIImageView * lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, kRelativeWidth(39)+height*t, Width-kRelativeHeight(40), 1)];
        lineImageView.backgroundColor = [UIColor lightGrayColor];
        [mainView addSubview:lineImageView];
    }
    UILabel * sexLabel = [[UILabel alloc]initWithFrame:CGRectMake(Width/2+5, 5, kRelativeWidth(40), kRelativeHeight(30))];
    sexLabel.textAlignment  = NSTextAlignmentLeft;
    sexLabel.textColor = [UIColor lightGrayColor];
    sexLabel.backgroundColor = [UIColor clearColor];
    sexLabel.font = [UIFont systemFontOfSize:20];
    sexLabel.text = @"性别";
    [mainView addSubview:sexLabel];
    
    UILabel * bloodLabel = [[UILabel alloc]initWithFrame:CGRectMake(Width/2+5, kRelativeHeight(125), kRelativeWidth(40), kRelativeHeight(30))];
    bloodLabel.textAlignment  = NSTextAlignmentLeft;
    bloodLabel.textColor = [UIColor lightGrayColor];
    bloodLabel.backgroundColor = [UIColor clearColor];
    bloodLabel.font = [UIFont systemFontOfSize:20];
    bloodLabel.text = @"血型";
    [mainView addSubview:bloodLabel];
    for (int m = 0; m<2; m++) {
        float width = kRelativeWidth(45);
        float height = kRelativeHeight(120);
        UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(Width/2+kRelativeWidth(60)+width*m, 5, kRelativeWidth(20), kRelativeHeight(30))];
        btn.backgroundColor = [UIColor redColor];
        [btn setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@""] forState:UIControlStateSelected];
        [mainView addSubview:btn];
        
        NSArray * sexArray = [NSArray arrayWithObjects:@"男",@"女", nil];
        UILabel * manLabel = [[UILabel alloc]initWithFrame:CGRectMake(Width/2+kRelativeWidth(85)+width*m, 5, kRelativeWidth(30), kRelativeHeight(30))];
        manLabel.textAlignment  = NSTextAlignmentLeft;
        manLabel.textColor = [UIColor blackColor];
        manLabel.backgroundColor = [UIColor clearColor];
        manLabel.font = [UIFont systemFontOfSize:20];
        manLabel.text = [sexArray objectAtIndex:m];
        [mainView addSubview:manLabel];
        
        UIImageView * linImageView = [[UIImageView alloc]initWithFrame:CGRectMake(Width/2, height*m, 1, kRelativeHeight(40))];
        linImageView.backgroundColor = [UIColor lightGrayColor];
        [mainView addSubview:linImageView];
    }
    UITextField * text1Label = [[UITextField alloc]initWithFrame:CGRectMake(kRelativeWidth(100), 5, Width/2-kRelativeWidth(130), kRelativeHeight(30))];
    text1Label.textAlignment  = NSTextAlignmentRight;
    text1Label.textColor = [UIColor blackColor];
    text1Label.backgroundColor = [UIColor redColor];
    text1Label.font = [UIFont systemFontOfSize:20];
    text1Label.keyboardType = UIKeyboardTypeDefault;
    text1Label.returnKeyType = UIReturnKeyDone;
    text1Label.delegate = self;
    text1Label.clearButtonMode = UITextFieldViewModeAlways;
    text1Label.autocorrectionType = UITextAutocorrectionTypeYes;
    text1Label.text = @"";
    [mainView addSubview:text1Label];
    
    for (int s = 0; s<2; s++) {
        float width = Width/2;
        float height = kRelativeHeight(40);
        
        UITextField * text2Label = [[UITextField alloc]initWithFrame:CGRectMake(kRelativeWidth(120), kRelativeHeight(45)+height*s, Width-kRelativeWidth(180), kRelativeHeight(30))];
        text2Label.textAlignment = NSTextAlignmentRight;
        text2Label.textColor = [UIColor blackColor];
        text2Label.backgroundColor = [UIColor redColor];
        text2Label.font = [UIFont systemFontOfSize:20];
        text2Label.keyboardType = UIKeyboardTypeDefault;
        text2Label.returnKeyType = UIReturnKeyDone;
        text2Label.delegate = self;
        text2Label.clearButtonMode = UITextFieldViewModeAlways;
        text2Label.autocorrectionType = UITextAutocorrectionTypeYes;
        [mainView addSubview: text2Label];
        
        UITextField * text3Label = [[UITextField alloc]initWithFrame:CGRectMake(kRelativeWidth(120), kRelativeHeight(165)+height*s, Width-kRelativeWidth(180), kRelativeHeight(30))];
        text3Label.textAlignment = NSTextAlignmentRight;
        text3Label.textColor = [UIColor blackColor];
        text3Label.backgroundColor = [UIColor redColor];
        text3Label.font = [UIFont systemFontOfSize:20];
        text3Label.keyboardType = UIKeyboardTypeDefault;
        text3Label.returnKeyType = UIReturnKeyDone;
        text3Label.delegate = self;
        text3Label.clearButtonMode = UITextFieldViewModeAlways;
        text3Label.autocorrectionType = UITextAutocorrectionTypeYes;
        [mainView addSubview: text3Label];
        
//        UITextField * text4Label = [[UITextField alloc]initWithFrame:CGRectMake(100+(width-30)*s, 125, Width/2-130, 30)];
//        text4Label.textAlignment = NSTextAlignmentRight;
//        text4Label.textColor = [UIColor blackColor];
//        text4Label.backgroundColor = [UIColor redColor];
//        text4Label.font = [UIFont systemFontOfSize:20];
//        text4Label.keyboardType = UIKeyboardTypeDefault;
//        text4Label.returnKeyType = UIReturnKeyDone;
//        text4Label.delegate = self;
//        text4Label.clearButtonMode = UITextFieldViewModeAlways;
//        text4Label.autocorrectionType = UITextAutocorrectionTypeYes;
//        [mainView addSubview: text4Label];
        NSArray * titleArray = [NSArray arrayWithObjects:@"星座",@"血型", nil];
        ConstellationView * boxView = [[ConstellationView alloc]init];
        [boxView setControlsViewOriginx:kRelativeWidth(100)+(width-kRelativeWidth(30))*s ViewOriginy:kRelativeWidth(125) TextWidth:Width/2-kRelativeWidth(130) TextAndButtonHigth:kRelativeHeight(30) ButtonWidth:kRelativeWidth(20) TableHigth:kRelativeHeight(100) Editortype:YES];
        boxView.textfiled.placeholder =[titleArray objectAtIndex:s];
        boxView.delegate = self;
        boxView.tag = 1000;
        NSArray * constellationArray = [NSArray arrayWithObjects:@"白羊座",@"金牛座",@"双子座",@"巨蟹座",@"狮子座",@"处女座",@"天秤座",@"天蝎座",@"射手座",@"摩羯座",@"水瓶座",@"双鱼座", nil];
        NSArray * bloodArray = [NSArray arrayWithObjects:@"A型血",@"B型血",@"O型血",@"AB型血", nil];
        NSArray * arr = [NSArray arrayWithObjects:constellationArray,bloodArray, nil];
        boxView.arr = [arr objectAtIndex:s];
        [mainView addSubview:boxView];
        
        
    }

}
-(void)createSecView
{
    UILabel * titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(25), kRelativeHeight(300), kRelativeWidth(150), kRelativeHeight(40))];
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.textColor  = [UIColor grayColor];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont systemFontOfSize:22];
    titleLabel.text = @"【保密选项】";
    [mainScrollView addSubview:titleLabel];
    
    UILabel * changeLabel = [[UILabel alloc]initWithFrame:CGRectMake(Width-kRelativeWidth(120), kRelativeHeight(300), kRelativeWidth(100), kRelativeHeight(40))];
    changeLabel.textAlignment = NSTextAlignmentLeft;
    changeLabel.textColor  = [UIColor grayColor];
    changeLabel.backgroundColor = [UIColor clearColor];
    changeLabel.font = [UIFont systemFontOfSize:22];
    changeLabel.text = @"修改密码";
    [mainScrollView addSubview:changeLabel];
    
    UIView * mainView = [[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(340), Width-kRelativeWidth(40), kRelativeHeight(160))];
    mainView.backgroundColor = [UIColor whiteColor];
    [mainScrollView addSubview:mainView];
    
    for ( int i =0; i<4; i++) {
        float height=kRelativeHeight(40);
        NSArray * nameArray = [NSArray arrayWithObjects:@"身份证号",@"车牌号",@"车架号",@"发动机号", nil];
        UILabel * nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(5, 5+height*i, kRelativeWidth(85), kRelativeHeight(30))];
        nameLabel.textAlignment  = NSTextAlignmentLeft;
        nameLabel.textColor = [UIColor lightGrayColor];
        nameLabel.backgroundColor = [UIColor clearColor];
        nameLabel.font = [UIFont systemFontOfSize:20];
        nameLabel.text = [nameArray objectAtIndex:i];
        [mainView addSubview:nameLabel];
        
        UITextField * textLabel = [[UITextField alloc]initWithFrame:CGRectMake(kRelativeWidth(110), 5+height*i, Width-kRelativeHeight(170), kRelativeWidth(30))];
        textLabel.textAlignment = NSTextAlignmentRight;
        textLabel.textColor = [UIColor blackColor];
        textLabel.backgroundColor = [UIColor redColor];
        textLabel.font = [UIFont systemFontOfSize:20];
        textLabel.keyboardType = UIKeyboardTypeDefault;
        textLabel.returnKeyType = UIReturnKeyDone;
        textLabel.delegate = self;
        textLabel.clearButtonMode = UITextFieldViewModeAlways;
        textLabel.autocorrectionType = UITextAutocorrectionTypeYes;
        [mainView addSubview: textLabel];
    }
    for (int j = 0; j<3; j++) {
        float height=40;
        UIImageView * lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(39)+height*j, Width-kRelativeWidth(40), 1)];
        lineImageView.backgroundColor = [UIColor lightGrayColor];
        [mainView addSubview:lineImageView];
    }
 
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
-(void)selectedAtIndex:(int)index WithConstellation:(ConstellationView *)constellation{
    NSLog(@"row ==%d",index);
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    ConstellationView * box = (ConstellationView *)[self.view viewWithTag:1000];
    [box closeTableview];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
