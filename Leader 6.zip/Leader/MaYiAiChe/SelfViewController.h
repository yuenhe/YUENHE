//
//  SelfViewController.h
//  MaYiAiChe
//
//  Created by xc on 16/12/30.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelfViewController : UIViewController<UIScrollViewDelegate>
{
    UIScrollView * mainScrollView;
}

@end
