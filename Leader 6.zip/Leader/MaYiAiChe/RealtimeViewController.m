//
//  RealtimeViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "RealtimeViewController.h"
#import "CommodityTableViewCell.h"
#import "ServiceTableViewCell.h"
#import "SonServiceViewController.h"
#import "HRAccountTool.h"
#import "DataCenter.h"
#import "ServiceModel.h"
#import "TBRefresh.h"
#import "RealtimeFinishDetailViewController.h"
#import "UITableView+LSEmpty.h"

//#import "LBSegmentControl.h"
//#import "WeiJiDanTableViewController.h"
//#import "YiJiDanTableViewController.h"

@interface RealtimeViewController ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,cellCustomDelegate,cellServicDelegate>
{
    UIScrollView * _bigScrollView;
    UIView * _topView;
    UIView * _selectedView;
    UIButton * _selectedBtn;
    UIButton * _selectbtn;
    UIButton * _btn;
    UIButton * _ddbtn;
    UIView * _midView;
    NSString * _order;
    UIView * lineView;      // 下划线
}
@property (nonatomic,strong) DataCenter * data;
@property (nonatomic,strong) NSMutableArray * dataArray;
@property (nonatomic,strong) NSArray * dataarr;
@property (nonatomic,strong) UITableView * tableview;
@property (nonatomic,strong) UITableView * etableview;

@property(nonatomic,strong)UIButton * tmpBtn;       // 临时交换

@end
#define  WIDTH  self.view.frame.size.width
#define Height  self.view.frame.size.height
@implementation RealtimeViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if ([_status  isEqualToString:@"2001"]) {
        [self initNet];     //  已接单
    }else{
        [self createNet];   // 未接单
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _data = [DataCenter shareDataCenter];
    _dataArray = [NSMutableArray new];
    self.view.backgroundColor = [UIColor lightGrayColor];
    self.navigationController.navigationBar.hidden = YES;
    
    [self initTopView];
    [self createSemgent];       //  segement
    [self initUI];
    //[self initNet];
    //    [self createnetworking];
    // Do any additional setup after loading the view.
    self.tableview.startTip = YES;
    self.tableview.tipTitle = @"无新订单!";
    //可以不设置 默认图片为nomessage 可以到分类中修改默认图片名
    self.tableview.tipImage=[UIImage imageNamed:@"nomessage"];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark===================// 未接单
-(void)createNet
{
    if (_data.UIDs.length == 0) {
        
    }else{
        NSString * useID = _data.UIDs;
        
        AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        NSMutableDictionary * servicedic = [[NSMutableDictionary alloc]init];
        [servicedic setObject:useID forKey:@"s_userid"];
        //    NSString * urlString = @"http://106.15.0.128/working/index.php/Admin/ApiS/s_forders";
        NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_forders";
        [manager POST:urlString parameters:servicedic progress:^(NSProgress * _Nonnull uploadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            //        NSLog(@"%@",responseObject);
//            NSString * str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
//            NSLog(@"%@",str);
            NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            //        _data.order_num = dic[@"order_number"];
            if (dic[@"xiche_weijiedan"] != [NSNull null]) {
                NSArray * array = dic[@"xiche_weijiedan"];
                [_dataArray removeAllObjects];
                for (NSDictionary * dic in array) {
                    ServiceModel * model = [[ServiceModel alloc]init];
                    model.addtime = dic[@"yuyue_time"];
                    model.fuwu = dic[@"fuwu_type"];
                    model.title = dic[@"order_title"];
                    model.adress = dic[@"address"];
                    model.phonenum = dic[@"phone"];
                    model.logo = dic[@"xg_logo"];
                    model.status = dic[@"order_status"];
                    model.carstlye = dic[@"consumer_car"];
                    model.oder_number = dic[@"order_number"];
                    model.lat         = dic[@"lat"];
                    model.lng        = dic[@"lng"];
                    [_dataArray addObject:model];
                }
                //        self.dataarr = array;
                [self.tableview reloadData];
                //        NSLog(@"%@",_order);
            }else{
                NSLog(@"没有订单");
                [_dataArray removeAllObjects];
                [self.tableview reloadData];
            }
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"%@",error);
        }];
    }
}

#pragma mark===================//、、 已接单
-(void)initNet
{
    if (_data.UIDs.length == 0) {
        
    }else{
        NSString * useID = _data.UIDs;
        
        AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        NSMutableDictionary * servicedic = [[NSMutableDictionary alloc]init];
        [servicedic setObject:useID forKey:@"s_userid"];
        
        //    NSString * urlString = @"http://106.15.0.128/working/index.php/Admin/ApiS/s_forders";
        NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_forders";
        
        [manager POST:urlString parameters:servicedic progress:^(NSProgress * _Nonnull uploadProgress) {
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            //        NSLog(@"%@",responseObject);
//            NSString * str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
//            NSLog(@"%@",str);
            NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            //        _data.order_num = dic[@"order_number"];
            if (dic[@"xiche_yijiedan"] == [NSNull null]) {
                NSLog(@"没有订单");
                [_dataArray removeAllObjects];
                [self.tableview reloadData];
            }else{
                NSArray * array = dic[@"xiche_yijiedan"];
                [_dataArray removeAllObjects];
                for (NSDictionary * dic in array) {
                    ServiceModel * model = [[ServiceModel alloc]init];
                    model.addtime = dic[@"yuyue_time"];
                    model.fuwu = dic[@"fuwu_type"];
                    model.title = dic[@"order_title"];
                    model.adress = dic[@"address"];
                    model.phonenum = dic[@"phone"];
                    model.logo = dic[@"xg_logo"];
                    model.status = dic[@"order_status"];
                    model.carstlye = dic[@"consumer_car"];
                    model.start_time = dic[@"start_service_time"];
                    model.jiedan_time = dic[@"jiedan_time"];
                    model.oder_number = dic[@"order_number"];
                    model.lat         = dic[@"lat"];
                    model.lng        = dic[@"lng"];
                    if (dic[@"after_service_pic"] == [NSNull null]) {
                    }else{
                        model.after_service_pic = dic[@"after_service_pic"];
                    }
                    if (dic[@"before_service_pic"] == [NSNull null]) {
                    }else{
                        model.before_service_pic = dic[@"before_service_pic"];
                    }
                    [_dataArray addObject:model];
                }
                //        self.dataarr = array;
                [self.tableview reloadData];
            }
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"%@",error);
        }];
    }
}

-(void)initTopView
{
    _topView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, kRelativeHeight(80))];
    [_topView setBackgroundColor:[UIColor greenColor]];
    [self.view addSubview:_topView];
    
    
    NSArray * array = [[NSArray alloc]initWithObjects:@"服务",@"商品", nil];
    float width = 100;
    for (int i = 0; i<array.count; i++) {
        NSString * title = [array objectAtIndex:i];
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(width*i+(self.view.frame.size.width)/2-kRelativeWidth(100), kRelativeHeight(40), width, kRelativeHeight(40));
        [btn setTitle:title forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor greenColor] forState:UIControlStateSelected];
        [btn addTarget:self action:@selector(topbtnclick:) forControlEvents:UIControlEventTouchUpInside];
        btn.backgroundColor = [UIColor whiteColor];
        //        btn.hidden = YES;
        btn .tag = 100+i;
        [_topView addSubview:btn];
        if (i == 0) {
            _selectedBtn = btn;
            _selectedBtn.selected = YES;
        }
    }
    
}

// 创建 Semgent
-(void)createSemgent{
    
    _bigScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(80), WIDTH, Height-kRelativeHeight(80))];
    _bigScrollView.contentSize = CGSizeMake(WIDTH*2, 0);
    _bigScrollView.backgroundColor = [UIColor grayColor];
    _bigScrollView.pagingEnabled = YES;
    _bigScrollView.bounces = NO;
    _bigScrollView.delegate = self;
    [self.view  addSubview:_bigScrollView];
    
    //    YiJiDanTableViewController *  yijiedan  = [[YiJiDanTableViewController alloc]init];
    //    WeiJiDanTableViewController *  weijiedan = [[WeiJiDanTableViewController alloc]init];
    //
    //    LBSegmentControl * segmentControl = [[LBSegmentControl alloc] initStaticTitlesWithFrame:CGRectMake(0, 0, WIDTH, 55)];
    //    segmentControl.titles = @[@"未接单", @"已接单"];
    //    segmentControl.viewControllers = @[weijiedan,yijiedan];
    //    segmentControl.titleNormalColor = [UIColor blackColor];
    //    segmentControl.titleSelectColor = [UIColor colorWithRed:0/256.0 green:234/256.0 blue:116/256.0 alpha:1];
    //    [segmentControl setBottomViewColor:[UIColor colorWithRed:0/256.0 green:234/256.0 blue:116/256.0 alpha:1]];
    //    segmentControl.isTitleScale = YES;
    
    //    [_bigScrollView addSubview:segmentControl];
    
    ///*
    
    // 中间View
    UIView * bottomView  = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, 60)];
    bottomView.backgroundColor   = [UIColor whiteColor];
    [_bigScrollView addSubview:bottomView];
    
    NSArray * array  = @[@"未接单",@"已接单"];
    for (int i = 0; i< array.count; i++) {
        UIButton *  button = [[UIButton alloc]initWithFrame:CGRectMake(0+WIDTH/2*i, 0 , WIDTH/2, 50)];
        [button setTitle:array[i] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor  blackColor] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor colorWithRed:0/256.0 green:234/256.0 blue:116/256.0 alpha:1] forState:UIControlStateSelected];
        button.tag = 2000+i;
        [button addTarget:self action:@selector(chooseButton:) forControlEvents:UIControlEventTouchUpInside];
        [bottomView addSubview:button];
        
        if (i == 0) {
            button.selected = YES;
            // 下滑先
            lineView = [[UIView alloc]initWithFrame:CGRectMake(0, 51, WIDTH/array.count, 2)];
            lineView.backgroundColor = [UIColor colorWithRed:0/256.0 green:234/256.0 blue:116/256.0 alpha:1];
            lineView.tag = 3000;
            [bottomView addSubview:lineView];
        }
        
    }
    
}

//、选择已接单 未接单
-(void)chooseButton:(UIButton*)bt {
    UIButton * button  = [self.view viewWithTag:2000];
    if (button.tag!=bt.tag) {
        button.selected = NO;
    }
    if (_tmpBtn == nil){
        bt.selected = YES;
        _tmpBtn = bt;
    }
    else if (_tmpBtn !=nil && _tmpBtn == bt){
        bt.selected = YES;
    }
    else if (_tmpBtn!= bt && _tmpBtn!=nil){
        _tmpBtn.selected = NO;
        if (!_tmpBtn.selected) {
        }
        bt.selected = YES;
        if (bt.selected) {
        }
        _tmpBtn = bt;
    }
    
    if (bt.tag ==2000) {
        _status = @"2000";
        NSLog(@"未接单");
        [self createNet];
         [self.tableview.header beginRefreshing];
     }
    else if (bt.tag == 2001)
    {
        _status = @"2001";
         NSLog(@"已接单");
        [self  initNet];
         [self.tableview.header beginRefreshing];
     }
    
    // 让 label 跟着一起动
    CGRect rect = lineView.frame;
    rect.origin.x = WIDTH / 2 * (bt.tag - 2000);
    lineView.frame = rect;
    
    [_tableview reloadData];
    
}


#pragma mark===================// 创建表格
-(void)initUI
{
    if (!_tableview) {
        __weak RealtimeViewController * weakself = self;
        _tableview = [[UITableView alloc]initWithFrame:CGRectMake(0, 60, WIDTH, _bigScrollView.frame.size.height-111) style:UITableViewStylePlain];
        _tableview.tag =200;
        _tableview.delegate = self;
        _tableview.dataSource = self;
        _tableview.tableFooterView = [UIView new];
        [_tableview addRefreshHeaderWithBlock:^{
            [weakself LoadDatas];
        }];
          [self.tableview.header beginRefreshing];
        //        [_tableview addRefreshFootWithBlock:^{
        //             [weakself LoadMoreDatas];
        //        }];
        
        [_bigScrollView addSubview:_tableview];
    }
    
    //    self.tableview = fstTableView;
    
    UITableView * scdTableView = [[UITableView alloc]initWithFrame:CGRectMake(WIDTH, 0, WIDTH, _bigScrollView.frame.size.height) style:UITableViewStylePlain];
    scdTableView.tag =201;
    scdTableView.delegate = self;
    scdTableView.dataSource = self;
    [_bigScrollView addSubview:scdTableView];
    self.etableview = scdTableView;
    
    
}
#pragma mark -- scrollViewDelegate
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if ([scrollView isEqual:_bigScrollView]) {
        int contentoffset = scrollView.contentOffset.x;
        int numOfTable = contentoffset/WIDTH;
        UIButton * btn = (UIButton *)[self.view viewWithTag:100+numOfTable];
        [self topbtnclick:btn];
    }
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.contentOffset.y<0) {
        return;
    }
}
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if (scrollView.contentOffset.y <0) {
        return;
    }
}
-(void)topbtnclick:(UIButton *)sender
{
    if (_selectedBtn == sender) {
        return;
    }
    _selectedBtn.selected = NO;
    _selectedBtn = sender;
    _selectedBtn.selected = YES;
    float  width = 100;
    [_bigScrollView setContentOffset:CGPointMake(WIDTH* (sender.tag-100), 0) animated:YES];
    [UIView animateWithDuration:0.3 animations:^{
        _selectedView.frame = CGRectMake(width* (sender.tag -100), 80-3, width, 1);
    }];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    switch (tableView.tag) {
        case 200:{
            return 1;
        }
            break;
        case 201:
        {
            return 3;
        }
            break;
        default:
            return 0;
            break;
    }
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag == 200) {
        return _dataArray.count;
    }else
    {
        if (section == 0) {
            return 3;
        }else if (section == 1)
        {
            return 2;
        }else
        {
            return 1;
        }
    }
}

#pragma mark=================== cell 回调
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (tableView.tag) {
        case 200:
        {
            static NSString * cellID = @"cellCusId";
            ServiceTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellID];
            if (!cell) {
                cell = [[ServiceTableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellID];
            }
            //            ServiceModel * model = [[ServiceModel alloc]init];
            //            model = _dataArray[indexPath.row];
            //            UIImage * headIamgeView;
            //            NSURL * url = [NSURL URLWithString:model.logo];
            //            headIamgeView = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
            //            [cell reloadViewWithName:model.fuwu FirstLabel:model.title nameLabel:model.carstlye telLabel:model.phonenum adrLabel:model.adress headImageView:headIamgeView titleImageView:[UIImage imageNamed:@""] addtime:model.addtime];
            cell.delegate = self;
            
            ServiceModel * model = [[ServiceModel alloc]init];
            model = _dataArray[indexPath.row];
            cell.model = model;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            
            break;
        case 201:
        {
            static NSString * cellID = @"cellCusId";
            CommodityTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellID];
            if (!cell) {
                cell = [[CommodityTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
                cell.delegate = self;
                _selectedBtn = [[UIButton alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-kRelativeWidth(100), kRelativeHeight(95), kRelativeWidth(80), kRelativeHeight(30))];
                [_selectedBtn setTitle:@"立即接单" forState:UIControlStateNormal];
                [_selectedBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                //        [_selectedBtn setTitle:@"开始派送" forState:UIControlStateSelected];
                //        [_selectedBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateSelected];
                //        [_selectedBtn setTitle:@"完成订单" forState:UIControlStateSelected];
                //        [_selectedBtn setTitleColor:[UIColor blueColor] forState:UIControlStateSelected];
                [_selectedBtn addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
                _selectedBtn.tag = 101;
                _selectedBtn.backgroundColor = [UIColor greenColor];
                [cell.contentView addSubview:_selectedBtn];
            }
            NSString * headLabel;
            NSString * fstrtLabel;
            NSString * nameLabel;
            NSString * telLabel;
            NSString * adrLabel;
            UIImage * headIamgeView;
            UIImage * titleImageView;
            headLabel = @"商品A";
            fstrtLabel = @"xxxxxxx";
            nameLabel = @"李女士";
            telLabel = @"18888888888";
            adrLabel = @"江干区环球汽车科技园";
            headIamgeView = [UIImage imageNamed:@""];
            titleImageView = [UIImage imageNamed:@""];
            [cell reloadViewWithName:headLabel FirstLabel:fstrtLabel nameLabel:nameLabel telLabel:telLabel adrLabel:adrLabel headImageView:headIamgeView titleImageView:titleImageView];
            return cell;
        }
            break;
            
        default:
            return 0;
            break;
    }
}

#pragma mark===================//、、 进入服务界面
-(void)cellServicDidCLick:(ServiceTableViewCell*)cell WithBtn:(UIButton *)btn{
    
    //    SonServiceViewController *  service = [[SonServiceViewController alloc]init];
    RealtimeFinishDetailViewController *  service  = [[RealtimeFinishDetailViewController alloc]init];
    if ([cell.model.status isEqualToString:@"1"]) {
        NSString * useID = _data.UIDs;
        
        AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        NSMutableDictionary * servicedic = [[NSMutableDictionary alloc]init];
        [servicedic setObject:useID forKey:@"s_userid"];
        [servicedic setObject:cell.model.oder_number forKey:@"s_order_num"];
        //    [servicedic setObject:@"json" forKey:@"type"];
        
        //            NSString * urlString = @"http://106.15.0.128/working/index.php/Admin/ApiS/s_jiedan";
        NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_jiedan";
        
        [manager POST:urlString parameters:servicedic progress:^(NSProgress * _Nonnull uploadProgress) {
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            //            NSString * str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
            //            NSLog(@"%@",str);
            NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            
            if ([dic[@"status"] isEqualToString:@"接单成功"]) {
                service.orderStr        = cell.model.oder_number;
                service.headImageStr = cell.model.logo;
                service.fuwuStr         = cell.headLabel.text;
                service.titleStr            = cell.fstrtLabel.text;
                service.phoneStr        = cell.telLabel.text;
                service.addressStr      = cell.adrLabel.text;
                service.lat                   = cell.model.lat;
                service.lng                  = cell.model.lng;
                [self.navigationController pushViewController:service animated:YES];
                
            }else{
                NSLog(@"接单失败");
            }
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"%@",error);
        }];
        
    }else if ([cell.model.status isEqualToString:@"2"]){
        service.orderStr        = cell.model.oder_number;
        service.headImageStr = cell.model.logo;
        service.fuwuStr         = cell.headLabel.text;
        service.titleStr            = cell.fstrtLabel.text;
        service.phoneStr        = cell.telLabel.text;
        service.addressStr      = cell.adrLabel.text;
        service.lat                   = cell.model.lat;
        service.lng                  = cell.model.lng;
        service.status               =  cell.model.status;
        [self.navigationController pushViewController:service animated:YES];
        
    }else if ([cell.model.status isEqualToString:@"3"]){
        service.orderStr        = cell.model.oder_number;
        service.headImageStr = cell.model.logo;
        service.fuwuStr         = cell.headLabel.text;
        service.titleStr            = cell.fstrtLabel.text;
        service.phoneStr        = cell.telLabel.text;
        service.addressStr      = cell.adrLabel.text;
        service.lat                   = cell.model.lat;
        service.lng                  = cell.model.lng;
        service.status               =  cell.model.status;
        service.before_ImageArry     = cell.model.before_service_pic;
        [self.navigationController pushViewController:service animated:YES];
    }
    
    NSLog(@"----------444333-----%ld",btn.tag);
}

//-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
//{
//    static NSString * identy = @"head";
//    UITableViewHeaderFooterView * hf = [tableView dequeueReusableHeaderFooterViewWithIdentifier:identy];
//    if (!hf) {
//        hf = [[UITableViewHeaderFooterView alloc]initWithReuseIdentifier:identy];
//    }
//    if (tableView.tag == 201)
//    {
//        UIView * headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, kRelativeHeight(40))];
//        headView.backgroundColor = [UIColor whiteColor];
//        [hf addSubview:headView];
//
//        UILabel * textLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(5), kRelativeHeight(5), kRelativeWidth(80), kRelativeHeight(30))];
//        textLabel.textAlignment = NSTextAlignmentLeft;
//        textLabel.textColor = [UIColor grayColor];
//        textLabel.text =@"订单号";
//        textLabel.font = [UIFont systemFontOfSize:15];
//         [headView addSubview:textLabel];
//
//        UILabel * numLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(90), kRelativeHeight(5), kRelativeWidth(200), kRelativeHeight(30))];
//        numLabel.textAlignment = NSTextAlignmentLeft;
//        numLabel.textColor = [UIColor grayColor];
//        numLabel.text =@"12393939932772";
//        numLabel.font = [UIFont systemFontOfSize:15];
//         [headView addSubview:numLabel];
//    }
//    return hf;
//}
//-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
//{
//    static NSString * idt = @"headFoot";
//
//    UITableViewHeaderFooterView * fh = [tableView dequeueReusableHeaderFooterViewWithIdentifier:idt];
//    if (!fh) {
//        fh = [[UITableViewHeaderFooterView alloc]initWithReuseIdentifier:idt];
//    }
//    if (tableView.tag == 201) {
//        UIView * footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, kRelativeHeight(60))];
//        footView.backgroundColor = [UIColor whiteColor];
//        [fh addSubview:footView];
//
//        UIImageView * lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(0), kRelativeHeight(20), ScreenWidth-kRelativeWidth(160), kRelativeHeight(1))];
//        lineImageView.backgroundColor = [UIColor blackColor];
//        [footView addSubview:lineImageView];
//
//        //    UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth-kRelativeWidth(225), 0, kRelativeWidth(30), kRelativeHeight(40))];
//        //    imageView.backgroundColor = [UIColor clearColor];
//        //    imageView.image = [UIImage imageNamed:@"back"];
//        //    [footView addSubview:imageView];
//
//        UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(ScreenWidth-kRelativeWidth(150), kRelativeHeight(5), kRelativeWidth(120), kRelativeHeight(40))];
//        btn.backgroundColor = [UIColor clearColor];
//        [btn setTitle:@"查看更多" forState:UIControlStateNormal];
//        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//        [footView addSubview:btn];
//
//    }
//
//    return fh;
//}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
   return kRelativeHeight(180);
}
//- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
//{
//    if (tableView.tag == 201) {
//        return 30;
//    }else
//    {
//        if (section == 0) {
//            return 0;
//        }
//        return 1;
//    }
//
//}
//-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
//{
//    if (tableView.tag == 201) {
//        return 70;
//    }
//    return 1;
//}
-(void)btnclick:(UIButton *)btn
{
    if (btn.tag == 100) {
        [self.navigationController pushViewController:[SonServiceViewController new] animated:YES];
    }else
    {
        
    }
}
#pragma mark--------下拉 加载数据

-(void)LoadDatas
{
    
    [self.tableview.footer ResetNomoreData];
    
    if ([_status isEqualToString:@"2001"]) {
        if (_data.UIDs.length == 0) {
            NSLog(@"还没登录成功");
        }else{
            NSString * useID = _data.UIDs;
            
            AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
            manager.responseSerializer = [AFHTTPResponseSerializer serializer];
            NSMutableDictionary * servicedic = [[NSMutableDictionary alloc]init];
            [servicedic setObject:useID forKey:@"s_userid"];
            
            //    NSString * urlString = @"http://106.15.0.128/working/index.php/Admin/ApiS/s_forders";
            NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_forders";
            
            [manager POST:urlString parameters:servicedic progress:^(NSProgress * _Nonnull uploadProgress) {
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
                //        _data.order_num = dic[@"order_number"];
                if (dic[@"xiche_yijiedan"] == [NSNull null]) {
                    NSLog(@"没有订单");
                    [self.tableview reloadData];
                }else{
                    NSArray * array = dic[@"xiche_yijiedan"];
                    [_dataArray removeAllObjects];
                    for (NSDictionary * dic in array) {
                        ServiceModel * model = [[ServiceModel alloc]init];
                        model.addtime = dic[@"yuyue_time"];
                        model.fuwu = dic[@"fuwu_type"];
                        model.title = dic[@"order_title"];
                        model.adress = dic[@"address"];
                        model.phonenum = dic[@"phone"];
                        model.logo = dic[@"xg_logo"];
                        model.status = dic[@"order_status"];
                        model.carstlye = dic[@"consumer_car"];
                        model.oder_number = dic[@"order_number"];
                        model.lat         = dic[@"lat"];
                        model.lng        = dic[@"lng"];
                        if (dic[@"after_service_pic"] == [NSNull null]) {
                        }else{
                            model.after_service_pic = dic[@"after_service_pic"];
                        }
                        if (dic[@"before_service_pic"] == [NSNull null]) {
                        }else{
                            model.before_service_pic = dic[@"before_service_pic"];
                        }
                        [_dataArray addObject:model];
                    }
                    NSLog(@"---已接单-新的数量----------%ld------",_dataArray.count);
                    //                    [self.tableview reloadData];
                }
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error);
            }];
        }
    }
    
    else{
        if (_data.UIDs.length == 0) {
            NSLog(@"还没登录成功");
        }else{
            NSString * useID = _data.UIDs;
            
            AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
            manager.responseSerializer = [AFHTTPResponseSerializer serializer];
            NSMutableDictionary * servicedic = [[NSMutableDictionary alloc]init];
            [servicedic setObject:useID forKey:@"s_userid"];
            //    NSString * urlString = @"http://106.15.0.128/working/index.php/Admin/ApiS/s_forders";
            NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_forders";
            [manager POST:urlString parameters:servicedic progress:^(NSProgress * _Nonnull uploadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
                //        _data.order_num = dic[@"order_number"];
                if (dic[@"xiche_weijiedan"] != [NSNull null]) {
                    NSArray * array = dic[@"xiche_weijiedan"];
                    [_dataArray removeAllObjects];
                    for (NSDictionary * dic in array) {
                        ServiceModel * model = [[ServiceModel alloc]init];
                        model.addtime = dic[@"yuyue_time"];
                        model.fuwu = dic[@"fuwu_type"];
                        model.title = dic[@"order_title"];
                        model.adress = dic[@"address"];
                        model.phonenum = dic[@"phone"];
                        model.logo = dic[@"xg_logo"];
                        model.status = dic[@"order_status"];
                        model.carstlye = dic[@"consumer_car"];
                        model.oder_number = dic[@"order_number"];
                        model.lat         = dic[@"lat"];
                        model.lng        = dic[@"lng"];
                        [_dataArray addObject:model];
                    }
                    NSLog(@"---未接单-新的数量----------%ld------",_dataArray.count);
                    [self.tableview reloadData];
                    
                }else{
                    NSLog(@"没有订单");
                    //                     [self.tableview reloadData];
                }
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                NSLog(@"%@",error);
            }];
        }
        
    }
    
    // 模拟延时设置
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        [_tableview reloadData];
        
        [self.tableview.header endHeadRefresh];
        
    });
}

-(void)LoadMoreDatas
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [self.tableview.footer NoMoreData];
        
    });
    
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
