//
//  DataCenter.h
//  NewHouse
//
//  Created by gaoyang on 14-9-9.
//  Copyright (c) 2014年 gaoyang. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "CityModel.h"
//#import "UserModel.h"

@interface DataCenter : NSObject


@property(nonatomic,copy)NSString *path;                //本地数据库地址
//// @property(nonatomic,copy)NSString *localCity;            //获取当前城市
////@property(nonatomic,strong)CityModel *cityMod;            //选择城市信息
////@property(nonatomic,strong)UserModel *userModel;          //用户信息
//@property(nonatomic,strong)NSMutableDictionary *appPeiZhi;  //app配置
//
//@property (nonatomic,strong)NSString * types;  // 登录类型
//
//@property (nonatomic ,copy) NSString *nickName;  // 名字
//@property (nonatomic ,copy) NSString * sex;     // 性别
//@property (nonatomic ,strong) NSData *imageData;
//
//@property (nonatomic,strong)NSMutableArray * dataArray;  //首页收藏id
//@property (nonatomic,strong)NSMutableArray * dataArrayDongtai;//动态收藏id
//@property (nonatomic,strong)NSMutableArray * dataArrayDianzan;//动态点赞id
//@property (nonatomic,strong)NSString * dataString;  // model.act
//@property ( nonatomic,strong) NSString * agtCount;  // 经纪人账号
//

//@property (nonatomic,assign)CGFloat  latitude;                  // 当钱位置
//@property (nonatomic,assign)CGFloat  longitude;                 // 当前位置
//@property (nonatomic ,copy) NSString * homeLocationString;      // 首页定位名字
//@property (nonatomic ,copy) NSString * ShopLocationString;      // 店铺查询定位名字
@property (nonatomic,strong)NSString * UIDs;                    // Uid
// @property(nonatomic,copy)NSString *localShop;                  // 获取当前店铺地址
//@property(nonatomic,strong)NSMutableArray * longitudeArray;     // 经度数组
//@property(nonatomic,strong)NSMutableArray * latitudeArray;      // 纬度数组
@property(nonatomic,strong)NSString  * phone;                   // 手机号码
@property (nonatomic,strong)NSString * order_num;//订单号

+(id)shareDataCenter;                                   //创建单例


//////////////////////////////////////////////////////////////////////////////////////
//- (void)saveUserInofFromSanbox;
//
//- (void)loadUserInofFromSanbox;
//
//-(void)UIDset:(NSString *)uidstring;                       //录入账户UID
//-(NSString *)UIDget;                                      //获取账户UID
//-(id)getDataWithKey:(NSString *)key;                        //根据key值 获取data
//-(void)writeData:(id)target withKey:(NSString *)key;        //格局key值 录入data
@end
