//
//  NaviController.m
//  MaYiAiChe
//
//  Created by xc on 17/2/9.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "NaviController.h"

#import <MAMapKit/MAMapKit.h>
#import <UIKit/UIKit.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <AMapLocationKit/AMapLocationKit.h>
#import <AMapNaviKit/AMapNaviKit.h>
#import <AMapSearchKit/AMapSearchKit.h>
#import <AMapLocationKit/AMapLocationKit.h>
#import <AMapFoundationKit/AMapFoundationKit.h>


@interface NaviController ()<MAMapViewDelegate,AMapLocationManagerDelegate,AMapNaviDriveViewDelegate,AMapNaviDriveManagerDelegate,AMapSearchDelegate>{
    
    AMapNaviDriveManager *_driveManager;  //   导航
    AMapNaviDriveView *_naviDriveView;     //   导航

}

@property (nonatomic,strong)MAMapView * mapView;
@property (nonatomic,strong)AMapLocationManager * locationManager;
 @property (nonatomic,strong)UIButton * btn;
@property (nonatomic,strong)AMapNaviDriveManager * driveManager;
@property (nonatomic,strong)AMapNaviDriveView * driveView;
@property (nonatomic,strong)AMapNaviPoint * startPoint;
@property (nonatomic,strong)AMapNaviPoint * endPoint;

@property (nonatomic, strong) AMapSearchAPI *search;
@property (nonatomic,assign) double lau;  // 起点精度
@property (nonatomic,assign) double lon;  //  起点维度

//@property (nonatomic, strong) MoreMenuView * moreMenu;          // 更多button


@end

@implementation NaviController
-(void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
       [AMapServices sharedServices].apiKey = @"a28f576d080354502a3e8a352130d7be";
    self.search = [[AMapSearchAPI alloc]init];
    self.search.delegate = self;
     //初始化mapview
    _mapView = [[MAMapView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-100)];
    _mapView.delegate = self;
    // 地图缩放等级
    _mapView.zoomLevel = 17;
    // 开启定位
    _mapView.showsUserLocation = YES;
    //地图跟踪模式
    _mapView.userTrackingMode = MAUserTrackingModeFollow;

    [self.view  addSubview:_mapView];
    
    self.locationManager = [[AMapLocationManager alloc] init];
    self.locationManager.delegate = self;
    // 带逆地理信息的一次定位（返回坐标和地址信息）
    [self.locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
    //   定位超时时间，最低2s，此处设置为10s
    self.locationManager.locationTimeout =10;
    //   逆地理请求超时时间，最低2s，此处设置为10s
    self.locationManager.reGeocodeTimeout = 10;
    [self.locationManager startUpdatingLocation];
    
#pragma mark===================    //  管理导航
    _driveManager = [[AMapNaviDriveManager alloc] init];
    _driveManager.updateCameraInfo = YES;
    _driveManager.updateTrafficInfo = YES;
    [_driveManager setAllowsBackgroundLocationUpdates:YES];
    //    [_driveManager setPausesLocationUpdatesAutomatically:NO];
    [_driveManager setDelegate:self];
    //将driveView添加为导航数据的Representative，使其可以接收到导航诱导数据
    [_driveManager addDataRepresentative:_naviDriveView];

    
    _btn = [[UIButton alloc]init];
    _btn.frame = CGRectMake(kRelativeWidth(50), kRelativeHeight(ScreenHeight-100), kRelativeWidth(ScreenWidth-100), kRelativeHeight(40));
    [_btn setTitle:@"开始导航" forState:UIControlStateNormal];
    [_btn setTitleColor:[UIColor brownColor] forState:UIControlStateNormal];
    [_btn addTarget:self action:@selector(beginRouting) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_btn];
    [self showmap];
}
-(void)showmap
{
    _mapView.showTraffic = NO;
    _mapView.mapType = MAMapTypeStandard;
    
    _mapView.showsCompass = NO;
    _mapView.compassOrigin = CGPointMake(_mapView.compassOrigin.x, 22);
    _mapView.showsScale = NO;
    _mapView.scaleOrigin = CGPointMake(_mapView.scaleOrigin.x, 22);
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
//    [self clipOneAnnnotation];
}
-(void)clipOneAnnnotation
{
    MAPointAnnotation * pointAnnt = [[MAPointAnnotation alloc]init];
    pointAnnt.coordinate = CLLocationCoordinate2DMake(39.989631, 116.481018);
    pointAnnt.title = @"方恨国际";
    pointAnnt.subtitle = @"复东大街6号";
    [self.mapView addAnnotation:pointAnnt];
}
-(void)beginRouting
{
//    _startPoint = [AMapNaviPoint locationWithLatitude:39.993135 longitude:116.474175];
//    _endPoint = [AMapNaviPoint locationWithLatitude:39.908791 longitude:116.321257];
//    _driveManager = [[AMapNaviDriveManager alloc]init];
//    _driveManager.delegate = self;
//    
//    _driveView = [[AMapNaviDriveView alloc]init];
//    _driveView.frame = self.view.frame;
//    _driveView.delegate = self;
//    [self.view addSubview:_driveView];
//    
//    [self.driveManager addDataRepresentative:_driveView];
//    
//    [self.driveManager calculateDriveRouteWithStartPoints:@[self.startPoint] endPoints:@[self.endPoint] wayPoints:nil drivingStrategy:AMapNaviDrivingStrategyMultipleDefault];
    
    
    if ( !_naviDriveView )
    {
        if (_mapView.userLocation.coordinate.latitude == 0||_mapView.userLocation.coordinate.latitude == _mapView.userLocation.coordinate.longitude)
        {
//            [MBProgressHUD showError:@"位置读取中,请稍后"];
        }
        else{
            self.navigationController.navigationBar.hidden = YES;
            [UIApplication sharedApplication].statusBarHidden = YES;
            
            // 初始化导航视图, 使用另一种样式 : AMapNaviHUDView
            _naviDriveView = [[AMapNaviDriveView alloc]
                              initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), CGRectGetHeight(self.view.bounds) )];
            _naviDriveView.delegate = self;
        }
    }
    // 起点
    AMapNaviPoint *startPoint = [AMapNaviPoint locationWithLatitude:_lau longitude:_lon];
    
    //    AMapNaviPoint *startPoint = [AMapNaviPoint locationWithLatitude:30.326024 longitude:120.357335];
    // 终点
    AMapNaviPoint *endPoint = [AMapNaviPoint locationWithLatitude:_latitude longitude:_longitude];
    
    NSArray *startPoints = @[startPoint];
    NSArray *endPoints   = @[endPoint];
    
    //    // 关闭智能播报
    //    [_driveManager setDetectedMode:AMapNaviDetectedModeNone];
    // 智能播报
    [_driveManager setDetectedMode:AMapNaviDetectedModeCameraAndSpecialRoad];
    //iOS9(含)以上系统需设置
    [_driveManager setAllowsBackgroundLocationUpdates:YES];
    //驾车路径规划（未设置途经点、导航策略为速度优先）
    [_driveManager calculateDriveRouteWithStartPoints:startPoints endPoints:endPoints wayPoints:nil drivingStrategy:AMapNaviDrivingStrategyMultipleDefault];
    
}


//#pragma mark=================== 初始化
//- (void)initMoreMenu
//{
//    if (self.moreMenu == nil)
//    {
//        self.moreMenu = [[MoreMenuView alloc] init];
//        self.moreMenu.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
//        
//        [self.moreMenu setDelegate:self];
//    }
//}

//#pragma mark===================//、、点击更多2
//- (void)driveViewMoreButtonClicked:(AMapNaviDriveView *)driveView
//{
//    if (_naviDriveView.trackingMode == AMapNaviViewTrackingModeCarNorth)
//    {
//        _naviDriveView.trackingMode = AMapNaviViewTrackingModeMapNorth;
//    }
//    else
//    {
//        _naviDriveView.trackingMode = AMapNaviViewTrackingModeCarNorth;
//    }
//}

//、跟随模式
- (void)moreMenuViewTrackingModeChangeTo:(AMapNaviViewTrackingMode)trackingMode
{
    [_naviDriveView setTrackingMode:trackingMode];
}


#pragma mark - route delegate metho 开始导航 2
- (void)driveManagerOnCalculateRouteSuccess:(AMapNaviDriveManager *)driveManager {
    
    //将naviDriveView添加到AMapNaviDriveManager中
    [_driveManager addDataRepresentative:_naviDriveView];
    
    //将导航视图添加到视图层级中
    [self.view addSubview:_naviDriveView];
    
    //开始实时导航
    [_driveManager startGPSNavi];
}


//#pragma mark - AMapNaviWalkViewDelegate
////、、 停止戴航
- (void)driveViewCloseButtonClicked:(AMapNaviDriveView *)driveView {
    //停止导航
    [_driveManager stopNavi];
    
    //将naviDriveView从AMapNaviDriveManager中移除
    [_driveManager removeDataRepresentative:_naviDriveView];
    
    //停止语音
//    [[SpeechSynthesizer sharedSpeechSynthesizer] stopSpeak];
    
    //将导航视图从视图层级中移除
    [_naviDriveView removeFromSuperview];
    [self.navigationController popViewControllerAnimated:YES];
    self.navigationController.navigationBar.hidden = NO;
    [UIApplication sharedApplication].statusBarHidden = NO;
    
}

//、播放语音 4
- (void)driveManager:(AMapNaviDriveManager *)naviManager
 playNaviSoundString:(NSString *)soundString soundStringType:(AMapNaviSoundType)soundStringType {
    
    NSLog(@"playNaviSoundString:{%ld:%@}", (long)soundStringType, soundString);
    
    if (soundStringType == AMapNaviSoundTypePassedReminder) {
//        AudioServicesPlaySystemSound(1009);//播放系统“叮叮”提示音
    }
    else {
        // 播放语音, 注意在停止导航的时候停止播报语音
//        [[SpeechSynthesizer sharedSpeechSynthesizer] speakString:soundString];
    }
    
}
//、、路径规划失败错误
- (void)driveManager:(AMapNaviDriveManager *)driveManager onCalculateRouteFailure:(NSError *)error
{
    NSLog(@"onCalculateRouteFailure:{%ld - %@}", (long)error.code, error.localizedDescription);
}

//、启动导航后回调、3
- (void)driveManager:(AMapNaviDriveManager *)driveManager didStartNavi:(AMapNaviMode)naviMode
{
    NSLog(@"didStartNavi");
}

//、、路线偏航 重新计算
- (void)driveManagerNeedRecalculateRouteForYaw:(AMapNaviDriveManager *)driveManager
{
    NSLog(@"needRecalculateRouteForYaw");
}

//、  前方遇到拥堵需要重新计算路径时
- (void)driveManagerNeedRecalculateRouteForTrafficJam:(AMapNaviDriveManager *)driveManager
{
    NSLog(@"needRecalculateRouteForTrafficJam");
}

//、导航到达某个途经点的回调
- (void)driveManager:(AMapNaviDriveManager *)driveManager onArrivedWayPoint:(int)wayPointIndex
{
    NSLog(@"onArrivedWayPoint:%d", wayPointIndex);
}


//、、结束导航 模拟导航到达目的地停止导航后的回调函数
- (void)driveManagerDidEndEmulatorNavi:(AMapNaviDriveManager *)driveManager
{
    NSLog(@"didEndEmulatorNavi");
}

//、、已到达目的地
- (void)driveManagerOnArrivedDestination:(AMapNaviDriveManager *)driveManager
{
    NSLog(@"onArrivedDestination");
}

//、导航界面转向指示View点击时的回调函数
- (void)driveViewTrunIndicatorViewTapped:(AMapNaviDriveView *)driveView
{
    NSLog(@"TrunIndicatorViewTapped");
}

//、、暂停导航 继续导航-导航界面显示模式改变后的回调函数
- (void)driveView:(AMapNaviDriveView *)driveView didChangeShowMode:(AMapNaviDriveViewShowMode)showMode
{
    NSLog(@"didChangeShowMode:%ld", (long)showMode);
}






#pragma mark --MAMapViewDelegate
-(MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id<MAAnnotation>)annotation
{
    if ([annotation isKindOfClass:[MAPointAnnotation class]]) {
        static NSString * pointReuseIndentifier = @"pointReuseIndentifier";
        MAPinAnnotationView * annotationView = (MAPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:pointReuseIndentifier];
        if (annotationView == nil) {
            annotationView = [[MAPinAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:pointReuseIndentifier];
        }
        annotationView.canShowCallout = YES;
        annotationView.animatesDrop = YES;
        annotationView.draggable = YES;
        annotationView.pinColor = MAPinAnnotationColorGreen;
    }
    return nil;
}



- (void)amapLocationManager:(AMapLocationManager *)manager didUpdateLocation:(CLLocation *)location
{
    //    if (self.userLocationAnnotationView != nil)
    //    {
    //        [UIView animateWithDuration:0.1 animations:^{
    //
    //            double degree = userLocation.heading.trueHeading - _mapView.rotationDegree;
    //            self.userLocationAnnotationView.transform = CGAffineTransformMakeRotation(degree * M_PI / 180.f );
    //        }];
    //    }
    _lau =location.coordinate.latitude;
    _lon = location.coordinate.longitude;
    
    NSLog(@"location:{lat:%f; lon:%f; accuracy:%f}", location.coordinate.latitude, location.coordinate.longitude, location.horizontalAccuracy);
    
//        [self.locationManager stopUpdatingLocation];
}




//#pragma mark - AMapNaviDriveManagerDelegate
//- (void)driveManagerOnCalculateRouteSuccess:(AMapNaviDriveManager *)driveManager {
//    [driveManager startEmulatorNavi];//开始模拟导航
//}

@end
