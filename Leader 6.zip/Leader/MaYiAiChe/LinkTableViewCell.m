//
//  LinkTableViewCell.m
//  MaYiAiChe
//
//  Created by xc on 17/1/3.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "LinkTableViewCell.h"

#define Width [UIScreen mainScreen].bounds.size.width
#define Height [UIScreen mainScreen].bounds.size.height

@implementation LinkTableViewCell
{
    UILabel * _headLabel;
    UILabel * _priceLabel;
    UIImageView * _headImageView;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _headLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(95), kRelativeHeight(10), kRelativeWidth(100), kRelativeHeight(30))];
        _headLabel.textAlignment = NSTextAlignmentLeft;
        _headLabel.textColor = [UIColor blackColor];
        _headLabel.backgroundColor = [UIColor clearColor];
        _headLabel.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:_headLabel];
        
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(30), kRelativeHeight(10), kRelativeWidth(50), kRelativeHeight(80))];
        _headImageView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_headImageView];
        
        UIImageView * lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, kRelativeWidth(99), Width, kRelativeHeight(1))];
        lineImageView.backgroundColor = [UIColor lightGrayColor];
        [self.contentView addSubview:lineImageView];
        
        _priceLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(95), kRelativeHeight(60), kRelativeWidth(70), kRelativeHeight(30))];
        _priceLabel.textAlignment = NSTextAlignmentLeft;
        _priceLabel.textColor = [UIColor blackColor];
        _priceLabel.backgroundColor = [UIColor clearColor];
        _priceLabel.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:_priceLabel];
            }
    return self;
}
//-(void)btnclick:(UIButton *)btn
//{
//    if (self.delegate && [self.delegate respondsToSelector:@selector(cellDidClickWithBtn:)]) {
//        btn.tag= self.tag;
//        [self.delegate cellDidClickWithBtn:btn];
//    }
//}
-(void)reloadViewName:(NSString *)headLabel priceLabel:(NSString *)priceLabel headImageView:(UIImage *)headImageView
{
    _headLabel.text = headLabel;
    _headImageView.image = headImageView;
    _priceLabel.text = priceLabel;
}
@end
