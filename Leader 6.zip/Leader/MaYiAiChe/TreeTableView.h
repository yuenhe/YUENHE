//
//  TreeTableView.h
//  MaYiAiChe
//
//  Created by xc on 17/2/15.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TreeTableView : UITableView

-(instancetype)initWithFrame:(CGRect)frame withData : (NSArray *)data;
@end
