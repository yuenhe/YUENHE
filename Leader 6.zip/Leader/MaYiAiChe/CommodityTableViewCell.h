//
//  CommodityTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol cellCustomDelegate <NSObject>

-(void)cellDidClick:(UIButton *)btn;

@end
@interface CommodityTableViewCell : UITableViewCell

@property (weak,nonatomic) id <cellCustomDelegate>delegate;

-(void)reloadViewWithName:(NSString *)headLabel FirstLabel:(NSString*)firstLabel nameLabel:(NSString *)nameLabel  telLabel:(NSString *)telLabel adrLabel:(NSString *)adrLabel  headImageView:(UIImage *)headImageView titleImageView:(UIImage *)titleImageView;


@end
