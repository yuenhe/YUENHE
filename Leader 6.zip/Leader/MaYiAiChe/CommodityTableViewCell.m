//
//  CommodityTableViewCell.m
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "CommodityTableViewCell.h"

@implementation CommodityTableViewCell
{
    UILabel * _headLabel;
    UILabel * _fstLabel;
    UILabel * _fstrtLabel;
    UILabel * _nameLabel;
    UILabel * _telLabel;
    UILabel * _adrLabel;
    UILabel * _rfLabel;
    UILabel * _rscLabel;
    UILabel * _dipLabel;
    UIImageView * _headImageView;
    UIImageView * _sexImageView;
    UIButton * _selectedBtn;
    NSIndexPath * _indexpath;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        
        _fstLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(140), kRelativeHeight(45), kRelativeWidth(60), kRelativeHeight(20))];
        _fstLabel.textAlignment = NSTextAlignmentLeft;
        _fstLabel.textColor = [UIColor blackColor];
        //        _fstLabel.adjustsFontSizeToFitWidth = YES;
        _fstLabel.text = @"商品规格：";
        _fstLabel.font = [UIFont systemFontOfSize:12];
        _fstLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_fstLabel];
        
        _headLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(140), kRelativeHeight(10), kRelativeWidth(50), kRelativeHeight(30))];
        _headLabel.textAlignment = NSTextAlignmentLeft;
        _headLabel.textColor = [UIColor blackColor];
        _headLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_headLabel];
        
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(30), kRelativeWidth(100), kRelativeHeight(110))];
        _headImageView.backgroundColor = [UIColor grayColor];
        [self.contentView addSubview:_headImageView];
        
        _fstrtLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(200), kRelativeHeight(45), kRelativeWidth(100), kRelativeHeight(20))];
        _fstrtLabel.textAlignment = NSTextAlignmentLeft;
        _fstrtLabel.textColor = [UIColor blackColor];
        _fstrtLabel.backgroundColor = [UIColor clearColor];
        _fstrtLabel.font = [UIFont systemFontOfSize:12];
        _fstrtLabel.numberOfLines =2;
        [self.contentView addSubview:_fstrtLabel];
        
        _sexImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(140), kRelativeHeight(85), kRelativeWidth(20), kRelativeHeight(20))];
        _sexImageView.backgroundColor = [UIColor grayColor];
        [self.contentView addSubview:_sexImageView];
        
        _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(165), kRelativeHeight(85), kRelativeWidth(50), kRelativeHeight(20))];
        _nameLabel.textAlignment = NSTextAlignmentLeft;
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.font = [UIFont systemFontOfSize:15];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
        
        _telLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(210), kRelativeHeight(85), kRelativeWidth(100), kRelativeHeight(20))];
        _telLabel.layer.masksToBounds = YES;
        _telLabel.layer.cornerRadius = 10;
        _telLabel.backgroundColor = [UIColor blueColor];
        _telLabel.textAlignment = NSTextAlignmentCenter;
        _telLabel.textColor = [UIColor whiteColor];
        _telLabel.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:_telLabel];
        
        UILabel * ddLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(140), kRelativeHeight(115), kRelativeWidth(40), kRelativeHeight(10))];
        ddLabel.textAlignment = NSTextAlignmentLeft;
        ddLabel.textColor = [UIColor blackColor];
        ddLabel.backgroundColor = [UIColor clearColor];
        ddLabel.adjustsFontSizeToFitWidth = YES;
        ddLabel.text = @"地址:";
        ddLabel.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:ddLabel];
        
        _adrLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(175), kRelativeHeight(110), kRelativeWidth(150), kRelativeHeight(20))];
        _adrLabel.textAlignment = NSTextAlignmentLeft;
        _adrLabel.textColor =[UIColor blackColor];
        _adrLabel.backgroundColor = [UIColor clearColor];
        _adrLabel.font = [UIFont systemFontOfSize:12];
        _adrLabel.numberOfLines = 2;
        [self.contentView addSubview:_adrLabel];
        
//        _rfLabel = [[UILabel alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-100, 10, 80, 40)];
//        _rfLabel.text = @"主动接单";
//        _rfLabel.textAlignment = NSTextAlignmentCenter;
//        _rfLabel.textColor = [UIColor orangeColor];
//        _rfLabel.backgroundColor = [UIColor clearColor];
//        _rfLabel.adjustsFontSizeToFitWidth = YES;
//        [self.contentView addSubview:_rfLabel];
//        
//        _rscLabel = [[UILabel alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-100, 45, 80, 20)];
//        _rscLabel.text = @"派送中...";
//        _rscLabel.font = [UIFont systemFontOfSize:15];
//        _rscLabel.textAlignment = NSTextAlignmentCenter;
//        _rscLabel.textColor = [UIColor blackColor];
//        _rscLabel.backgroundColor = [UIColor clearColor];
//        _rscLabel.adjustsFontSizeToFitWidth = YES;
//        [self.contentView addSubview:_rscLabel];
        
        
        _selectedBtn = [[UIButton alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-kRelativeWidth(100), kRelativeHeight(95), kRelativeWidth(80), kRelativeHeight(30))];
        [_selectedBtn setTitle:@"立即接单" forState:UIControlStateNormal];
        [_selectedBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//        [_selectedBtn setTitle:@"开始派送" forState:UIControlStateSelected];
//        [_selectedBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateSelected];
//        [_selectedBtn setTitle:@"完成订单" forState:UIControlStateSelected];
//        [_selectedBtn setTitleColor:[UIColor blueColor] forState:UIControlStateSelected];
        [_selectedBtn addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
        _selectedBtn.backgroundColor = [UIColor greenColor];
        _selectedBtn.tag = 102;
        [self.contentView addSubview:_selectedBtn];
    }
    return self;
}
-(void)btnclick:(UIButton *)btn
{
    if ([self.delegate respondsToSelector:@selector(cellDidClick:)]) {
        btn.tag = self.tag;
        [self.delegate cellDidClick: btn];
    }
}
-(void)reloadViewWithName:(NSString *)headLabel FirstLabel:(NSString *)firstLabel nameLabel:(NSString *)nameLabel telLabel:(NSString *)telLabel adrLabel:(NSString *)adrLabel headImageView:(UIImage *)headImageView titleImageView:(UIImage *)titleImageView
{
    _headLabel.text = headLabel;
    _headImageView.image = headImageView;
    _fstrtLabel.text = firstLabel;
    _nameLabel.text =nameLabel;
    _telLabel.text = telLabel;
    _adrLabel.text = adrLabel;
    _sexImageView.image = titleImageView;
    
}

@end
