//
//  ServiceTableViewCell.m
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "ServiceTableViewCell.h"

@implementation ServiceTableViewCell
 
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
//        
        _fstLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(5), kRelativeWidth(120), kRelativeHeight(30))];
        _fstLabel.textAlignment = NSTextAlignmentLeft;
        _fstLabel.textColor = [UIColor grayColor];
        //        _fstLabel.adjustsFontSizeToFitWidth = YES;
//        _fstLabel.text = @"添加时间：";
        _fstLabel.font = [UIFont systemFontOfSize:12];
        _fstLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_fstLabel];
        
        _timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(100), kRelativeHeight(5), kRelativeHeight(200), kRelativeHeight(30))];
        _timeLabel.textAlignment = NSTextAlignmentLeft;
        _timeLabel.textColor = [UIColor grayColor];
        //        _fstLabel.adjustsFontSizeToFitWidth = YES;
       // _fstLabel.text = @"添加时间：";
        _timeLabel.font = [UIFont systemFontOfSize:12];
        _timeLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_timeLabel];
        
        _headLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(140), kRelativeHeight(40), kRelativeWidth(150), kRelativeHeight(30))];
        _headLabel.textAlignment = NSTextAlignmentLeft;
        _headLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:_headLabel];
        
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(40), kRelativeWidth(100), kRelativeHeight(110))];
        _headImageView.backgroundColor = [UIColor grayColor];
        [self.contentView addSubview:_headImageView];
        
        _fstrtLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(140), kRelativeHeight(75), kRelativeWidth(ScreenWidth-130), kRelativeHeight(20))];
        _fstrtLabel.textAlignment = NSTextAlignmentLeft;
        _fstrtLabel.textColor = [UIColor blackColor];
        _fstrtLabel.font = [UIFont systemFontOfSize:14];
        _fstrtLabel.numberOfLines =2;
        [self.contentView addSubview:_fstrtLabel];
        
        _sexImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(140), kRelativeHeight(100), kRelativeWidth(20), kRelativeHeight(20))];
//        _sexImageView.backgroundColor = [UIColor grayColor];
        _sexImageView.image = [UIImage imageNamed:@"icon_teacher.png"];
        [self.contentView addSubview:_sexImageView];
        
        _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(140), kRelativeHeight(130), kRelativeWidth(300), kRelativeHeight(20))];
        _nameLabel.textAlignment = NSTextAlignmentLeft;
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.font = [UIFont systemFontOfSize:14];
         [self.contentView addSubview:_nameLabel];
        
        _telLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(165), kRelativeHeight(100), kRelativeWidth(100), kRelativeHeight(20))];
        _telLabel.layer.masksToBounds = YES;
        _telLabel.layer.cornerRadius = 10;
        _telLabel.backgroundColor = [UIColor colorWithRed:0/256.0 green:234/256.0 blue:116/256.0 alpha:1];
        _telLabel.textAlignment = NSTextAlignmentCenter;
        _telLabel.textColor = [UIColor whiteColor];
        _telLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_telLabel];
        
        UILabel * ddLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(160), kRelativeWidth(40), kRelativeHeight(10))];
        ddLabel.textAlignment = NSTextAlignmentLeft;
        ddLabel.textColor = [UIColor blackColor];
         ddLabel.adjustsFontSizeToFitWidth = YES;
        ddLabel.text = @"地址:";
        ddLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:ddLabel];
        
        _adrLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(70), kRelativeHeight(155), kRelativeWidth(300), kRelativeHeight(20))];
        _adrLabel.textAlignment = NSTextAlignmentLeft;
        _adrLabel.textColor =[UIColor blackColor];
         _adrLabel.font = [UIFont systemFontOfSize:14];
        _adrLabel.numberOfLines = 2;
        [self.contentView addSubview:_adrLabel];
        
        //        _rfLabel = [[UILabel alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-100, 10, 80, 40)];
        //        _rfLabel.text = @"主动接单";
        //        _rfLabel.textAlignment = NSTextAlignmentCenter;
        //        _rfLabel.textColor = [UIColor orangeColor];
        //        _rfLabel.backgroundColor = [UIColor clearColor];
        //        _rfLabel.adjustsFontSizeToFitWidth = YES;
        //        [self.contentView addSubview:_rfLabel];
        //
        //        _rscLabel = [[UILabel alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-100, 45, 80, 20)];
        //        _rscLabel.text = @"派送中...";
        //        _rscLabel.font = [UIFont systemFontOfSize:15];
        //        _rscLabel.textAlignment = NSTextAlignmentCenter;
        //        _rscLabel.textColor = [UIColor blackColor];
        //        _rscLabel.backgroundColor = [UIColor clearColor];
        //        _rscLabel.adjustsFontSizeToFitWidth = YES;
        //        [self.contentView addSubview:_rscLabel];
        
        
        _selectedBtn = [[UIButton alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-kRelativeWidth(100), kRelativeHeight(95), kRelativeWidth(80), kRelativeHeight(30))];
//        [_selectedBtn setTitle:@"" forState:UIControlStateNormal];
        [_selectedBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        //        [_selectedBtn setTitle:@"开始派送" forState:UIControlStateSelected];
        //        [_selectedBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateSelected];
        //        [_selectedBtn setTitle:@"完成订单" forState:UIControlStateSelected];
        //        [_selectedBtn setTitleColor:[UIColor blueColor] forState:UIControlStateSelected];
        [_selectedBtn addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
        _selectedBtn.backgroundColor = [UIColor greenColor];
        _selectedBtn.tag = 102;
        [self.contentView addSubview:_selectedBtn];

 /*
        _fstLabel = [[UILabel alloc]initWithFrame:CGRectMake(10,  5,  120,  30)];
        _fstLabel.textAlignment = NSTextAlignmentLeft;
        _fstLabel.textColor = [UIColor grayColor];
        //        _fstLabel.adjustsFontSizeToFitWidth = YES;
        //        _fstLabel.text = @"添加时间：";
        _fstLabel.font = [UIFont systemFontOfSize:12];
        _fstLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_fstLabel];
        
        _timeLabel = [[UILabel alloc]initWithFrame:CGRectMake( 70,  5, 200,  30)];
        _timeLabel.textAlignment = NSTextAlignmentLeft;
        _timeLabel.textColor = [UIColor grayColor];
        //        _fstLabel.adjustsFontSizeToFitWidth = YES;
        // _fstLabel.text = @"添加时间：";
        _timeLabel.font = [UIFont systemFontOfSize:12];
        _timeLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_timeLabel];
        
        _headLabel = [[UILabel alloc]initWithFrame:CGRectMake(140,  40,  150,  30)];
        _headLabel.textAlignment = NSTextAlignmentLeft;
        _headLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:_headLabel];
        
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake( 20,  40,  100,  110)];
        _headImageView.backgroundColor = [UIColor grayColor];
        [self.contentView addSubview:_headImageView];
        
        _fstrtLabel = [[UILabel alloc]initWithFrame:CGRectMake(140,  75, ScreenWidth-130, 20)];
        _fstrtLabel.textAlignment = NSTextAlignmentLeft;
        _fstrtLabel.textColor = [UIColor blackColor];
        _fstrtLabel.font = [UIFont systemFontOfSize:14];
        _fstrtLabel.numberOfLines =2;
        [self.contentView addSubview:_fstrtLabel];
        
        _sexImageView = [[UIImageView alloc]initWithFrame:CGRectMake(140,  100,  20,  20)];
        //        _sexImageView.backgroundColor = [UIColor grayColor];
        _sexImageView.image = [UIImage imageNamed:@"icon_teacher.png"];
        [self.contentView addSubview:_sexImageView];
        
        _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(140,  130,  300,  20)];
        _nameLabel.textAlignment = NSTextAlignmentLeft;
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_nameLabel];
        
        _telLabel = [[UILabel alloc]initWithFrame:CGRectMake(165,  100,  100,  20)];
        _telLabel.layer.masksToBounds = YES;
        _telLabel.layer.cornerRadius = 10;
        _telLabel.backgroundColor = [UIColor colorWithRed:0/256.0 green:234/256.0 blue:116/256.0 alpha:1];
        _telLabel.textAlignment = NSTextAlignmentCenter;
        _telLabel.textColor = [UIColor whiteColor];
        _telLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_telLabel];
        
        UILabel * ddLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 160, 40, 10)];
        ddLabel.textAlignment = NSTextAlignmentLeft;
        ddLabel.textColor = [UIColor blackColor];
        ddLabel.adjustsFontSizeToFitWidth = YES;
        ddLabel.text = @"地址:";
        ddLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:ddLabel];
        
        _adrLabel = [[UILabel alloc]initWithFrame:CGRectMake(70, 155, 300, 20)];
        _adrLabel.textAlignment = NSTextAlignmentLeft;
        _adrLabel.textColor =[UIColor blackColor];
        _adrLabel.font = [UIFont systemFontOfSize:14];
        _adrLabel.numberOfLines = 2;
        [self.contentView addSubview:_adrLabel];
        
        //        _rfLabel = [[UILabel alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-100, 10, 80, 40)];
        //        _rfLabel.text = @"主动接单";
        //        _rfLabel.textAlignment = NSTextAlignmentCenter;
        //        _rfLabel.textColor = [UIColor orangeColor];
        //        _rfLabel.backgroundColor = [UIColor clearColor];
        //        _rfLabel.adjustsFontSizeToFitWidth = YES;
        //        [self.contentView addSubview:_rfLabel];
        //
        //        _rscLabel = [[UILabel alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-100, 45, 80, 20)];
        //        _rscLabel.text = @"派送中...";
        //        _rscLabel.font = [UIFont systemFontOfSize:15];
        //        _rscLabel.textAlignment = NSTextAlignmentCenter;
        //        _rscLabel.textColor = [UIColor blackColor];
        //        _rscLabel.backgroundColor = [UIColor clearColor];
        //        _rscLabel.adjustsFontSizeToFitWidth = YES;
        //        [self.contentView addSubview:_rscLabel];
        
        
        _selectedBtn = [[UIButton alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-100, 95, 80, 30)];
        //        [_selectedBtn setTitle:@"" forState:UIControlStateNormal];
        [_selectedBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        //        [_selectedBtn setTitle:@"开始派送" forState:UIControlStateSelected];
        //        [_selectedBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateSelected];
        //        [_selectedBtn setTitle:@"完成订单" forState:UIControlStateSelected];
        //        [_selectedBtn setTitleColor:[UIColor blueColor] forState:UIControlStateSelected];
        [_selectedBtn addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
        _selectedBtn.backgroundColor = [UIColor greenColor];
        _selectedBtn.tag = 102;
        [self.contentView addSubview:_selectedBtn];

    */
        
    }
    return self;
}
-(void)btnclick:(UIButton *)btn
{
    if ([self.delegate respondsToSelector:@selector(cellServicDidCLick:WithBtn:)]) {
        btn.tag = self.tag;
        [self.delegate cellServicDidCLick:self WithBtn:btn];
    }
}

-(void)setModel:(ServiceModel *)model{
    _model = model;
    _headLabel.text = model.fuwu;
    NSURL * url = [NSURL URLWithString:model.logo];
    _headImageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:url]];
     _fstrtLabel.text = model.title;
    _nameLabel.text =model.carstlye;
    _telLabel.text = model.phonenum;
    _adrLabel.text = model.adress;
    //    _sexImageView.image = titleImageView;
//    _timeLabel.text = model.addtime;
    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm"];
//    NSLog(@"----------------%@-----------------%@--------------%@-------",model.logo,model.status,model.lat);
    if ([_model.status isEqualToString:@"1"]) {
//        _selectedBtn.titleLabel.text = @"";
        _timeLabel.text = model.addtime;
       _fstLabel.text = @"预约时间：";
         [_selectedBtn setTitle:@"立即接单" forState:UIControlStateNormal];
    }else if ([_model.status isEqualToString:@"2"]){
//         _selectedBtn.titleLabel.text = @"";
        // 将时间戳转成时间
         NSDate * date = [NSDate dateWithTimeIntervalSince1970:[model.jiedan_time doubleValue]];
        //    NSLog(@"--%@--",date);
        NSString * stt = [dateFormatter stringFromDate:date];
        _timeLabel.text = stt;
          _fstLabel.text = @"接单时间：";
         [_selectedBtn setTitle:@"已接单" forState:UIControlStateNormal];
    }else{
//       _selectedBtn.titleLabel.text = @"";
        // 将时间戳转成时间
        NSDate * date = [NSDate dateWithTimeIntervalSince1970:[model.start_time doubleValue]];
        //    NSLog(@"--%@--",date);
        NSString * stt = [dateFormatter stringFromDate:date];
        _timeLabel.text = stt;
        _fstLabel.text = @"服务时间：";
         [_selectedBtn setTitle:@"服务中" forState:UIControlStateNormal];
     }
    
}

//
//-(void)reloadViewWithName:(NSString *)headLabel FirstLabel:(NSString *)firstLabel nameLabel:(NSString *)nameLabel telLabel:(NSString *)telLabel adrLabel:(NSString *)adrLabel headImageView:(UIImage *)headImageView titleImageView:(UIImage *)titleImageView addtime:(NSString *)addtime
//{
//    _headLabel.text = headLabel;
//    _headImageView.image = headImageView;
//    _fstrtLabel.text = firstLabel;
//    _nameLabel.text =nameLabel;
//    _telLabel.text = telLabel;
//    _adrLabel.text = adrLabel;
////    _sexImageView.image = titleImageView;
//    _timeLabel.text = addtime;
//    
//}

@end
