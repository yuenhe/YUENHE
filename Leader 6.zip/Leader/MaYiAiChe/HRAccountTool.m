//
//  HRAccountTool.m
//  MaYiAiChe
//
//  Created by xc on 17/1/12.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "HRAccountTool.h"

@implementation HRAccountTool

+(void)saveAccount:(NSArray *)account
{
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    //保存数据 用户信息；用户名；用户密码；用户id
    [userDefaults setObject:account forKey:@"account"];
    [userDefaults setObject:[account objectAtIndex:0] forKey:@"c_name"];
    [userDefaults setObject:[account objectAtIndex:1] forKey:@"c_pwd"];
    [userDefaults setObject:[account objectAtIndex:2] forKey:@"s_userid"];
    
    
    
}
+(NSArray *)getAccount
{
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    NSArray * array = [userDefaults objectForKey:@"account" ];
    return array;
}
+(NSString *)getUserName
{
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    NSString * userName = [userDefaults objectForKey:@"c_name"];
    return userName;
    
}
+(NSString *)getPossWord
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString * possWord = [userDefaults objectForKey:@"c_pwd"];
    NSLog(@"%@",possWord);
    return possWord;
}
+(NSString *)getUserID
{
    NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
    NSString * userId = [userDefaults objectForKey:@"s_userid"];
    NSLog(@"%@",userId);
    return userId;
}

@end
