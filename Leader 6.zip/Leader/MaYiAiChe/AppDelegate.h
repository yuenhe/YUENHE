//
//  AppDelegate.h
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataCenter.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    NSString * _useID;

}

@property (strong, nonatomic) UIWindow *window;
@property float autoSizeScaleX;
@property float autoSizeScaleY;
-(UIImage *)scaleImage:(UIImage *)image toSize:(CGSize)theTize;//图片压缩到指定CGSize大小

@property (nonatomic,strong)NSString * userPhone; // 账号输入框
@property (nonatomic,strong)NSString * userPassword;  // 密码输入框
@property (nonatomic, strong) DataCenter * data;


@end

