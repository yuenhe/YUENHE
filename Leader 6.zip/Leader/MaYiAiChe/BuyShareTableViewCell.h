//
//  BuyShareTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 17/2/14.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>
#define kCellIdentifier_Right @"BuyShareTableViewCell"
@interface BuyShareTableViewCell : UITableViewCell

@end
