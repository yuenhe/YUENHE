//
//  MadeshareTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 16/12/27.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MycellDelegate <NSObject>

-(void)cellDidClickWithIndexpath:(NSIndexPath *)indexpath;

@end
@interface MadeshareTableViewCell : UITableViewCell
@property (weak,nonatomic) id <MycellDelegate>delegate;

-(void)reloadViewWithName:(NSString *)headLabel imageView:(UIImage *)imageView showStatus:(NSInteger)showstatus;
@end
