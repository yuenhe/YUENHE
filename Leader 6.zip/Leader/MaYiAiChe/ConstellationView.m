//
//  ConstellationView.m
//  MaYiAiChe
//
//  Created by xc on 17/1/5.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "ConstellationView.h"
#define VWidth(v)   (v).frame.size.width
#define VHeight(v)   (v).frame.size.height
#define VWIDTH(v)   (v).frame.size.width + (v).frame.origin.x
#define VHEIGHT(v)  (v).frame.size.height + (v).frame.origin.y
#define kTextColor                      [UIColor darkGrayColor]
#define kBorderColor                    [UIColor colorWithRed:219/255.0 green:217/255.0 blue:216/255.0 alpha:1]

@implementation ConstellationView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //Initialization code
    }
    return self;
}
-(void)setControlsViewOriginx:(int)originx ViewOriginy:(int)originy TextWidth:(int)textwidth TextAndButtonHigth:(int)hight ButtonWidth:(int)buttonwidth TableHigth:(int)tableHight Editortype:(BOOL)type
{
    self.backgroundColor = [UIColor whiteColor];
    CGRect rect = self.frame;
    rect.size.height = hight;
    rect.size.width = textwidth+buttonwidth;
    rect.origin.x = originx;
    rect.origin.y = originy;
    self.frame = rect;
    
    _view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, hight)];
    [self addSubview:_view];
    
    _textfiled = [[UITextField alloc]initWithFrame:CGRectMake(0, 0, textwidth, hight)];
    _textfiled.userInteractionEnabled = YES;
    [self addSubview:_textfiled];
    
    _buttonImageFlag = YES;
    _button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _button.frame = CGRectMake(VWidth(_textfiled), 0, buttonwidth, hight);
    [_button addTarget:self action:@selector(tableShowAndHide:) forControlEvents:UIControlEventTouchUpInside];
    _imageview  = [[UIImageView alloc]initWithFrame:CGRectMake(5, 10, 10, 10)];
    _imageview.image = [UIImage imageNamed:@"下拉"];
    [_button addSubview:_imageview];
    [self addSubview: _button];
    
    _tableview = [[UITableView alloc]initWithFrame:CGRectMake(0, VHEIGHT(_textfiled), textwidth+buttonwidth, tableHight) style:UITableViewStylePlain];
    _tableview.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableview.hidden = YES;
    _tableview.delegate = self;
    _tableview.dataSource = self;
    _tableview.layer.borderColor = (__bridge CGColorRef)(kBorderColor);
    _tableview.layer.borderWidth = 0.5;
    [self addSubview:_tableview];
    
}
-(void)tableShowAndHide:(UIButton *)btn
{
    if (_buttonImageFlag == YES) {
        [self reloadataTableview];
        CGRect rect = self.frame;
        rect.size.height = _textfiled.frame.size.height+_tableview.frame.size.height;
        self.frame = rect;
        _buttonImageFlag = NO;
        _imageview.transform = CGAffineTransformMakeScale(1.0, -1.0);
        _tableview.hidden = NO;
        
    }else
    {
        [self closeTableview];
    }
}
-(void)reloadataTableview
{
    [_tableview reloadData];
}
-(void)closeTableview
{
    _buttonImageFlag = YES;
    CGRect rect = self.frame;
    rect.size.height = _textfiled.frame.size.height;
    self.frame = rect;
    _imageview.transform = CGAffineTransformMakeScale(1.0, 1.0);
    _tableview.hidden = YES;
}
#pragma mark Tableview delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _arr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cellIdc = @"cell";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellIdc];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdc];
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(2, 0, self.frame.size.width-4, 30)];
        label.font = [UIFont systemFontOfSize:16];
        label.textAlignment = NSTextAlignmentLeft;
        [cell addSubview:label];
        
        UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 30, self.frame.size.width, 0.5)];
        imageView.backgroundColor = kBorderColor;
        [cell addSubview:imageView];
    }
    cell.textLabel.text = _arr[indexPath.row];
    return cell;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(tableView.frame.origin.x, 0, tableView.frame.size.width, 0)];
    return view;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30.5;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _textfiled.text =_arr[indexPath.row];
    [self closeTableview];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if ([_delegate respondsToSelector:@selector(selectedAtIndex:WithConstellation:)]) {
        [_delegate selectedAtIndex:(int)indexPath.row WithConstellation:self];
    }
    
    
    
}
@end
