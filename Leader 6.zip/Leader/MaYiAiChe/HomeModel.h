//
//  HomeModel.h
//  MaYiAiChe
//
//  Created by xc on 17/1/16.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface HomeModel : NSObject
@property (nonatomic,copy) NSString * itemName;
@property (nonatomic,copy) NSString * time;
@property (nonatomic,copy) NSString * picUrl;
@property (nonatomic,copy) NSString * headPicUrl;
@property (nonatomic,copy) NSString * footPicUrl;

@end
