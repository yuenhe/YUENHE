//
//  PayController.m
//  MaYiAiChe
//
//  Created by xc on 17/2/14.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "PayController.h"
#import "AFNetworking.h"
#import <AlipaySDK/AlipaySDK.h>
#import "Order.h"
#import "AlertViewContr.h"

@interface PayController ()
@property (nonatomic,strong)UIButton * selectedBtn;
@property (nonatomic,strong)NSString * alipayOrder;
@property (nonatomic,strong)NSString * index;
@end
@implementation PayController
{
    UIView *_mynavigationBar;
    UIButton * _backLabel;
    UILabel * _titleLabel;
    UILabel * _payLabel;
    UIButton * _payBtn;
    
}
-(void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:238.0/255 green:238.0/255 blue:238.0/255 alpha:1];
    self.navigationController.navigationBarHidden = YES;
    //自定义navigationbar
    _mynavigationBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, kRelativeHeight(64))];
    _mynavigationBar.backgroundColor = [UIColor greenColor];
    [self.view addSubview:_mynavigationBar];
    //返回item
    _backLabel = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(5), kRelativeHeight(25), kRelativeWidth(30), kRelativeHeight(30))];
    _backLabel.backgroundColor = [UIColor clearColor];
    [_backLabel setImage:[UIImage imageNamed:@"backwhite"] forState:UIControlStateNormal];
    [_backLabel addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigationBar addSubview:_backLabel];
    
    //title
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-kRelativeWidth(100), kRelativeHeight(22), kRelativeWidth(200), kRelativeHeight(40))];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text =@"支付界面";
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.font = [UIFont systemFontOfSize:25];
    [_mynavigationBar addSubview:_titleLabel];
    [self initUI];
//    [self initNet];

}
//返回上一页
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)initUI
{
    UILabel * wpayLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(30), kRelativeHeight(120), kRelativeWidth(120), kRelativeHeight(40))];
    wpayLabel.textAlignment = NSTextAlignmentLeft;
    wpayLabel.textColor = [UIColor grayColor];
    wpayLabel.backgroundColor = [UIColor clearColor];
    wpayLabel.text = @"待支付:";
    wpayLabel.font = [UIFont systemFontOfSize:18];
    [self.view addSubview:wpayLabel];
    
    _payLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(100), kRelativeHeight(120), kRelativeWidth(120), kRelativeHeight(40))];
    _payLabel.textAlignment = NSTextAlignmentLeft;
    _payLabel.textColor = [UIColor orangeColor];
    _payLabel.backgroundColor = [UIColor clearColor];
    _payLabel.text = @"100.00";
    _payLabel.font = [UIFont systemFontOfSize:18];
    [self.view addSubview:_payLabel];
    
    UIView * mainView = [[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(25), kRelativeHeight(170), ScreenWidth-kRelativeWidth(50), kRelativeHeight(245))];
    mainView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:mainView];
    
    UILabel * paystyLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(10), kRelativeWidth(150), kRelativeHeight(30))];
    paystyLabel.textAlignment = NSTextAlignmentLeft;
    paystyLabel.textColor = [UIColor grayColor];
    paystyLabel.backgroundColor = [UIColor clearColor];
    paystyLabel.text = @"支付方式";
    paystyLabel.font = [UIFont systemFontOfSize:15];
    [mainView addSubview:paystyLabel];
    
    for (int i = 0; i<3; i++) {
        float height =kRelativeHeight(60);
        NSArray * imageArr = [NSArray arrayWithObjects:@"icon_balance",@"icon_alipay",@"icon_wechat" ,nil];
        NSArray * titleArr = [NSArray arrayWithObjects:@"余额支付",@"支付宝",@"微信钱包", nil];
        
        UIImageView * imageview = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeHeight(10), kRelativeHeight(55)+height*i, kRelativeWidth(45), kRelativeHeight(45))];
        imageview.backgroundColor = [UIColor clearColor];
        imageview.layer.masksToBounds = YES;
        imageview.layer.cornerRadius = 5;
        imageview.image = [UIImage imageNamed:[imageArr objectAtIndex:i]];
        [mainView addSubview:imageview];
        
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(65), kRelativeHeight(62.5)+height*i, kRelativeWidth(120), kRelativeHeight(25))];
        label.textAlignment = NSTextAlignmentLeft;
        label.textColor = [UIColor grayColor];
        label.backgroundColor = [UIColor clearColor];
        label.text = [titleArr objectAtIndex:i];
        label.font = [UIFont systemFontOfSize:15];
        [mainView addSubview:label];
        
        _payBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _payBtn.frame = CGRectMake(mainView.frame.size.width-kRelativeWidth(40), kRelativeHeight(62.5)+height*i, kRelativeWidth(30), kRelativeHeight(30));
        _payBtn.backgroundColor = [UIColor clearColor];
        [_payBtn setImage:[UIImage imageNamed:@"未勾选"] forState:UIControlStateNormal];
        [_payBtn setImage:[UIImage imageNamed:@"勾选"] forState:UIControlStateSelected];
       
        [_payBtn addTarget:self action:@selector(payclick:) forControlEvents:UIControlEventTouchUpInside];
        _payBtn.tag = 100+i;
        [mainView addSubview:_payBtn];
    }
    UIButton * sureBtn = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(25), kRelativeHeight(440), ScreenWidth-kRelativeWidth(50), kRelativeHeight(60))];
    sureBtn.backgroundColor = [UIColor colorWithRed:235.0/255 green:117.0/255 blue:101.0/255 alpha:1];
    [sureBtn setTitle:@"确认支付" forState:UIControlStateNormal];
    [sureBtn setTintColor:[UIColor whiteColor]];
    [sureBtn addTarget:self action:@selector(sureclick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sureBtn];
}
-(void)payclick:(UIButton *)btn
{
    btn.selected = !btn.selected;
    if (btn!=self.selectedBtn) {
        self.selectedBtn.selected = NO;
        self.selectedBtn = btn;
    }
    self.selectedBtn.selected = YES;
    _index = [NSString stringWithFormat:@"%ld",(long)btn.tag];
    NSLog(@"----选择了--%@",_index);
}

-(void)sureclick
{
    if ([_index isEqualToString:@"101"]) {
        [self doAliPay];
    }
}
-(void)doAliPay
{
    NSString *appID = @"2016122104472746";
    //    NSString *appID = @"2016102400751082";
    
    NSString *privateKey = @"MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAPU1cDwxEdBVIw2MQMgEa8Sipa1MsndZYrKkd3cy0O/SYkr66hYdrGK78OI8Ii+AOb6Belyjx9u/tImqLeWLDaw/c9JWp1ZVH6oDJ7QQbvjWa/q9doRQ2hA92oWxJa2jEgHr6bY2t6f650dfUEeqYLIShr148a6vQMIvqvEPoPFDAgMBAAECgYAaHqAe+UchfwAl4EvCQp5MKtslE6drCS13RAepvdL9yNZJkGLBClYjikuFfcxSbQE5pscm+Rc/9DLB+0u6SM6i1hpy2iJvzBp9/nCOAc9GMWVzIAA+nLUbH6+zTL8zX7pfqxOOyq0ymMRmhpitocPYC7ASXCYxUISymXAv0E2BsQJBAPykLwSVtm3YlzqJWLSydEG8mmqstb5mdX4KYtTLKQJZhUQ/bBaPF/Q/Jr71bcUtSUO/mV2gkrs/8f1oJ2ZK1vsCQQD4d/WWvjNfzfITXtzwrvx4Y1/6EVRZealQtNp+F0JUTsAAxHDXcLiV22H5Ym8FFkyywckLawTAQo9bad6n7lxZAkEAhElEBVaPK31Z0mDQfe1jSniDMpA0qfnkU5cEoP+v/Xb6fP3ojvdmR5I5q4u/apuH3V2Z5JiLvFiDUXkUCE/vuQJAOQ/7s+nsjIUUokQ4A4J8cv2Hjjuqnn3lV6ahQzH+RrRrPgHfVGsLyUa/4nErxARSCv+cN2YVij3/BGR1ASYpyQJBAJ/TNHj1P64bs3lIVj8fvmEwTMGELej9te3hw746pNtwDNmnusONG2j90zVHvpiCXEdJsW4rKDLrXQe+X3W2SvM=";
    //partner和seller获取失败,提示     (这里判断你有没有填写appID和私钥)
    if ([appID length] == 0 || [privateKey length] == 0)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"缺少appId或者私钥。" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
        return;
    }
    //    (下面就是一些订单信息的设置)
    
    /*
     *生成订单信息及签名
     */
    //将商品信息赋予AlixPayOrder的成员变量
    Order* order = [[Order alloc]init];
    // NOTE: app_id设置
    order.app_id = appID;
    // NOTE: 支付接口名称
    order.method = @"alipay.trade.app.pay";
    // NOTE: 参数编码格式
    order.charset = @"utf-8";
    
    // NOTE: 当前时间点
    NSDateFormatter* formatter = [NSDateFormatter new];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    //    [formatter setDateFormat:@"yyyy-MM-dd"];
    order.timestamp = [formatter stringFromDate:[NSDate date]];
    
    order.notify_url = @"http://www.xxx.com"; //回调URL
    // NOTE: 支付版本
    order.version = @"1.0";
    // NOTE: sign_type设置
    order.sign_type = @"RSA";
    
    // NOTE: 商品数据
    order.biz_content = [BizContent new];
    order.biz_content.body = @"我是测试数据132321";     // 描述内容
    order.biz_content.subject = @"汽车坐垫真皮保证223233";        // 订单信息
    order.biz_content.out_trade_no = [self generateTradeNO]; //订单ID（由商家自行制定）
    NSString *orderNo   = [NSString stringWithFormat:@"%ld",time(0)];
    order.biz_content.timeout_express = @"30m"; //超时时间设置
    order.biz_content.total_amount = [NSString stringWithFormat:@"%.2f", 0.02]; //商品价格
    order.biz_content.seller_id = @"2088521141966090";  // 收款支付宝用户ID 2088324
    // 拼接的长订单
    NSString * orderNO = [NSString stringWithFormat:@"%@%@",order.biz_content.out_trade_no,orderNo];
    
    _alipayOrder  = orderNO;        // 支付宝支付订单号
    
    NSLog(@"==支付宝支付订单号===%@",_alipayOrder);
    
    
    
    NSDictionary *  ddd  = @{@"total_amount":@"0.01",@"subject":@"汽车坐垫真皮保证"};
    NSString * json5 = [self dictionaryToJson:ddd];
    NSDictionary * dd = @{@"order_info":json5};
    
    
    AFHTTPSessionManager   * mager = [AFHTTPSessionManager manager];
    
    mager.responseSerializer = [AFHTTPResponseSerializer  serializer];
    //    http://192.168.0.131/MultiPay/examples/ali/Alipay.php
    [mager POST:@"http://115.29.172.223/alipay/alipay.php" parameters:dd progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSString * signedString = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
        
        NSLog(@"--服务器返回--%@",signedString);
        
        
        if (signedString != nil) {
            //应用注册scheme,在AliSDKDemo-Info.plist 定义URL types
            //        NSString *appScheme = @"alisdkdemo";
            NSString *appScheme = @"mayiaiche";
            // NOTE: 将签名成功字符串格式化为订单字符串,请严格按照该格式
            
            //        //       / (这里就是开始正常的支付了) KEEYISDHIDJS
            //        // NOTE: 调用支付结果开始支付
            [[AlipaySDK defaultService] payOrder:signedString fromScheme:appScheme callback:^(NSDictionary *resultDic) {
                
                NSLog(@"reslut = %@",resultDic);
                if ([resultDic[@"resultStatus"]intValue] == 9000) {
                    NSLog(@"成功");
                    AlertViewContr * alert  = [[AlertViewContr alloc]initWithTitle:@"支付成功" message:nil sureBtn:@"" cancleBtn:nil];
                    [alert showXLAlertView];
                } else {
                    NSLog(@"失败");
                }
            }];
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        NSLog(@"%@",error.localizedDescription);
    }];

}
#pragma mark=================== 订单随机
-(NSString *)generateTradeNO
{
    const int count =8;
    NSString * sourceString=@"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    NSMutableString *re=[[NSMutableString alloc]init];
    for (int i = 0; i < count; i++) {
        unsigned index=rand()%[sourceString length];
        NSString * s=[sourceString substringWithRange:NSMakeRange(index, 1)];
        [re appendString:s];
    }
    return re;
}


//、字典 转json
-(NSString*)dictionaryToJson:(NSDictionary *)dic

{
    NSError *parseError = nil;
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
}
@end
