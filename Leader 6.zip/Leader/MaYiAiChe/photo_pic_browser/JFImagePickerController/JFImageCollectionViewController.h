//
//  JFImageCollectionViewController.h
//  JFImagePickerController
//
//  Created by Johnil on 15-7-3.
//  Copyright (c) 2014年 Johnil. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JFImageCollectionViewController : UIViewController

- (UICollectionView *)collectionView;

@end
