//
//  WSImageBroserCell.h
//  doucui
//
//  Created by 吴振松 on 16/10/12.
//  Copyright © 2016年 lootai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WSImageModel.h"

@interface WSImageBroserCell : UICollectionViewCell
@property (nonatomic, strong) WSImageModel *model;

@end
