//
//  WSImageModel.m
//  doucui
//
//  Created by 吴振松 on 16/10/12.
//  Copyright © 2016年 lootai. All rights reserved.
//

#import "WSImageModel.h"

@implementation WSImageModel

@end
