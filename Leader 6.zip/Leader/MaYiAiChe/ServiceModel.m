//
//  ServiceModel.m
//  MaYiAiChe
//
//  Created by xc on 17/1/20.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "ServiceModel.h"

@implementation ServiceModel

@end
