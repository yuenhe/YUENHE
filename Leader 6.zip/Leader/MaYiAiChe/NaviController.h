//
//  NaviController.h
//  MaYiAiChe
//
//  Created by xc on 17/2/9.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NaviController : UIViewController

@property (nonatomic,assign) double latitude; // 终点 经度
@property (nonatomic,assign) double longitude;   // 终点 维度


@end
