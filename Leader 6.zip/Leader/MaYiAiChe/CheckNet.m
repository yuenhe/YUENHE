//
//  CheckNet.m
//  MaYiAiChe
//
//  Created by xc on 17/1/16.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "CheckNet.h"
#import "AFNetworking.h"

@implementation CheckNet

-(void)judgeNetState
{
    AFHTTPSessionManager * manager = [[AFHTTPSessionManager alloc]initWithBaseURL:[NSURL URLWithString:@"http://baidu.com"]];
    [manager.reachabilityManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        /*
         AFNetworkReachabilityStatusNotReachable     = 0,
         没有连接网络
         AFNetworkReachabilityStatusReachableViaWWAN = 1,
         当前网络是无线广域网（3G/4G/GPS/2G）
         AFNetworkReachabilityStatusReachableViaWiFi = 2,
         当前网络是wifi
         */
        if (status == AFNetworkReachabilityStatusNotReachable) {
            NSLog(@"---没有连接网络");
        }else if (status == AFNetworkReachabilityStatusReachableViaWWAN)
        {
            NSLog(@"---3G/4G/GPS等无形广域网");
        }else if (status == AFNetworkReachabilityStatusReachableViaWiFi)
        {
            NSLog(@"---wifi");
        }

    }];
    [manager.reachabilityManager startMonitoring];
}

@end
