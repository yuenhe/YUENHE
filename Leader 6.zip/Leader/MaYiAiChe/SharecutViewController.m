//
//  SharecutViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/23.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "SharecutViewController.h"

@interface SharecutViewController ()<UITextFieldDelegate>
{
    UIView *_mynavigationBar;
    UIButton * _backLabel;
    UILabel * _titleLabel;
    UITextField * _numTextField;
}

@end

@implementation SharecutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];
    self.navigationController.navigationBar.hidden = YES;
    //自定义navigationbar
    _mynavigationBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 64)];
    _mynavigationBar.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_mynavigationBar];
    //返回item
    _backLabel = [[UIButton alloc]initWithFrame:CGRectMake(5, 25, 30, 30)];
    _backLabel.backgroundColor = [UIColor clearColor];
    _backLabel.tag = 100;
    [_backLabel setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [_backLabel addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigationBar addSubview:_backLabel];
    
    //title
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-100, 22, 200, 40)];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text =@"股东撤资";
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor blackColor];
    _titleLabel.font = [UIFont systemFontOfSize:25];
    [_mynavigationBar addSubview:_titleLabel];
    //创建店铺图片
    UIImageView * potoImageView = [[UIImageView alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-50, 120, 100, 100)];
    potoImageView.backgroundColor = [UIColor lightGrayColor];
    potoImageView.layer.masksToBounds = YES;
    potoImageView.layer.cornerRadius = 50;
    [self.view addSubview:potoImageView];
    
    [self createMenuView];
    //确认按钮
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setFrame:CGRectMake(20, 550, self.view.frame.size.width-40, 40)];
    [btn setTitle:@"我要减资" forState:UIControlStateNormal];
    [btn setTintColor:[UIColor whiteColor]];
    btn.backgroundColor = [UIColor greenColor];
    [btn addTarget:self action:@selector(btncutclick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    

    // Do any additional setup after loading the view.
}
//跳转上一界面
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//创建view
-(void)createMenuView
{
    UIView * menuView = [[UIView alloc]initWithFrame:CGRectMake(20, 250, self.view.frame.size.width-40, 250)];
    menuView.backgroundColor = [UIColor whiteColor];
    menuView.layer.borderWidth = 1.0;
    menuView.layer.borderColor = [[UIColor greenColor]CGColor];
    [self.view addSubview:menuView];
    NSArray * titleArray = [NSArray arrayWithObjects:@"店铺名称",@"店铺地址",@"撤出资金", nil];
    NSArray * textArray = [NSArray arrayWithObjects:@"xxxxxxx",@"xxxxxxx", nil];
    //创建店铺名称，地址，撤出资金
    for (int i = 0; i<3; i++) {
        float height = 80;
        UILabel * titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(40, 20+height*i, 80, 30)];
        titleLabel.textAlignment = NSTextAlignmentLeft;
        titleLabel.textColor = [UIColor lightGrayColor];
        titleLabel.font = [UIFont systemFontOfSize:20];
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.text = [titleArray objectAtIndex:i];
        [menuView addSubview:titleLabel];
    }
    //创建输入内容
    for (int t = 0; t<2; t++) {
        float height = 80;
        UILabel * textLabel = [[UILabel alloc]initWithFrame:CGRectMake(130, 20+height*t, 200, 30)];
        textLabel.textAlignment = NSTextAlignmentLeft;
        textLabel.backgroundColor = [UIColor clearColor];
        textLabel.font = [UIFont systemFontOfSize:20];
        if (t == 2) {
            textLabel.textColor = [UIColor orangeColor];
        }else{
            textLabel.textColor = [UIColor blackColor];
        }
        textLabel.text =[textArray objectAtIndex:t];
        [menuView addSubview:textLabel];
    }
    //创建输入框
    for (int s = 0 ; s<2; s++) {
        float width = 120;
       _numTextField = [[UITextField alloc]initWithFrame:CGRectMake(130+width*s, 180, 80, 30)];
        _numTextField.textAlignment = NSTextAlignmentLeft;
        _numTextField.textColor = [UIColor blackColor];
        _numTextField.borderStyle = UITextBorderStyleLine;
        _numTextField.layer.borderWidth = 1.0;
        _numTextField.layer.borderColor = [[UIColor blackColor]CGColor];
        //再次编辑就清空
        _numTextField.clearsOnBeginEditing = YES;
        //内容对齐方式
        _numTextField.textAlignment = NSTextAlignmentLeft;
        //设置键盘的样式
        _numTextField.keyboardType =UIKeyboardTypeDefault;
        //return键变成什么键
        _numTextField.returnKeyType = UIReturnKeyDone;
        //设置代理 用于实现协议
        _numTextField.delegate =self;
        _numTextField.tag = 100+s;
        [menuView addSubview:_numTextField];
        
        NSArray * nameArray = [NSArray arrayWithObjects:@"股",@"元", nil];
        
        UILabel  * headLabel = [[UILabel alloc]initWithFrame:CGRectMake(210+width*s, 180, 30, 30)];
        headLabel.textAlignment = NSTextAlignmentLeft;
        headLabel.textColor = [UIColor blackColor];
        headLabel.font = [UIFont systemFontOfSize:20];
        headLabel.backgroundColor = [UIColor clearColor];
        headLabel.text = [nameArray objectAtIndex:s];
        [menuView addSubview:headLabel];
        
    }
    
}
//收起键盘
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [_numTextField resignFirstResponder];
    return YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
