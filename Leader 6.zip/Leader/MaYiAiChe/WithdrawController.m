//
//  WithdrawController.m
//  MaYiAiChe
//
//  Created by xc on 17/2/14.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "WithdrawController.h"

@interface WithdrawController ()
@property (nonatomic,strong) UIButton * selectedBtn;

@end
@implementation WithdrawController
{
    UIView *_mynavigationBar;
    UIButton * _backLabel;
    UILabel * _titleLabel;
    UILabel * _WithdrawLabel;
}
-(void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:238.0/255 green:238.0/255 blue:238.0/255 alpha:1];
    self.navigationController.navigationBarHidden = YES;
    //自定义navigationbar
    _mynavigationBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, kRelativeHeight(64))];
    _mynavigationBar.backgroundColor = [UIColor greenColor];
    [self.view addSubview:_mynavigationBar];
    //返回item
    _backLabel = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(5), kRelativeHeight(25), kRelativeWidth(30), kRelativeHeight(30))];
    _backLabel.backgroundColor = [UIColor clearColor];
    [_backLabel setImage:[UIImage imageNamed:@"backwhite"] forState:UIControlStateNormal];
    [_backLabel addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigationBar addSubview:_backLabel];
    
    //title
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-kRelativeWidth(100), kRelativeHeight(22), kRelativeWidth(100), kRelativeHeight(40))];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text =@"提现界面";
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.font = [UIFont systemFontOfSize:25];
    [_mynavigationBar addSubview:_titleLabel];
    [self initUI];
    
}
//返回上一页
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)initUI
{
    UILabel * wpayLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(30), kRelativeHeight(120), kRelativeWidth(120), kRelativeHeight(40))];
    wpayLabel.textAlignment = NSTextAlignmentLeft;
    wpayLabel.textColor = [UIColor grayColor];
    wpayLabel.backgroundColor = [UIColor clearColor];
    wpayLabel.text = @"待提现:";
    wpayLabel.font = [UIFont systemFontOfSize:18];
    [self.view addSubview:wpayLabel];
    
    _WithdrawLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(100), kRelativeHeight(120), kRelativeWidth(120), kRelativeHeight(40))];
    _WithdrawLabel.textAlignment = NSTextAlignmentLeft;
    _WithdrawLabel.textColor = [UIColor orangeColor];
    _WithdrawLabel.backgroundColor = [UIColor clearColor];
    _WithdrawLabel.text = @"100.00";
    _WithdrawLabel.font = [UIFont systemFontOfSize:18];
    [self.view addSubview:_WithdrawLabel];
    
    UIView * mainView = [[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(25), kRelativeHeight(170), ScreenWidth-kRelativeWidth(50), kRelativeHeight(245))];
    mainView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:mainView];
    
    UILabel * paystyLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(10), kRelativeWidth(150), kRelativeHeight(30))];
    paystyLabel.textAlignment = NSTextAlignmentLeft;
    paystyLabel.textColor = [UIColor grayColor];
    paystyLabel.backgroundColor = [UIColor clearColor];
    paystyLabel.text = @"支付方式";
    paystyLabel.font = [UIFont systemFontOfSize:15];
    [mainView addSubview:paystyLabel];
    
    for (int i = 0; i<3; i++) {
        float height =kRelativeHeight(60);
        NSArray * imageArr = [NSArray arrayWithObjects:@"icon_balance",@"icon_alipay",@"icon_wechat" ,nil];
        NSArray * titleArr = [NSArray arrayWithObjects:@"余额支付",@"支付宝",@"微信钱包", nil];
        
        UIImageView * imageview = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeHeight(10), kRelativeHeight(55)+height*i, kRelativeWidth(45), kRelativeHeight(45))];
        imageview.backgroundColor = [UIColor clearColor];
        imageview.layer.masksToBounds = YES;
        imageview.layer.cornerRadius = 5;
        imageview.image = [UIImage imageNamed:[imageArr objectAtIndex:i]];
        [mainView addSubview:imageview];
        
        UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(65), kRelativeHeight(62.5)+height*i, kRelativeWidth(120), kRelativeHeight(25))];
        label.textAlignment = NSTextAlignmentLeft;
        label.textColor = [UIColor grayColor];
        label.backgroundColor = [UIColor clearColor];
        label.text = [titleArr objectAtIndex:i];
        label.font = [UIFont systemFontOfSize:15];
        [mainView addSubview:label];
        
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(mainView.frame.size.width-kRelativeWidth(40), kRelativeHeight(62.5)+height*i, kRelativeWidth(30), kRelativeHeight(30));
        btn.backgroundColor = [UIColor clearColor];
        [btn setImage:[UIImage imageNamed:@"未勾选"] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"勾选"] forState:UIControlStateSelected];
        btn.userInteractionEnabled = YES;
        
        [btn addTarget:self action:@selector(payclick:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = 100+i;
        [mainView addSubview:btn];
    }
    UIButton * sureBtn = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(25), kRelativeHeight(440), ScreenWidth-kRelativeWidth(50), kRelativeHeight(60))];
    sureBtn.backgroundColor = [UIColor colorWithRed:235.0/255 green:117.0/255 blue:101.0/255 alpha:1];
    [sureBtn setTitle:@"确认支付" forState:UIControlStateNormal];
    [sureBtn setTintColor:[UIColor whiteColor]];
    [sureBtn addTarget:self action:@selector(sureclick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sureBtn];
}
-(void)payclick:(UIButton *)btn
{
    btn.selected = !btn.selected;
    if (btn!=self.selectedBtn) {
        self.selectedBtn.selected = NO;
        self.selectedBtn = btn;
    }
    self.selectedBtn.selected = YES;
}
-(void)sureclick
{
    
}

@end
