//
//  ScheduleModel.h
//  MaYiAiChe
//
//  Created by yuenhe on 17/3/28.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ScheduleModel : NSObject
/*
  xiche_order_id : "184"
 order_number : "AP-1490629362-7370"
 payment_amount : "0.01"
 consumer_id : "77"
 xiche_goods_id : "14"
 consumer_car : "比亚迪S7--白色--京A·DDDDD"
 phone : "12345678999"
 address : "上城区望江街道三多村单身公寓霞晖北村"
 fuwu_type : "上门服务"
 xaddtime : "1490629362"
 jifen_amount : "0"
 youhuiquan_id : "0"
 youhuiquan_linkman_name : "wqw"
 order_title : "上门服务--洗个蛋"
 order_status : "4"
 tuijianren_name : "qwq"
 beizhu : ""
 yuyue_time : "2017-03-27 23:54"
 store_id : "0"
 lat : "30.238167"
 lng : "120.183092"
 finish_pay_time : "1490629366"
 jiedan_time : "1490629880"
 start_service_time : "1490629893"
 finish_service_time : "1490638868"
 chargeback_time : null
 before_service_pic
 after_service_pic
 */

@property(nonatomic,strong)NSString *  xiche_order_id;                  //  订单id
@property(nonatomic,strong)NSString *  order_number;                  //  订单号
@property(nonatomic,strong)NSString *  payment_amount;              //  金额
@property(nonatomic,strong)NSString *  xiche_goods_id;                 //  洗车商品id
@property(nonatomic,strong)NSString *  consumer_car;                  //  车辆信息
@property(nonatomic,strong)NSString *  phone;                              //  电话
@property(nonatomic,strong)NSString *  address;                           //  服务地址
@property(nonatomic,strong)NSString *  fuwu_type;                       //  服务方式
@property(nonatomic,strong)NSString *  xaddtime;                         //  下单时间
@property(nonatomic,strong)NSString *  order_title;                        //  标题
@property(nonatomic,strong)NSString *  order_status;                    //  订单状态
@property(nonatomic,strong)NSString *  yuyue_time;                      //  预约时间
@property(nonatomic,strong)NSString *  lat;                                   //  纬度
@property(nonatomic,strong)NSString *  lng;                                  //  经度
@property(nonatomic,strong)NSString *  finish_pay_time;               //  支付成功时间
@property(nonatomic,strong)NSString *  jiedan_time;                     //  截单时间
@property(nonatomic,strong)NSString *  start_service_time;          //  开始服务时间
@property(nonatomic,strong)NSString *  finish_service_time;         //  完成服务时间
@property(nonatomic,strong)NSArray  *  before_service_pic;        //  服务前照片
@property(nonatomic,strong)NSArray  *  after_service_pic;           //  服务后照片
@property(nonatomic,strong)NSString *  xg_logo;                         // 商品图片

//@property(nonatomic,strong)NSString *  ;        //
//@property(nonatomic,strong)NSString *  ;        //
//@property(nonatomic,strong)NSString *  ;        //
//@property(nonatomic,strong)NSString *  ;        //
//@property(nonatomic,strong)NSString *  ;        //
//@property(nonatomic,strong)NSString *  ;        //

-(id)initWithDic:(NSDictionary *)dic;   

@end
