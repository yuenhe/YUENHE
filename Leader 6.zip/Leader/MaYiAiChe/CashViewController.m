//
//  CashViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/23.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "CashViewController.h"

@interface CashViewController ()<UITextFieldDelegate>
{
    UIView *_mynavigationBar;
    UIButton * _backLabel;
    UILabel * _titleLabel;
    UITextField * _numTextField;
}

@end

@implementation CashViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];
    self.navigationController.navigationBar.hidden = YES;
    //自定义navigationbar
    _mynavigationBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 64)];
    _mynavigationBar.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_mynavigationBar];
    //返回item
    _backLabel = [[UIButton alloc]initWithFrame:CGRectMake(5, 25, 30, 30)];
    _backLabel.backgroundColor = [UIColor clearColor];
    _backLabel.tag = 100;
    [_backLabel setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [_backLabel addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigationBar addSubview:_backLabel];
    
    //title
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-100, 22, 200, 40)];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text =@"提现";
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor blackColor];
    _titleLabel.font = [UIFont systemFontOfSize:25];
    [_mynavigationBar addSubview:_titleLabel];
    //确认按钮
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setFrame:CGRectMake(20, 450, self.view.frame.size.width-40, 40)];
    [btn setTitle:@"确认体现" forState:UIControlStateNormal];
    [btn setTintColor:[UIColor whiteColor]];
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(btncutclick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    [self createView];
    
    // Do any additional setup after loading the view.
}
-(void)createView
{
    //创建view
    UIView * headView = [[UIView alloc]initWithFrame:CGRectMake(20, 100, self.view.frame.size.width-40, 260)];
    headView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:headView];
    //创建灰色view
    UIView * titleView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, headView.frame.size.width, 40)];
    titleView.backgroundColor = [UIColor lightGrayColor];
    [headView addSubview:titleView];
    //头图像
    UIImageView * headIamgeView = [[UIImageView alloc]initWithFrame:CGRectMake(5, 5, 30, 30)];
    headIamgeView.image = [UIImage imageNamed:@"pay"];
    headIamgeView.backgroundColor = [UIColor clearColor];
    [titleView addSubview:headIamgeView];
    //头标题
    UILabel * titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(40, 5, 100, 30)];
    titleLabel.text = @"可提现积分:";
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.font = [UIFont systemFontOfSize:18];
    [titleView addSubview:titleLabel];
    //积分
    UILabel * numLabel = [[UILabel alloc]initWithFrame:CGRectMake(130, 5, 60, 30)];
    numLabel.text = @"xxxx";
    numLabel.backgroundColor = [UIColor clearColor];
    numLabel.textAlignment = NSTextAlignmentCenter;
    numLabel.textColor = [UIColor blackColor];
    numLabel.font = [UIFont systemFontOfSize:18];
    [titleView addSubview:numLabel];
    //标题
    UILabel * pushLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 45, 100, 30)];
    pushLabel.text = @"提现到余额";
    pushLabel.backgroundColor = [UIColor clearColor];
    pushLabel.textAlignment = NSTextAlignmentLeft;
    pushLabel.textColor = [UIColor blackColor];
    pushLabel.font = [UIFont systemFontOfSize:15];
    [headView addSubview:pushLabel];
    //标题
    UILabel * ProposeLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 150, 40, 30)];
    ProposeLabel.text = @"提出";
    ProposeLabel.backgroundColor = [UIColor clearColor];
    ProposeLabel.textAlignment = NSTextAlignmentLeft;
    ProposeLabel.textColor = [UIColor blackColor];
    ProposeLabel.font = [UIFont systemFontOfSize:15];
    [headView addSubview:ProposeLabel];
    //输入框
    _numTextField = [[UITextField alloc]initWithFrame:CGRectMake(60, 150, headView.frame.size.width-140, 30)];
    _numTextField.textColor = [UIColor blackColor];
    _numTextField.textAlignment = NSTextAlignmentLeft;
    _numTextField.font = [UIFont systemFontOfSize:15];
    _numTextField.backgroundColor = [UIColor clearColor];
    _numTextField.delegate = self;
    _numTextField.returnKeyType = UIReturnKeyDone;
    [headView addSubview:_numTextField];
    
    UIImageView * lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 30-1, _numTextField.frame.size.width, 1)];
    lineImageView.backgroundColor = [UIColor lightGrayColor];
    [_numTextField addSubview:lineImageView];
    //标题
    UILabel * integralLabel = [[UILabel alloc]initWithFrame:CGRectMake(headView.frame.size.width-60, 150, 40, 30)];
    integralLabel.text = @"分";
    integralLabel.backgroundColor = [UIColor clearColor];
    integralLabel.textAlignment = NSTextAlignmentLeft;
    integralLabel.textColor = [UIColor blackColor];
    integralLabel.font = [UIFont systemFontOfSize:15];
    [headView addSubview:integralLabel];
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//跳转上一界面
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
    
}
//收起键盘
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [_numTextField resignFirstResponder];
    return YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
