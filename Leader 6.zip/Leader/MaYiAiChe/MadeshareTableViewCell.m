//
//  MadeshareTableViewCell.m
//  MaYiAiChe
//
//  Created by xc on 16/12/27.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "MadeshareTableViewCell.h"
#import "MapView.h"

@implementation MadeshareTableViewCell
{
  
    UILabel * _headLabel;
    UIImageView * _menuImageView;
    NSIndexPath * _indexpath;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
       
        _headLabel = [[UILabel alloc]initWithFrame:CGRectMake(30, 10, 120, 30)];
        _headLabel.backgroundColor = [UIColor clearColor];
        _headLabel.textAlignment = NSTextAlignmentLeft;
        _headLabel.textColor = [UIColor blackColor];
        _headLabel.font = [UIFont systemFontOfSize:18];
        [self.contentView addSubview:_headLabel];
        
        _menuImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 200)];
        _menuImageView.backgroundColor = [UIColor grayColor];
        [self.contentView addSubview:_menuImageView];
        
    }
    return self;
}
-(void)btnclick:(UIButton *)btn
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(cellDidClickWithIndexpath:)]) {
        btn.tag = self.tag;
        [self.delegate cellDidClickWithIndexpath:_indexpath];
    }
}
-(void)reloadViewWithName:(NSString *)headLabel imageView:(UIImage *)imageView showStatus:(NSInteger)showstatus
{
    if (showstatus == 0) {
        
        _headLabel.hidden = NO;
        _menuImageView.hidden = YES;
        
        _headLabel.text = headLabel;
    }else if (showstatus == 1)
    {
        _headLabel.hidden = YES;
        _menuImageView.hidden = NO;
        
        _menuImageView.image = imageView;
      
    }
}
@end
