//
//  WeiJiDanTableViewController.m
//  MaYiAiChe
//
//  Created by xc on 2017/3/24.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "WeiJiDanTableViewController.h"
#import "DataCenter.h"
#import "ServiceTableViewCell.h"
#import "SonServiceViewController.h"
#import "HRAccountTool.h"
#import "ServiceModel.h"
#import "TBRefresh.h"
#import "CommodityTableViewCell.h"


@interface WeiJiDanTableViewController ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,cellCustomDelegate,cellServicDelegate>
{
    UIScrollView * _bigScrollView;
    UIView * _topView;
    UIView * _selectedView;
    UIButton * _selectedBtn;
    UIButton * _selectbtn;
    UIButton * _btn;
    UIButton * _ddbtn;
    UIView * _midView;
    NSString * _order;
    UIView * lineView;      // 下划线
}


@property (nonatomic,strong) DataCenter * data;                        //  单利
@property (nonatomic,strong) NSMutableArray * dataArray;        // 数据源

@property (nonatomic,strong) UITableView * tableview;

@end

@implementation WeiJiDanTableViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self createNet];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _data = [DataCenter shareDataCenter];
    _dataArray = [NSMutableArray new];
    self.view.backgroundColor = [UIColor lightGrayColor];
    self.navigationController.navigationBar.hidden = YES;
    
    [self initUI];
    //    [self createNet];
    //[self initNet];
    //    [self createnetworking];
    // Do any additional setup after loading the view.
}


-(void)createNet
{
    //    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    //    NSString * useID = [defaults objectForKey:@"s_userid"];
    //    NSString * store =@"爱洗车下沙店";
    NSString * useID = _data.UIDs;
    
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSMutableDictionary * servicedic = [[NSMutableDictionary alloc]init];
    [servicedic setObject:useID forKey:@"s_userid"];
    //    [servicedic setObject:store forKey:@"s_store"];
    //    [servicedic setObject:@"json" forKey:@"type"];
    //    [servicedic setObject:@"11" forKey:@"sex"];
    //    [servicedic setObject:@"13" forKey:@"name"];
    //    [servicedic setObject:@"poop" forKey:@"yes"];
    //    [servicedic setObject:@"tr" forKey:@"adr"];
    //    [servicedic setObject:@"yep" forKey:@"head"];
    //    NSString * urlString = @"http://106.15.0.128/working/index.php/Admin/ApiS/s_forders";
    NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_forders";
    [manager POST:urlString parameters:servicedic progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //        NSLog(@"%@",responseObject);
        //        NSString * str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
        //        NSLog(@"%@",str);
        NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
        //        _data.order_num = dic[@"order_number"];
        NSArray * array = dic[@"xiche_weijiedan"];
        [_dataArray removeAllObjects];
        for (NSDictionary * dic in array) {
            ServiceModel * model = [[ServiceModel alloc]init];
            model.addtime = dic[@"yuyue_time"];
            model.fuwu = dic[@"fuwu_type"];
            model.title = dic[@"order_title"];
            model.adress = dic[@"address"];
            model.phonenum = dic[@"phone"];
            model.logo = dic[@"xg_logo"];
            model.status = dic[@"order_status"];
            model.carstlye = dic[@"consumer_car"];
            model.oder_number = dic[@"order_number"];
            model.lat         = dic[@"lat"];
            model.lng        = dic[@"lng"];
            [_dataArray addObject:model];
        }
        //        self.dataarr = array;
        [self.tableview reloadData];
        //        _order = [dic objectForKey:@"order_num"];
        //        NSLog(@"%@",_order);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];
}



// 创建表格
-(void)initUI
{
    
    if (!_tableview) {
        __weak WeiJiDanTableViewController * weakself = self;
        _tableview = [[UITableView alloc]initWithFrame:CGRectMake(0, 61, ScreenWidth, _bigScrollView.frame.size.height-61) style:UITableViewStylePlain];
        _tableview.tag =200;
        _tableview.delegate = self;
        _tableview.dataSource = self;
        [_tableview addRefreshHeaderWithBlock:^{
                        [weakself LoadDatas];
        }];
        [_tableview addRefreshFootWithBlock:^{
                        [weakself LoadMoreDatas];
        }];
        
        [_bigScrollView addSubview:_tableview];
    }
    
    
}








- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * cellID = @"cellCusId";
    ServiceTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[ServiceTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.delegate = self;
        ServiceModel * model = [[ServiceModel alloc]init];
        model = _dataArray[indexPath.row];
        cell.model = model;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
        return cell;
}
    
    //#pragma mark===================//、、 进入服务界面
    //-(void)cellServicDidCLick:(ServiceTableViewCell*)cell WithBtn:(UIButton *)btn{
    //
    //        SonServiceViewController *  service = [[SonServiceViewController alloc]init];
    //        service.orderStr        = cell.model.oder_number;
    //        service.headImageStr = cell.model.logo;
    //        service.fuwuStr         = cell.headLabel.text;
    //        service.titleStr            = cell.fstrtLabel.text;
    //        service.phoneStr        = cell.telLabel.text;
    //        service.addressStr      = cell.adrLabel.text;
    //        service.lat                   = cell.model.lat;
    //        service.lng                  = cell.model.lng;
    //
    //        [self.navigationController pushViewController:service animated:YES];
    //        NSLog(@"----------444333-----%ld",btn.tag);
    //    }
    
    - (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
    {
        return 180;
    }
    
#pragma mark-加载数据
    
-(void)LoadDatas
    {
        
        [self.tableview.footer ResetNomoreData];
        
        // 模拟延时设置
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            [self.tableview.header endHeadRefresh];
            
        });
        
        
        
    }
    
-(void)LoadMoreDatas
    {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            [self.tableview.footer NoMoreData];
            
        });
        
    }
    
    
    /*
     // Override to support conditional editing of the table view.
     - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
     // Return NO if you do not want the specified item to be editable.
     return YES;
     }
     */
    
    /*
     // Override to support editing the table view.
     - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
     if (editingStyle == UITableViewCellEditingStyleDelete) {
     // Delete the row from the data source
     [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
     } else if (editingStyle == UITableViewCellEditingStyleInsert) {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
     // Return NO if you do not want the item to be re-orderable.
     return YES;
     }
     */
    
    /*
     #pragma mark - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
     // Get the new view controller using [segue destinationViewController].
     // Pass the selected object to the new view controller.
     }
     */
    
    @end
