//
//  LinkTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 17/1/3.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MyCellDelegate <NSObject>


@end
@interface LinkTableViewCell : UITableViewCell

@property (weak,nonatomic) id <MyCellDelegate>delegate;

-(void)reloadViewName:(NSString *)headLabel priceLabel:(NSString *)priceLabel headImageView:(UIImage *)headImageView;

@end
