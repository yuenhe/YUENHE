//
//  HRAccountTool.h
//  MaYiAiChe
//
//  Created by xc on 17/1/12.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HRAccountTool : NSObject

/**
 *  存储账号信息
 *  @param account 需要存储的账号信息：第一个值为用户名；第二个值为密码
 */
+(void)saveAccount:(NSArray *)account;
/**
 *  返回账号信息
 *  @param account 需要存储的账号信息：第一个值为用户名；第二个值为密码
 */
+(NSArray *)getAccount;
/**
 *  返回用户名账号信息
 *  @param account 需要存储的账号信息：第一个值为用户名；第二个值为密码
 */
+(NSString *)getUserName;
/**
 *  返回密码信息
 *  @param account 需要存储的账号信息：第一个值为用户名；第二个值为密码
*/
+(NSString *)getPossWord;
/**
 *  返回userID信息
 *  @param account 需要存储的账号信息：第一个值为用户名；第二个值为密码
 */
+(NSString *)getUserID;
/**
 *  判断bool值
 *  @param account 需要存储的账号信息：第一个值为用户名；第二个值为密码
 */

@end
