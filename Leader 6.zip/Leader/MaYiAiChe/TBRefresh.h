//
//  TBRefresh.h
//  TBRefreshDemo
//
//  Created by bob on 2017/3/7.
//  Copyright © 2017年 bob. All rights reserved.
//

#ifndef TBRefresh_h
#define TBRefresh_h
#import "UIScrollView+TBRefresh.h"
#import "TBRefreshHeadView.h"
#import "TBRefreshFootView.h"
#define ScreenWidth     [UIScreen mainScreen].bounds.size.width
#define ScreenHeight  [UIScreen mainScreen].bounds.size.height

#endif /* TBRefresh_h */
