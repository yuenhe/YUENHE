//
//  NSString+MD5.h
//  MaYiAiChe
//
//  Created by xc on 17/1/12.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
@interface NSString (MD5)
+(NSString *)stringToMD5:(NSString *)str;
@end
