//
//  ShareoneTableViewCell.m
//  MaYiAiChe
//
//  Created by xc on 16/12/23.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "ShareoneTableViewCell.h"

@implementation ShareoneTableViewCell
{
    UILabel * _nameLabel;
    UILabel * _telLabel;
    UILabel * _investnumLabel;
    UILabel * _shareLabel;
    UILabel * _investLabel;
    UILabel * _UnitLabel;
    UIImageView * _headIamgeView;
    UILabel * _sharenamelabel;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //创建头图像
        _headIamgeView = [[UIImageView alloc]initWithFrame:CGRectMake(20, 20, 44, 44)];
        _headIamgeView.layer.masksToBounds = YES;
        _headIamgeView.layer.cornerRadius = 22;
        _headIamgeView.backgroundColor = [UIColor grayColor]
        ;
        [self.contentView addSubview:_headIamgeView];
        //创建姓名
        _nameLabel  = [[UILabel alloc]initWithFrame:CGRectMake(80, 20, 80, 30)];
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.textAlignment  = NSTextAlignmentLeft;
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.font = [UIFont systemFontOfSize:20];
        [self.contentView addSubview:_nameLabel];
        //创建联系方式
        _telLabel = [[UILabel alloc]initWithFrame:CGRectMake(150, 25, 100, 20)];
        _telLabel.backgroundColor = [UIColor blueColor];
        _telLabel.layer.masksToBounds = YES;
        _telLabel.layer.cornerRadius = 15;
        _telLabel.textAlignment = NSTextAlignmentCenter;
        _telLabel.textColor = [UIColor blackColor];
        _telLabel.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:_telLabel];
        //创建标题投资
        _investLabel = [[UILabel alloc]initWithFrame:CGRectMake(80, 50, 50, 30)];
        _investLabel.text = @"投资:";
        _investLabel.textColor = [UIColor blackColor];
        _investLabel.textAlignment = NSTextAlignmentLeft;
        _investLabel.font = [UIFont systemFontOfSize:15];
        _investLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_investLabel];
        //创建标题分红
        _sharenamelabel = [[UILabel alloc]initWithFrame:CGRectMake(250, 50, 50, 30)];
        _sharenamelabel.text = @"分红:";
        _sharenamelabel.textColor = [UIColor blackColor];
        _sharenamelabel.textAlignment = NSTextAlignmentLeft;
        _sharenamelabel.font = [UIFont systemFontOfSize:15];
        _sharenamelabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_sharenamelabel];
        //投资资金获得的分红
        _shareLabel = [[UILabel alloc]initWithFrame:CGRectMake(300, 50, 50, 30)];
        _shareLabel.textColor = [UIColor blackColor];
        _shareLabel.textAlignment = NSTextAlignmentLeft;
        _shareLabel.font = [UIFont systemFontOfSize:15];
        _shareLabel.backgroundColor = [UIColor clearColor];
         [self.contentView addSubview:_shareLabel];
        //投资资金数额
        _investnumLabel = [[UILabel alloc]initWithFrame:CGRectMake(120, 50, 60, 30)];
        _investnumLabel.textAlignment = NSTextAlignmentCenter;
        _investnumLabel.textColor = [UIColor blackColor];
        _investnumLabel.backgroundColor = [UIColor clearColor];
        _investnumLabel.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_investnumLabel];
       //for循环，布局两个单位
        for (int i = 0; i<2; i++) {
            float width = 200;
            //单位label
            _UnitLabel = [[UILabel alloc]initWithFrame:CGRectMake(width*i+180, 50, 40, 30)];
            _UnitLabel.textAlignment = NSTextAlignmentCenter;
            _UnitLabel.textColor = [UIColor blackColor];
            _UnitLabel.backgroundColor = [UIColor clearColor];
            _UnitLabel.font = [UIFont systemFontOfSize:15];
            _UnitLabel.text = @"元";
            [self.contentView addSubview:_investnumLabel];
        }
      
        
    }
    return self;
}
//给定义的空间赋值
-(void)reloadViewWithName:(NSString *)nameLabel telLabel:(NSString *)telLabel investnumLabel:(NSString *)investnumLabel shareLabel:(NSString *)shareLabel headImageView:(UIImage *)headImageView
{
    _nameLabel.text =nameLabel;
    _telLabel.text = telLabel;
    _investnumLabel .text = investnumLabel;
    _shareLabel.text = shareLabel;
    _headIamgeView.image = headImageView;
}
@end
