//
//  TitleTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 16/12/27.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CellCusDelegate <NSObject>

-(void)cellDidClickWithIndexpath:(UIButton *)button;

@end
@interface TitleTableViewCell : UITableViewCell

@property (weak,nonatomic) id <CellCusDelegate>delegate;

@end
