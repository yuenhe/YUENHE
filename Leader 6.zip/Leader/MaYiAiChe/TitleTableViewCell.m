//
//  TitleTableViewCell.m
//  MaYiAiChe
//
//  Created by xc on 16/12/27.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "TitleTableViewCell.h"

@implementation TitleTableViewCell
{
    UIImageView * _selectedBtn;
    UILabel * _nameLabel;
    NSIndexPath * _indexpath;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        NSArray * imageArray = [NSArray arrayWithObjects:@"wash",@"Beauty",@"preserve",@"Repair", nil];
        NSArray * nameArray = [NSArray arrayWithObjects:@"洗车",@"美容",@"保养",@"维修", nil];
        for (int t = 0; t <4; t++) {
            float width = 100;
            _selectedBtn  = [[UIImageView alloc]initWithFrame:CGRectMake(width*t+40, 10, 50, 50)];
            _selectedBtn.image = [UIImage imageNamed:[imageArray objectAtIndex:t]];
            _selectedBtn.backgroundColor = [UIColor clearColor];
            [self.contentView addSubview:_selectedBtn];
            
            _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(width*t+40, 65, 50, 20)];
            _nameLabel.backgroundColor = [UIColor clearColor];
            _nameLabel.textColor = [UIColor blackColor];
            _nameLabel.textAlignment = NSTextAlignmentCenter;
            _nameLabel.text = [nameArray objectAtIndex:t];
            _nameLabel.font = [UIFont systemFontOfSize:18];
            [self.contentView addSubview:_nameLabel];

    }
    }
    return self;
    
}


@end
