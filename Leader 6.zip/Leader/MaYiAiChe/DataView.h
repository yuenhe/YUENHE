//
//  DataView.h
//  MaYiAiChe
//
//  Created by xc on 17/2/6.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol dateViewDelegate <NSObject>
-(void)dateViewWithTitle:(NSString * )string dayWithTittle:(NSString *)daystring;
@end
@interface DataView : UIView
/** 1.最小的年份，default is 1900 */
@property (nonatomic, assign)NSInteger yearLeast;
/** 2.显示年份数量，default is 200 */
@property (nonatomic, assign)NSInteger yearSum;
/** 3.中间选择框的高度，default is 28*/
@property (nonatomic, assign)CGFloat heightPickerComponent;

@property(nonatomic,assign)id<dateViewDelegate>delegate;
-(void)show;
-(void)hiden;
-(void)setUI;

@end
