//
//  ServiceModel.h
//  MaYiAiChe
//
//  Created by xc on 17/1/20.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ServiceModel : NSObject

@property (nonatomic,strong) NSString * carstlye;
@property (nonatomic,strong) NSString * phonenum;
@property (nonatomic,strong) NSString * logo;
@property (nonatomic,strong) NSString * adress;
@property (nonatomic,strong) NSString * fuwu;
@property (nonatomic,strong) NSString * addtime;
@property (nonatomic,strong) NSString * title;
@property (nonatomic,strong) NSString * status;
@property (nonatomic,strong)NSString  * oder_number;
@property (nonatomic,strong)NSString  * lat;
@property (nonatomic,strong)NSString  * lng;
@property (nonatomic,strong)NSArray  * before_service_pic;
@property (nonatomic,strong)NSArray  * after_service_pic;
@property (nonatomic,strong) NSString * jiedan_time;
@property (nonatomic,strong) NSString * start_time;
@end
