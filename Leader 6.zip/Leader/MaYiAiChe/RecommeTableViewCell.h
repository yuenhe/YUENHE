//
//  RecommeTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 16/12/22.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol cellCustomDelegate <NSObject>

-(void)cellDidClickWithIndexPath:(NSIndexPath *)indexpath;

@end
@interface RecommeTableViewCell : UITableViewCell
@property (weak,nonatomic) id <cellCustomDelegate>delegate;

-(void)reloadViewWithName:(NSString *)headLabel headImageview:(UIImage *)headImageView totalLabel:(NSString *)totalLabel totalnumLabel:(NSString *)totalnumLabel numLabel:(NSString *)numLabel nameLabel:(NSString *)nameLabel textLabel:(NSString *)textLabel tuijianLabel:(NSString *)tuijianLabel tuijiannumLabel:(NSString *)tuijiannumLabel showStatus:(NSInteger)showstatus;
@end
