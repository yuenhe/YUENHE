//
//  MapView.h
//  MaYiAiChe
//
//  Created by xc on 17/2/8.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface MapView : UIView 
-(instancetype)initWithFrame:(CGRect)frame;
@end
