//
//  EwmViewController.m
//  MaYiAiChe
//
//  Created by xc on 17/1/3.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "EwmViewController.h"

@interface EwmViewController ()
{
    UIView * _headView;
}
#define Width [UIScreen mainScreen].bounds.size.width
#define Height [UIScreen mainScreen].bounds.size.height
@end

@implementation EwmViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor lightGrayColor];
    self.navigationController.navigationBarHidden = YES;
    _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Width, kRelativeHeight(80))];
    _headView.backgroundColor = [UIColor greenColor];
    [self.view addSubview:_headView];
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(40), kRelativeWidth(30), kRelativeHeight(30))];
    [btn setImage:[UIImage imageNamed:@"backwhite"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = [UIColor clearColor];
    [_headView addSubview:btn];
    
    UILabel * textLabel = [[UILabel alloc]init];
    textLabel.center = CGPointMake(Width/2, kRelativeHeight(50));
    textLabel.bounds = CGRectMake(0, 0, kRelativeWidth(200), kRelativeHeight(40));
    textLabel.textAlignment = NSTextAlignmentCenter;
    textLabel.textColor = [UIColor whiteColor];
    textLabel.text = @"分享二维码扫描";
    textLabel.font = [UIFont systemFontOfSize:25];
    [_headView addSubview:textLabel];
    
    
    [self createView];
    // Do any additional setup after loading the view.
}
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)createView
{
//    UIView *mainView =[[UIView alloc]initWithFrame:CGRectMake(0, 80, Width, Height-80)];
//    mainView.backgroundColor = [UIColor lightGrayColor];
//    [self.view addSubview:mainView];
    
    UIImageView * titleImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(30), kRelativeHeight(100), kRelativeWidth(80), kRelativeHeight(95))];
    titleImageView.backgroundColor = [UIColor greenColor];
    [self.view addSubview:titleImageView];
    
    UILabel * headLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(120), kRelativeHeight(100), kRelativeWidth(200), kRelativeHeight(30))];
    headLabel.textAlignment = NSTextAlignmentCenter;
    headLabel.textColor = [UIColor blackColor];
    headLabel.text = @"XX商品代金券";
    headLabel.font = [UIFont boldSystemFontOfSize:20];
    [self.view addSubview:headLabel];
    
    UILabel * textsLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(120), kRelativeHeight(140), kRelativeWidth(300), kRelativeHeight(30))];
    textsLabel.textAlignment = NSTextAlignmentCenter;
    textsLabel.textColor = [UIColor blackColor];
    textsLabel.text = @"识别二维码，安装注册即可使用";
    textsLabel.font = [UIFont systemFontOfSize:18];
    [self.view addSubview:textsLabel];
    
    UILabel * priceLabel = [[UILabel alloc]initWithFrame:CGRectMake(Width-kRelativeWidth(80), kRelativeHeight(165), kRelativeWidth(50), kRelativeHeight(30))];
    priceLabel.textAlignment = NSTextAlignmentCenter;
    priceLabel.textColor = [UIColor blackColor];
    priceLabel.text = @"￥20";
    priceLabel.font = [UIFont boldSystemFontOfSize:18];
    [self.view addSubview:priceLabel];
    
    UIView * bottomView = [[UIView alloc]initWithFrame:CGRectMake((Width-kRelativeWidth(320))/2, kRelativeHeight(230), kRelativeWidth(320), kRelativeHeight(290))];
    bottomView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:bottomView];
    
    UIImageView * ScanLifeImageView = [[UIImageView alloc]init];
    ScanLifeImageView.image = [UIImage imageNamed:@""];
    ScanLifeImageView.center =CGPointMake(kRelativeWidth(160), kRelativeHeight(145));
    ScanLifeImageView.bounds = CGRectMake(0, 0, kRelativeWidth(179), kRelativeHeight(190));
    ScanLifeImageView.backgroundColor = [UIColor redColor];
    [bottomView addSubview:ScanLifeImageView];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
