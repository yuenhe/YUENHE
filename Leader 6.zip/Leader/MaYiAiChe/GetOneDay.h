//
//  GetOneDay.h
//  MaYiAiChe
//
//  Created by xc on 17/2/23.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GetOneDay : NSObject
/**
 *  获取几年几月几日后的日期，0表示今天，负数表示之前
 */
+ (int)getOneDay:(int)day;
@end
