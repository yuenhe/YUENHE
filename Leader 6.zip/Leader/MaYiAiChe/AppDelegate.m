//
//  AppDelegate.m
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "AppDelegate.h"
#import "RegisterViewController.h"
#import "BulletinViewController.h"
#import "RealtimeViewController.h"
#import "ScheduleViewController.h"
#import "MineViewController.h"
#import "HRAccountTool.h"
#import <AlipaySDK/AlipaySDK.h>
#import "NSString+MD5.h"
#import "UITableView+LSEmpty.h"


#define ScreenHeight [[UIScreen mainScreen] bounds].size.height
#define ScreenWidth [[UIScreen mainScreen] bounds].size.width

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self setUpWindow];
        _data = [DataCenter shareDataCenter];
    [AMapServices sharedServices].apiKey = @"a28f576d080354502a3e8a352130d7be";
  
    return YES;
}
//图片压缩到指定CGSize大小
-(UIImage *)scaleImage:(UIImage *)image toSize:(CGSize)theTize//图片压缩到指定CGSize大小
{
    UIGraphicsBeginImageContext(theTize);
    [image drawInRect:CGRectMake(0, 0, theTize.width, theTize.height)];
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}
-(void)setUpWindow
{
    if (self.window) {
        self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    }
    
    //    监听 登录状态 跳转到tabbar页面
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(createTableBar) name:@"tabbar" object:nil];

    NSUserDefaults  * user  = [NSUserDefaults standardUserDefaults];
    //         存密码
    
    _userPassword = [user objectForKey:@"passwordSave"];
    _userPhone    = [user objectForKey:@"nameSave"];
    
    if ([user objectForKey:@"nameSave"])
    {
        NSLog(@"不是第一次");
         [self login];
        [self createTableBar];
        
    }else{
        RegisterViewController * registerView = [[RegisterViewController alloc]init];
        self.window.rootViewController = registerView;
     }
    
    [self.window makeKeyAndVisible];
    
 }

-(void)createTableBar{
    BulletinViewController * btc = [[BulletinViewController alloc]init];
    UINavigationController * nvc = [[UINavigationController alloc]initWithRootViewController:btc];
    nvc.title = @"公告";
    nvc.tabBarItem.image = [[UIImage imageNamed:@"首页2@2x"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    nvc.tabBarItem.selectedImage = [[UIImage imageNamed:@"首页1@2x"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    RealtimeViewController * rvc = [[RealtimeViewController alloc]init];
    UINavigationController * nvc1 = [[UINavigationController alloc]initWithRootViewController:rvc];
    nvc1.title = @"实时订单";
    nvc1.navigationBar.backgroundColor = [UIColor orangeColor];
    nvc1.tabBarItem.image = [[UIImage imageNamed:@"实时订单1"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nvc1.tabBarItem.selectedImage = [[UIImage imageNamed:@"实时订单2"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    ScheduleViewController * svc = [[ScheduleViewController alloc]init];
    UINavigationController *nvc2 = [[UINavigationController alloc]initWithRootViewController:svc];
    nvc2.title = @"日程安排";
    nvc2.tabBarItem.image = [[UIImage imageNamed:@"日程安排1"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nvc2.tabBarItem.selectedImage = [[UIImage imageNamed:@"日程安排2"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    MineViewController * mvc = [[MineViewController alloc]init];
    UINavigationController * nvc3 = [[UINavigationController alloc]initWithRootViewController:mvc];
    nvc3.title = @"我的";
    nvc3.tabBarItem.image = [[UIImage imageNamed:@"我的2@2x"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nvc3.tabBarItem.selectedImage = [[UIImage imageNamed:@"我的1@2x"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    NSArray * titleArray = [NSArray arrayWithObjects:nvc,nvc1,nvc2,nvc3, nil];
    UITabBarController * tatolControllers = [[UITabBarController alloc]init];
    //items,selectedItem 属性是由tabcontroller来管理的，不能进行外部赋值
    
    //不能通过对backgroundColor赋值来改变标签栏的颜色
    tatolControllers.tabBar.backgroundColor = [UIColor clearColor];
    tatolControllers.tabBar.tintColor = [UIColor greenColor];
    
    //改变被选中图片的色调
    tatolControllers.tabBar.selectedImageTintColor = [UIColor greenColor];
    
    //将appelegete实例作为tabcontroller代理
    
    tatolControllers.viewControllers = titleArray;
    
    self.window.rootViewController =tatolControllers;

    
}

-(void)login
{
    NSString *useName = _userPhone;
    NSString * possWord = _userPassword;
    NSString * md5Str = [NSString stringToMD5:possWord];
    NSLog(@"md5str == %@",[NSString stringToMD5:possWord]);
    NSDictionary * parameters = @{@"c_name":useName,@"c_pwd":md5Str};
    //    NSMutableArray  * dic = [[NSMutableArray alloc]init];
    //    [dic setValue:useName forKey:@"c_name"];
    //    [dic setValue:md5Str forKey:@"c_pwd"];
    NSString * urlString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_login";
    AFHTTPSessionManager * managers =[AFHTTPSessionManager manager];
    //    managers.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", nil ];
    managers.responseSerializer  = [AFHTTPResponseSerializer serializer];
    [managers POST:urlString parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"请求成功，服务器返回的信息%@----%@",responseObject,[responseObject class]);
        NSString * str = [[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSLog(@"%@",str);
        NSDictionary * dic  = [NSJSONSerialization JSONObjectWithData:responseObject options:1 error:nil];
        _useID = [dic objectForKey:@"id"];
        
        if ([[dic objectForKey:@"status"] isEqualToString:@"登录成功"]) {
            
            NSLog(@"登录成功");
            _data.UIDs = dic[@"id"];
            _data.phone =_userPhone;
            NSDictionary * iddic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            NSLog(@"%@",[iddic class]);
            
                  //            [self.navigationController pushViewController:tatolControllers animated:YES];
            [[NSNotificationCenter  defaultCenter]postNotificationName:@"tabbar" object:nil];
             NSUserDefaults  * user  = [NSUserDefaults standardUserDefaults];
            //         存密码
            [user setInteger:1 forKey:@"isLogin"];
             [user setObject:_userPhone forKey:@"nameSave"];
            [user setObject:_userPassword forKey:@"passwordSave"];
            [user synchronize];
              
        }else{
            
            UIAlertView * alert  = [[UIAlertView alloc]initWithTitle:[dic objectForKey:@"status"] message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            alert.tag = 2;
            [alert show];
            return ;
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        //NSLog(@"请求失败，服务器返回的错误信息％@",error);
        NSData * data = error.userInfo[@"com.alamofire.serialization.response.error.data"];
        NSString * str = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"错误原因:%@",str);
         UIAlertView * alert  = [[UIAlertView alloc]initWithTitle:@"网络连接异常" message:@"重新登录" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        alert.tag = 3;
        [alert show];
//        RegisterViewController * registerView = [[RegisterViewController alloc]init];
//        self.window.rootViewController = registerView;
    }];
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 2 || alertView.tag == 3) {
       RegisterViewController * registerView = [[RegisterViewController alloc]init];
    self.window.rootViewController = registerView;
    }
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}
- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation {
    
    if ([url.host isEqualToString:@"safepay"]) {
        // 支付跳转支付宝钱包进行支付，处理支付结果
        [[AlipaySDK defaultService] processOrderWithPaymentResult:url standbyCallback:^(NSDictionary *resultDic) {
            NSLog(@"result = %@",resultDic);
        }];
        
//        // 授权跳转支付宝钱包进行支付，处理支付结果
//        [[AlipaySDK defaultService] processAuth_V2Result:url standbyCallback:^(NSDictionary *resultDic) {
//            NSLog(@"result = %@",resultDic);
//            // 解析 auth code
//            NSString *result = resultDic[@"result"];
//            NSString *authCode = nil;
//            if (result.length>0) {
//                NSArray *resultArr = [result componentsSeparatedByString:@"&"];
//                for (NSString *subResult in resultArr) {
//                    if (subResult.length > 10 && [subResult hasPrefix:@"auth_code="]) {
//                        authCode = [subResult substringFromIndex:10];
//                        break;
//                    }
//                }
//            }
//            NSLog(@"授权结果 authCode = %@", authCode?:@"");
//        }];
    }
    return YES;
}
// NOTE: 9.0以后使用新API接口
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString*, id> *)options
{
    if ([url.host isEqualToString:@"safepay"]) {
        // 支付跳转支付宝钱包进行支付，处理支付结果
        [[AlipaySDK defaultService] processOrderWithPaymentResult:url standbyCallback:^(NSDictionary *resultDic) {
            NSLog(@"result = %@",resultDic);
        }];
        
//        // 授权跳转支付宝钱包进行支付，处理支付结果
//        [[AlipaySDK defaultService] processAuth_V2Result:url standbyCallback:^(NSDictionary *resultDic) {
//            NSLog(@"result = %@",resultDic);
//            // 解析 auth code
//            NSString *result = resultDic[@"result"];
//            NSString *authCode = nil;
//            if (result.length>0) {
//                NSArray *resultArr = [result componentsSeparatedByString:@"&"];
//                for (NSString *subResult in resultArr) {
//                    if (subResult.length > 10 && [subResult hasPrefix:@"auth_code="]) {
//                        authCode = [subResult substringFromIndex:10];
//                        break;
//                    }
//                }
//            }
//            NSLog(@"授权结果 authCode = %@", authCode?:@"");
//        }];
    }
    return YES;
}

@end
