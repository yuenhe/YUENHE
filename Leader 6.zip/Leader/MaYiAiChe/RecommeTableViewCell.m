//
//  RecommeTableViewCell.m
//  MaYiAiChe
//
//  Created by xc on 16/12/22.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "RecommeTableViewCell.h"

@implementation RecommeTableViewCell
{
    UILabel * _leftLabel;
    UITextField * _rightTextField;
    UILabel * _headLabel;
    UIImageView * _headImageView;
    UIImageView *_line3ImageView;
    UIImageView *_line4ImageView;
    UIImageView *_line5ImageView;
    UILabel * _totalLabel;
    UILabel * _totalnumLabel;
    UILabel * _nameLabel;
    UILabel * _textLabel;
    UILabel * _numLabel;
    UIButton * btn1;
    UILabel * _tuijianLabel;
    UILabel * _tuijiannumLabel;
    NSIndexPath *_indexpath;
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _leftLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width-kRelativeWidth(40), kRelativeHeight(70))];
        _leftLabel.backgroundColor = [UIColor greenColor];
        _leftLabel.text = @"获取商品推荐券：";
        _leftLabel.adjustsFontSizeToFitWidth = YES;
        _leftLabel.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_leftLabel];
        
        _rightTextField = [[UITextField alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width/2-kRelativeWidth(60),0 , [UIScreen mainScreen].bounds.size.width/2, kRelativeHeight(70))];
        _rightTextField.backgroundColor = [UIColor whiteColor];
        _rightTextField.placeholder = @"推荐链接／二维码";
        _rightTextField.adjustsFontSizeToFitWidth = YES;
        _rightTextField.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_rightTextField];
        
        _headLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(45), kRelativeHeight(5), kRelativeWidth(100), kRelativeHeight(30))];
        _headLabel.textColor = [UIColor orangeColor];
        _headLabel.textAlignment = NSTextAlignmentLeft;
        _headLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_headLabel];
        
        _numLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(150), kRelativeHeight(5), kRelativeWidth(50), kRelativeHeight(30))];
        _numLabel.textColor = [UIColor blackColor];
        _numLabel.textAlignment = NSTextAlignmentLeft;
        _numLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_numLabel];
        
        
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(5), kRelativeWidth(30), kRelativeHeight(30))];
        _headImageView.backgroundColor = [UIColor orangeColor];
        [self.contentView addSubview:_headImageView];
        
        _line3ImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(39), [UIScreen mainScreen].bounds.size.width, 1)];
        _line3ImageView.backgroundColor =[UIColor blackColor];
        [self.contentView addSubview:_line3ImageView];
        
        _line4ImageView = [[UIImageView alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width/2-1, kRelativeHeight(40), 1, kRelativeHeight(40))];
        _line4ImageView.backgroundColor = [UIColor blackColor];
        [self.contentView addSubview:_line4ImageView];
        
        
        _line5ImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(80), [UIScreen mainScreen].bounds.size.width, 1)];
        _line5ImageView.backgroundColor =[UIColor blackColor];
        [self.contentView addSubview:_line5ImageView];
        
        float width =[UIScreen mainScreen].bounds.size.width/2;
        _totalLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(5), kRelativeWidth(150), kRelativeHeight(30))];
        _totalLabel.textColor = [UIColor blackColor];
        _totalLabel.textAlignment = NSTextAlignmentLeft;
        _totalLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_totalLabel];
        
        _totalnumLabel = [[UILabel alloc]initWithFrame:CGRectMake(width-kRelativeWidth(100), kRelativeHeight(5), kRelativeWidth(60), kRelativeHeight(30))];
        _totalnumLabel.textColor = [UIColor blackColor];
        _totalnumLabel.textAlignment = NSTextAlignmentLeft;
        _totalnumLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_totalnumLabel];
        
        _tuijianLabel = [[UILabel alloc]initWithFrame:CGRectMake(width+kRelativeWidth(10), kRelativeHeight(5), kRelativeWidth(150), kRelativeHeight(30))];
        _tuijianLabel.textColor = [UIColor blackColor];
        _tuijianLabel.textAlignment = NSTextAlignmentLeft;
        _tuijianLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_tuijianLabel];
        
        _tuijiannumLabel = [[UILabel alloc]initWithFrame:CGRectMake(width*2-kRelativeWidth(100), kRelativeHeight(5), kRelativeWidth(60), kRelativeHeight(30))];
        _tuijiannumLabel.textColor = [UIColor blackColor];
        _tuijiannumLabel.textAlignment = NSTextAlignmentLeft;
        _tuijiannumLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_tuijiannumLabel];
       
        _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(5), kRelativeWidth(60), kRelativeHeight(30))];
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.textAlignment = NSTextAlignmentCenter;
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
        
        _textLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(60), kRelativeHeight(5), kRelativeWidth(250), kRelativeHeight(30))];
        _textLabel.textColor = [UIColor blackColor];
        _textLabel.textAlignment = NSTextAlignmentCenter;
        _textLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_textLabel];
        
        btn1 = [[UIButton alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-kRelativeWidth(35), kRelativeHeight(5), kRelativeWidth(30), kRelativeHeight(30))];
        btn1.backgroundColor = [UIColor clearColor];
        
        [btn1 setImage:[UIImage imageNamed:@"下拉"]forState:UIControlStateNormal];
        [btn1 setImage:[UIImage imageNamed:@"收回"] forState:UIControlStateSelected];
        [btn1 addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:btn1];

    }
    return self;
}
-(void)btnclick:(UIButton *)btn
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(cellDidClickWithIndexPath:)]) {
        [self.delegate cellDidClickWithIndexPath:_indexpath];
    }
}
//0显示第一段，1显示第二段的第一行，2显示第二段的二行，3显示第二段第三行,4显示第三段的第一行，5显示第三段的剩余行
-(void)reloadViewWithName:(NSString *)headLabel headImageview:(UIImage *)headImageView totalLabel:(NSString *)totalLabel totalnumLabel:(NSString *)totalnumLabel numLabel:(NSString *)numLabel nameLabel:(NSString *)nameLabel textLabel:(NSString *)textLabel tuijianLabel:(NSString *)tuijianLabel tuijiannumLabel:(NSString *)tuijiannumLabel showStatus:(NSInteger)showstatus
{
    if (showstatus == 0) {
        _leftLabel.hidden = NO;
        _rightTextField.hidden = NO;
        _headLabel.hidden = YES;
        _headImageView.hidden = YES;
        _line3ImageView.hidden = YES;
        _line4ImageView.hidden = YES;
        _line5ImageView.hidden = YES;
        _totalLabel.hidden = YES;
        _totalnumLabel.hidden = YES;
        _nameLabel.hidden = YES;
        _textLabel.hidden = YES;
        _numLabel.hidden = YES;
        _tuijiannumLabel.hidden = YES;
        _tuijianLabel.hidden =YES;
        btn1.hidden = YES;
        
    }else if (showstatus == 1)
    {
        _leftLabel.hidden = YES;
        _rightTextField.hidden = YES;
        _headLabel.hidden = NO;
        _headImageView.hidden = NO;
        _line3ImageView.hidden = NO;
        _line4ImageView.hidden = YES;
        _line5ImageView.hidden = YES;
        _totalLabel.hidden = YES;
        _totalnumLabel.hidden = YES;
        _nameLabel.hidden = YES;
        _textLabel.hidden = YES;
        _numLabel.hidden = YES;
        btn1.hidden = YES;
        _tuijiannumLabel.hidden = YES;
        _tuijianLabel.hidden =YES;
        
        _headLabel.text = headLabel;
        _headImageView.image = headImageView;
        
    }else if (showstatus == 2)
    {
        _leftLabel.hidden = YES;
        _rightTextField.hidden = YES;
        _headLabel.hidden = YES;
        _headImageView.hidden = YES;
        _line3ImageView.hidden = NO;
        _line4ImageView.hidden = YES;
        _line5ImageView.hidden = YES;
        _totalLabel.hidden = NO;
        _totalnumLabel.hidden = NO;
        _nameLabel.hidden = YES;
        _textLabel.hidden = YES;
        _numLabel.hidden = YES;
        btn1.hidden = YES;
        _tuijiannumLabel.hidden = NO;
        _tuijianLabel.hidden =NO;
        
        _totalLabel.text = totalLabel;
        _totalnumLabel.text = totalnumLabel;
        _tuijianLabel.text = tuijianLabel;
        _tuijiannumLabel.text = tuijiannumLabel;
    }else if (showstatus == 3)
    {
        _leftLabel.hidden = YES;
        _rightTextField.hidden = YES;
        _headLabel.hidden = YES;
        _headImageView.hidden = YES;
        _line3ImageView.hidden = YES;
        _line4ImageView.hidden = YES;
        _line5ImageView.hidden = YES;
        _totalLabel.hidden = NO;
        _totalnumLabel.hidden = NO;
        _nameLabel.hidden = YES;
        _textLabel.hidden = YES;
        _numLabel.hidden = YES;
        btn1.hidden = YES;
        _tuijiannumLabel.hidden = NO;
        _tuijianLabel.hidden =NO;
        
        _totalLabel.text = totalLabel;
        _totalnumLabel.text = totalnumLabel;
        _tuijianLabel.text = tuijianLabel;
        _tuijiannumLabel.text = tuijiannumLabel;
    }else if (showstatus == 4)
    {
        _leftLabel.hidden = YES;
        _rightTextField.hidden = YES;
        _headLabel.hidden = NO;
        _headImageView.hidden = NO;
        _line3ImageView.hidden = YES;
        _line4ImageView.hidden = YES;
        _line5ImageView.hidden = YES;
        _totalLabel.hidden = YES;
        _totalnumLabel.hidden = YES;
        _nameLabel.hidden = YES;
        _textLabel.hidden = YES;
        _numLabel.hidden = NO;
        btn1.hidden = YES;
        _tuijiannumLabel.hidden = YES;
        _tuijianLabel.hidden =YES;
        
        _headLabel.text = headLabel;
        _headImageView.image = headImageView;
        _numLabel.text = numLabel;
        
    }else
    {
        _leftLabel.hidden = YES;
        _rightTextField.hidden = YES;
        _headLabel.hidden = YES;
        _headImageView.hidden = YES;
        _line3ImageView.hidden = YES;
        _line4ImageView.hidden = YES;
        _line5ImageView.hidden = YES;
        _totalLabel.hidden = YES;
        _totalnumLabel.hidden = YES;
        _nameLabel.hidden = NO;
        _textLabel.hidden = NO;
        _numLabel.hidden = YES;
        btn1.hidden = NO;
        _tuijiannumLabel.hidden = YES;
        _tuijianLabel.hidden =YES;
        
        _nameLabel.text = nameLabel;
        _textLabel.text = textLabel;
    }
}
@end
