//
//  ScheduleModel.m
//  MaYiAiChe
//
//  Created by yuenhe on 17/3/28.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "ScheduleModel.h"

@implementation ScheduleModel

-(id)initWithDic:(NSDictionary *)dic{
    
     if (self = [super init]) {
        
         self.order_number           = dic[@"order_number"];
         self.payment_amount      = dic[@"payment_amount"];
         self.xiche_goods_id         = dic[@"xiche_goods_id"];
         self.consumer_car           = dic[@"consumer_car"];
         self.phone                      = dic[@"phone"];
         self.address                   = dic[@"address"];
         self.fuwu_type               = dic[@"fuwu_type"];
         self.order_title               = dic[@"order_title"];
         self.order_status           = dic[@"order_status"];
         self.yuyue_time             = dic[@"yuyue_time"];
         self.lat                          = dic[@"lat"];
         self.lng                         = dic[@"lng"];
         self.finish_pay_time       = dic[@"finish_pay_time"];
         self.jiedan_time            = dic[@"jiedan_time"];
         self.start_service_time  = dic[@"start_service_time"];
         self.finish_service_time = dic[@"finish_service_time"];
         self.before_service_pic = dic[@"before_service_pic"];
         self.after_service_pic   = dic[@"after_service_pic"];
         self.xg_logo                 = dic[@"xg_logo"];
    }
    
    return self;
    
}


@end
