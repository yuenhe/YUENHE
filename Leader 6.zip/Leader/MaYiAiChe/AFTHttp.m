//
//  AFTHttp.m
//  MaYiAiChe
//
//  Created by xc on 17/1/19.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "AFTHttp.h"

static NSString * const AFAppDotNetAPIBaseURLString = @"http://115.29.172.223/working/index.php/Admin/ApiS/s_notice";
@implementation AFTHttp
+(instancetype)shareHttp
{
    static AFTHttp * manage = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manage = [[AFTHttp alloc]initWithBaseURL:[NSURL URLWithString:AFAppDotNetAPIBaseURLString]];
        manage.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModePublicKey];
        manage.requestSerializer.timeoutInterval = 10.0;
        manage.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/plain",@"text/html",@"application/json", nil];
        NSLog(@"%@",[manage class]);
//        NSString * userId = [[NSString alloc]initWithData:manage encoding:NSUTF8StringEncoding];
//        NSLog(@"%@",userId);
    });
    return manage;
}


@end
