//
//  InshareViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/23.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "InshareViewController.h"
#import "MadeshareTableViewCell.h"
#import "TitleTableViewCell.h"
#import "ShareVideoViewController.h"
#import "MapView.h"
@interface InshareViewController ()<UITableViewDataSource,UITableViewDelegate,MycellDelegate,CellCusDelegate>
{
    UIView *_mynavigationBar;
    UIButton * _backLabel;
    UILabel * _titleLabel;
    UIButton * _jionbtn;
    UITableView * _listTableView;
    UIImageView * headimageview;
    UIView * headView;
    MapView * _mapview;
}
@end

@implementation InshareViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];
    self.tabBarController.
    self.navigationController.navigationBar.hidden = YES;
    //自定义navigationbar
    _mynavigationBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 64)];
    _mynavigationBar.backgroundColor = [UIColor greenColor];
    [self.view addSubview:_mynavigationBar];
    //返回item
    _backLabel = [[UIButton alloc]initWithFrame:CGRectMake(5, 25, 30, 30)];
    _backLabel.backgroundColor = [UIColor clearColor];
    [_backLabel setImage:[UIImage imageNamed:@"backwhite"] forState:UIControlStateNormal];
    [_backLabel addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigationBar addSubview:_backLabel];
    
    //title
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-100, 22, 200, 40)];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text =@"我的入股";
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.font = [UIFont systemFontOfSize:25];
    [_mynavigationBar addSubview:_titleLabel];
    
    _jionbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _jionbtn.backgroundColor = [UIColor redColor];
    [_jionbtn setFrame:CGRectMake(0, self.view.frame.size.height-49, self.view.frame.size.width, 49)];
    [_jionbtn setTitle:@"撤出资金" forState:UIControlStateNormal];
    [_jionbtn addTarget:self action:@selector(btnjionclick) forControlEvents:UIControlEventTouchUpInside]
    ;
    [self.view addSubview:_jionbtn];
    
    [self createTableView];
    [self createHeadView];

    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)createTableView
{
    _listTableView  = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height-64-49)];
    _listTableView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_listTableView];
    _listTableView.delegate = self;
    _listTableView.dataSource = self;
    _listTableView.bounces = NO;
    _listTableView.showsVerticalScrollIndicator = NO;
    
}
-(void)createHeadView
{
    _listTableView.tableHeaderView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 365)];
    _listTableView.tableHeaderView.backgroundColor = [UIColor whiteColor];
    
    UILabel * nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(30, 210, 150, 30)];
    nameLabel.textColor = [UIColor blackColor];
    nameLabel.textAlignment = NSTextAlignmentLeft;
    nameLabel.backgroundColor = [UIColor clearColor];
    nameLabel.text = @"xxxxx门店";
    nameLabel.font = [UIFont systemFontOfSize:18];
    [_listTableView.tableHeaderView addSubview:nameLabel];
    
    UIImageView * adrIamgeView = [[UIImageView alloc]initWithFrame:CGRectMake(30, 245, 30, 30)];
    adrIamgeView.backgroundColor = [UIColor redColor];
    [_listTableView.tableHeaderView addSubview:adrIamgeView];
    
    UILabel * adrLabel = [[UILabel alloc]initWithFrame:CGRectMake(65, 245, 150, 30)];
    adrLabel.textColor = [UIColor blackColor];
    adrLabel.textAlignment = NSTextAlignmentLeft;
    adrLabel.backgroundColor = [UIColor clearColor];
    adrLabel.text = @"xx市xx路2888号";
    adrLabel.font = [UIFont systemFontOfSize:15];
    [_listTableView.tableHeaderView addSubview:adrLabel];
    
    UIImageView * lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(30, 280, [UIScreen mainScreen].bounds.size.width-60, 1)];
    lineImageView.backgroundColor = [UIColor blackColor];
    [_listTableView.tableHeaderView addSubview:lineImageView];
    for (int i = 0; i < 2; i++) {
        NSArray * totalArray = [NSArray arrayWithObjects:@"当前总金额",@"当前参与人数", nil];
        NSArray * titleArray = [NSArray arrayWithObjects:@"当前剩余投资总金额",@"当前剩余参与人数", nil];
        float width = 200;
        UILabel * totalLabel = [[UILabel alloc]initWithFrame:CGRectMake(30+width*i, 290, 85, 20)];
        totalLabel.textColor = [UIColor blackColor];
        totalLabel.textAlignment = NSTextAlignmentLeft;
        totalLabel.backgroundColor = [UIColor clearColor];
        totalLabel.text =[totalArray objectAtIndex:i];
        totalLabel.font = [UIFont systemFontOfSize:12];
        [_listTableView.tableHeaderView addSubview:totalLabel];
        
        UILabel * titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(30+width*i, 315, 120, 20)];
        titleLabel.textColor = [UIColor blackColor];
        titleLabel.textAlignment = NSTextAlignmentLeft;
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.text =[titleArray objectAtIndex:i];
        titleLabel.font = [UIFont systemFontOfSize:12];
        [_listTableView.tableHeaderView addSubview:titleLabel];
        
        UILabel * numLabel = [[UILabel alloc]initWithFrame:CGRectMake(120+width*i, 290, 50, 20)];
        numLabel.textColor = [UIColor blackColor];
        numLabel.textAlignment = NSTextAlignmentLeft;
        numLabel.backgroundColor = [UIColor redColor];
        numLabel.font = [UIFont systemFontOfSize:12];
        [_listTableView.tableHeaderView addSubview:numLabel];
        
        UILabel * lnumLabel = [[UILabel alloc]initWithFrame:CGRectMake(150+width*i, 315, 50, 20)];
        lnumLabel.textColor = [UIColor blackColor];
        lnumLabel.textAlignment = NSTextAlignmentLeft;
        lnumLabel.backgroundColor = [UIColor redColor];
        lnumLabel.font = [UIFont systemFontOfSize:12];
        [_listTableView.tableHeaderView addSubview:lnumLabel];
    }
    headimageview = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 200)];
    headimageview.backgroundColor =[UIColor clearColor];
    [_listTableView.tableHeaderView addSubview:headimageview];
    headimageview.image = [UIImage imageNamed:@"4"];
}

#pragma mark -- 数据源
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (0 == section) {
        return 1;
    }else if (1 == section)
    {
        return 2;
    }else if (2 == section)
    {
        return 3;
    }else
    {
        return 2;
    }
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        static NSString * celluseId = @"cellfirstId";
        TitleTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:celluseId];
        if (!cell) {
            cell =[[TitleTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:celluseId];
            cell.delegate = self;
        }
        return cell;
    }
    static NSString * cellID = @"cellCusId";
    MadeshareTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[MadeshareTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        cell.delegate = self;
    }
    NSString * headLabel;
    UIImage * imageView;
    NSArray * titleArray = [NSArray arrayWithObjects:@"店铺详情",@"店铺360˚街景",@"店铺地址",@"产品展示", nil];
    for (int i =0 ; i<titleArray.count; i++) {
        if (indexPath.section ==1) {
            if (indexPath.row == 0) {
                headLabel = [titleArray objectAtIndex:0];
            }else
            {
                imageView = [UIImage imageNamed:@"1"];
                UIButton * btn =[UIButton buttonWithType:UIButtonTypeCustom];
                btn.center = CGPointMake([UIScreen mainScreen].bounds.size.width/2, 120);
                btn.bounds = CGRectMake(0, 0, 60, 60);
                [btn setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
                [btn addTarget:self action:@selector(btnpushclick) forControlEvents:UIControlEventTouchUpInside];
                btn.backgroundColor = [UIColor redColor];
                [cell.contentView addSubview:btn];

            }
        }else if (indexPath.section == 2)
        {
            if (indexPath.row == 0) {
                headLabel = [titleArray objectAtIndex:1];
                cell.accessoryType =  UITableViewCellAccessoryDisclosureIndicator;
            }else if (indexPath.row == 1)
            {
                headLabel = [titleArray objectAtIndex:2];
            }else
            {
                _mapview = [[MapView alloc]initWithFrame:CGRectMake(0, 0,[UIScreen mainScreen].bounds.size.width, 240)];
                _mapview.backgroundColor = [UIColor redColor];
                [cell.contentView addSubview:_mapview];
            }
        }else
        {
            if (indexPath.row == 0) {
                headLabel = [titleArray objectAtIndex:3];
            }
        }
        
    }
    int showstatus;
    if (indexPath.section == 1)
    {
        if (indexPath.row == 0) {
            showstatus =0;
        }else{
            showstatus = 1;
        }
    }else if (indexPath.section == 2)
    {
        if (indexPath.row == 0) {
            showstatus = 0;
        }else if (indexPath.row ==1)
        {
            showstatus =0;
        }else
        {
            showstatus = 1;
        }
    }else
    {
        if (indexPath.row ==0) {
            showstatus = 0;
        }else
        {
            showstatus = 1;
        }
    }
    [cell reloadViewWithName:headLabel imageView:imageView  showStatus:showstatus];
    return cell;
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 88;
    }else if (indexPath.section == 1)
    {
        if (indexPath.row == 0) {
            return 44;
        }else{
            return 240;
        }
    }else if (indexPath.section == 2)
    {
        if (indexPath.row == 0) {
            return 44;
        }else if (indexPath.row ==1)
        {
            return 44;
        }else
        {
            return 240;
        }
    }else
    {
        if (indexPath.row ==0) {
            return 44;
        }else
        {
            return 240;
        }
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 2;
    }else
    {
        return 15;
    }
}
-(void)btnpushclick
{
    self.hidesBottomBarWhenPushed = NO;
    [self.navigationController pushViewController:[ShareVideoViewController new] animated:YES];
    self.hidesBottomBarWhenPushed = YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
