//
//  AFTHttp.h
//  MaYiAiChe
//
//  Created by xc on 17/1/19.
//  Copyright © 2017年 xc. All rights reserved.
//
#import "AFNetworking/AFNetworking.h"
#import "AFHTTPSessionManager.h"
@interface AFTHttp : AFHTTPSessionManager
+(instancetype)shareHttp;
@end
