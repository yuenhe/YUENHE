//
//  LinksViewController.m
//  MaYiAiChe
//
//  Created by xc on 17/1/3.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "LinksViewController.h"

@interface LinksViewController ()
{
    UIView * _headView;
    UITextView * _mianTextView;
}
#define Width [UIScreen mainScreen].bounds.size.width
#define Height [UIScreen mainScreen].bounds.size.height
@property (assign,nonatomic) BOOL _isChange;
@end

@implementation LinksViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    self.view.backgroundColor = [UIColor lightGrayColor];
    _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Width, kRelativeHeight(80))];
    _headView.backgroundColor = [UIColor greenColor];
    [self.view addSubview:_headView];
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(40), kRelativeWidth(30), kRelativeHeight(30))];
    [btn setImage:[UIImage imageNamed:@"backwhite"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = [UIColor clearColor];
    [_headView addSubview:btn];
    
    UIButton * linkbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [linkbtn setFrame:CGRectMake(kRelativeWidth(60), kRelativeHeight(280), Width-kRelativeWidth(120), kRelativeHeight(40))];
    [linkbtn setTitle:@"一键生成链接" forState:UIControlStateNormal];
    [linkbtn setTintColor:[UIColor whiteColor]];
    [linkbtn addTarget:self action:@selector(btnpush:) forControlEvents:UIControlEventTouchUpInside];
    linkbtn.backgroundColor = [UIColor orangeColor];
    linkbtn.layer.masksToBounds = YES;
    linkbtn.layer.cornerRadius = 5;
    linkbtn.layer.borderColor = [[UIColor orangeColor]CGColor];
    linkbtn.layer.borderWidth = 1;
    [self.view addSubview:linkbtn];
    
    [self createView];
    [self initUI];

    // Do any additional setup after loading the view.
}
-(void)initUI
{
    _mianTextView = [[UITextView alloc]initWithFrame:CGRectMake(kRelativeWidth(5), kRelativeHeight(370), Width-kRelativeWidth(10), kRelativeHeight(110))];
    _mianTextView.backgroundColor = [UIColor whiteColor];
    _mianTextView.layer.borderWidth =1;
    _mianTextView.layer.borderColor = [[UIColor blackColor]CGColor];
    _mianTextView.text = @"链接已经生成，快去分享吧";
    _mianTextView.textColor = [UIColor lightGrayColor];
    [self.view addSubview:_mianTextView];
    _mianTextView.hidden = YES;
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(Width-kRelativeWidth(115), kRelativeHeight(65), kRelativeWidth(100), kRelativeHeight(40))];
    btn.backgroundColor = [UIColor lightGrayColor];
    [btn setTitle:@"推广" forState:UIControlStateNormal];
    [btn setTintColor:[UIColor blackColor]];
    btn.layer.masksToBounds = YES;
    btn.layer.cornerRadius = 5;
    [btn addTarget:self action:@selector(btnpushOut) forControlEvents:UIControlEventTouchUpInside];
    [_mianTextView addSubview:btn];
    
}
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)createView
{
    UIView * mainView = [[UIView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(80), Width, kRelativeHeight(150))];
    mainView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:mainView];
    
    UIImageView * titleImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(30), kRelativeHeight(20), kRelativeWidth(80), kRelativeHeight(95))];
    titleImageView.backgroundColor = [UIColor greenColor];
    [mainView addSubview:titleImageView];
    UILabel * headLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(120), kRelativeHeight(20), kRelativeWidth(200), kRelativeHeight(30))];
    headLabel.textAlignment = NSTextAlignmentCenter;
    headLabel.textColor = [UIColor blackColor];
    headLabel.text = @"XX商品代金券";
    headLabel.font = [UIFont boldSystemFontOfSize:20];
    [mainView addSubview:headLabel];
    
    UILabel * priceLabel = [[UILabel alloc]initWithFrame:CGRectMake(Width-kRelativeWidth(80), kRelativeHeight(85), kRelativeWidth(50), kRelativeHeight(30))];
    priceLabel.textAlignment = NSTextAlignmentCenter;
    priceLabel.textColor = [UIColor blackColor];
    priceLabel.text = @"￥20";
    priceLabel.font = [UIFont boldSystemFontOfSize:18];
    [mainView addSubview:priceLabel];
}
-(void)btnpush:(UIButton *)btn
{
    if (_mianTextView.hidden == NO) {
        _mianTextView.hidden = YES;
    }else
    {
        _mianTextView.hidden = NO;
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
