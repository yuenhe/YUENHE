//
//  EmployeeTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 17/1/17.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EmployeeModel.h"

@protocol MyCellDelegate <NSObject>

-(void)cellDidClickWithIndexPath:(NSIndexPath *)indexpath;

@end
@interface EmployeeTableViewCell : UITableViewCell

@property (weak,nonatomic) id <MyCellDelegate>delegate;

-(void)reloadWithName:(NSString *)textLabel timeLabel:(NSString *)timeLabel headIamgeView:(UIImage *)headIamge;


@end
