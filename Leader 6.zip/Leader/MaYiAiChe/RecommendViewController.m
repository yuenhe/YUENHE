//
//  RecommendViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "RecommendViewController.h"
#import "IdeaViewController.h"
#import "RecommeTableViewCell.h"
@interface RecommendViewController ()<UITableViewDelegate,UITableViewDataSource,cellCustomDelegate>
{
    UIView *_mynavigationBar;
    UIButton * _backLabel;
    UILabel * _titleLabel;
    UIButton * _ideabtn;
    UITableView * _listTableView;
    
}

@end

@implementation RecommendViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor lightGrayColor];
    
    self.navigationController.navigationBar.hidden = YES;
    //自定义navigationbar
    _mynavigationBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, kRelativeHeight(64))];
    _mynavigationBar.backgroundColor = [UIColor greenColor];
    [self.view addSubview:_mynavigationBar];
    //返回item
    _backLabel = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(5), kRelativeHeight(25), kRelativeWidth(30), kRelativeHeight(30))];
    _backLabel.backgroundColor = [UIColor greenColor];
    _backLabel.tag = 100;
    [_backLabel setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [_backLabel addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigationBar addSubview:_backLabel];
    
    //title
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-kRelativeWidth(100), kRelativeHeight(22), kRelativeWidth(200), kRelativeHeight(40))];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text =@"我的优惠券";
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor blackColor];
    _titleLabel.font = [UIFont systemFontOfSize:25];
    [_mynavigationBar addSubview:_titleLabel];
    //意见箱
    _ideabtn = [[UIButton alloc]initWithFrame:CGRectMake(self.view.frame.size.width-kRelativeWidth(40), kRelativeHeight(25), kRelativeWidth(30), kRelativeHeight(30))];
    _ideabtn.backgroundColor = [UIColor greenColor];
    _ideabtn.tag = 101;
    [_ideabtn setImage:[UIImage imageNamed:@"idea"] forState:UIControlStateNormal];
    [_ideabtn addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigationBar addSubview:_ideabtn];
    [self createTableView];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//点击事件
-(void)btnclick:(UIButton *)sender
{
    if (sender.tag == 100) {
        [self.navigationController popViewControllerAnimated:YES];
    }else if (sender.tag ==101)
    {
        [self.navigationController pushViewController:[IdeaViewController new] animated:YES];
    }
}
//创建tableview
-(void)createTableView
{
    _listTableView = [[UITableView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(64), self.view.frame.size.width-kRelativeWidth(40), self.view.frame.size.height-kRelativeHeight(64))];
    _listTableView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_listTableView];
    _listTableView.delegate = self;
    _listTableView.dataSource = self;
    _listTableView.bounces = NO;
    _listTableView.showsVerticalScrollIndicator = NO;
}
#pragma  mark -- 数据源
//分section
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}
//每个sectiony有几行
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //判断在第三段有八行
    if (section == 2) {
        return 8;
    }else if (section == 1)
    {
        return 3;
    }
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cellId = @"cellCusId";
    RecommeTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[RecommeTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
        cell.delegate = self;
        
    }
    NSString * _headLabel;
    UIImage * _headImageView;
    NSString * _totalLabel;
    NSString * _totalnumLabel;
    NSString * _nameLabel;
    NSString * _textLabel;
    NSString * _numLabel;
    NSString * _tuijianLabel;
    NSString * _tuijiannumLabel;
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            _headLabel = @"我的积分";
            _headImageView = [UIImage imageNamed:@""];
        }else if (indexPath.row == 1)
        {
            NSArray * titleArray = [NSArray arrayWithObjects:@"获得总积分:",@"推荐积分:", nil];
            NSArray * numArray = [NSArray arrayWithObjects:@"5000",@"4000", nil];
            for (int i = 0; i<2; i++) {
                _totalLabel = [titleArray objectAtIndex:0];
                _totalnumLabel = [numArray objectAtIndex:0];
                _tuijianLabel = [titleArray objectAtIndex:1];
                _tuijiannumLabel = [numArray objectAtIndex:1];
            }
        }else
        {
            NSArray * titleArray = [NSArray arrayWithObjects:@"已使用积分:",@"剩余积分:", nil];
            NSArray * numArray = [NSArray arrayWithObjects:@"3000",@"2000", nil];
            for (int i = 0; i<2; i++) {
                _totalLabel = [titleArray objectAtIndex:0];
                _totalnumLabel = [numArray objectAtIndex:0];
                _tuijianLabel = [titleArray objectAtIndex:1];
                _tuijiannumLabel = [numArray objectAtIndex:1];
            }
        }
    }else if (indexPath.section == 2)
        {
            if (indexPath.row == 0) {
                _headImageView = [UIImage imageNamed:@""];
                _headLabel = @"我的推荐";
                _numLabel = @"30人";
            }else
            {
                NSArray * nameArray = [NSArray arrayWithObjects:@"元芳",@"八戒",@"妖精",@"快",@"还",@"我",@"爷爷", nil];
                NSArray * textArray = [NSArray arrayWithObjects:@"车牌号：赣b245971",@"车牌号：赣b245971",@"车牌号：赣b245971",@"车牌号：赣b245971",@"车牌号：赣b245971",@"车牌号：赣b245971",@"车牌号：赣b245971", nil];
                if (indexPath.row ==1) {
                    _nameLabel = [nameArray objectAtIndex:0];
                    _textLabel = [textArray objectAtIndex:0];
            
                }else if (indexPath.row == 2)
                {
                    _nameLabel = [nameArray objectAtIndex:1];
                    _textLabel = [textArray objectAtIndex:1];
                }else if (indexPath.row == 3)
                {
                    _nameLabel = [nameArray objectAtIndex:2];
                    _textLabel = [textArray objectAtIndex:2];
                }else if (indexPath.row == 4)
                {
                    _nameLabel = [nameArray objectAtIndex:3];
                    _textLabel = [textArray objectAtIndex:3];
                }else if (indexPath.row == 5)
                {
                    _nameLabel = [nameArray objectAtIndex:4];
                    _textLabel = [textArray objectAtIndex:4];
                }else if (indexPath.row == 6)
                {
                    _nameLabel = [nameArray objectAtIndex:5];
                    _textLabel = [textArray objectAtIndex:5];
                }else
                {
                    _nameLabel = [nameArray objectAtIndex:6];
                    _textLabel = [textArray objectAtIndex:6];
                }
                
            }
            
        }

    int showstatus;
    if (indexPath.section == 0) {
        showstatus =0;
    }else if (indexPath.section == 1)
    {
        if (indexPath.row == 0) {
            showstatus = 1;
        }else if (indexPath.row ==1)
        {
            showstatus = 2;
        }else
        {
            showstatus =3;
        }
    }else if (indexPath.section == 2)
    {
        if (indexPath.row == 0) {
            showstatus = 4;
        }else
        {
            showstatus =5;
        }
    }
    [cell reloadViewWithName:_headLabel headImageview:_headImageView totalLabel:_totalLabel totalnumLabel:_totalnumLabel numLabel:_numLabel nameLabel:_nameLabel textLabel:_textLabel tuijianLabel:_tuijianLabel tuijiannumLabel:_tuijiannumLabel showStatus:showstatus];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 70;
    }
    return 40;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0;
    }
    return 30;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
