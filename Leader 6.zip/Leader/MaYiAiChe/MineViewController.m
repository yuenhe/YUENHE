//
//  MineViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "MineViewController.h"

#import "CouponViewController.h"
#import "MyAssetsContoller.h"
#import "RecommendViewController.h"
#import "SelfViewController.h"
#import "LinkViewController.h"
#import "TreeTableView.h";
#import "Node.h"
@interface MineViewController ()<UITableViewDelegate,UITableViewDataSource>
#define Width [UIScreen mainScreen].bounds.size.width
#define Height [UIScreen mainScreen].bounds.size.height

@end

@implementation MineViewController
{
    UITableView * _listTableView;
    UIView * _headView;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBar.hidden = YES;
    
    mainScrollview = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, Width, Height)];
    mainScrollview.delegate = self;
    mainScrollview.contentSize = CGSizeMake(Width, kRelativeHeight(1100));
    mainScrollview.pagingEnabled = NO;
    mainScrollview.scrollEnabled = YES;
    mainScrollview.bounces = NO;
    mainScrollview.backgroundColor = [UIColor lightGrayColor];
    mainScrollview.showsHorizontalScrollIndicator = YES;
    [self.view addSubview:mainScrollview];
    
    _headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Width, kRelativeHeight(200))];
    _headView.backgroundColor = [UIColor greenColor];
    [mainScrollview addSubview: _headView];
    
    
    UIButton * titleBtn = [[UIButton alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-kRelativeWidth(55), kRelativeHeight(30), kRelativeWidth(110), kRelativeHeight(110))];
    titleBtn.backgroundColor = [UIColor whiteColor];
    [titleBtn setBackgroundImage:[UIImage imageNamed:@"timg.jpeg"] forState:UIControlStateNormal];
    [titleBtn addTarget:self action:@selector(btnselfclick) forControlEvents:UIControlEventTouchUpInside];
    titleBtn.layer.masksToBounds = YES;
    titleBtn.layer.cornerRadius = 55;
    //给头像设置一个圆形边框
    titleBtn.layer.borderWidth = 1.5f;
    titleBtn.layer.borderColor = [UIColor whiteColor].CGColor;
    [_headView addSubview:titleBtn];
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(20), kRelativeWidth(30), kRelativeHeight(30))];
    btn.backgroundColor = [UIColor redColor];
    [btn setImage:[UIImage imageNamed:@""]forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnmenclick) forControlEvents:UIControlEventTouchUpInside];
//    [_headView addSubview:btn];
    
    UILabel * rightLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(55), kRelativeWidth(30), kRelativeHeight(10))];
    rightLabel.backgroundColor = [UIColor clearColor];
    rightLabel.text = @"优惠券";
    rightLabel.adjustsFontSizeToFitWidth = YES;
    rightLabel.textAlignment = NSTextAlignmentCenter;
//    [_headView addSubview:rightLabel];
    
    UILabel * centerLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-kRelativeWidth(100), kRelativeHeight(130), kRelativeWidth(200), kRelativeHeight(10))];
    centerLabel.backgroundColor = [UIColor clearColor];
//    centerLabel.text = @"2016年10月24日加入";
    centerLabel.adjustsFontSizeToFitWidth = YES;
    centerLabel.textAlignment = NSTextAlignmentCenter;
    [_headView addSubview:centerLabel];
    
    UILabel * dwnrgtLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-kRelativeWidth(90), kRelativeHeight(150), kRelativeWidth(80), kRelativeHeight(20))];
    dwnrgtLabel.backgroundColor = [UIColor clearColor];
    dwnrgtLabel.text = @"今日积分：";
    dwnrgtLabel.adjustsFontSizeToFitWidth = YES;
    dwnrgtLabel.textAlignment = NSTextAlignmentCenter;
    [_headView addSubview:dwnrgtLabel];
    
    UILabel * dwnrgtmdLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-kRelativeWidth(40), kRelativeHeight(150), kRelativeWidth(30), kRelativeHeight(20))];
    dwnrgtmdLabel.backgroundColor = [UIColor clearColor];
//    dwnrgtmdLabel.text = @"30";
    dwnrgtmdLabel.adjustsFontSizeToFitWidth = YES;
    dwnrgtmdLabel.textAlignment = NSTextAlignmentCenter;
    [_headView addSubview:dwnrgtmdLabel];
    
    UILabel * dwnleftmdLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2+kRelativeWidth(30), kRelativeHeight(150), kRelativeWidth(120), kRelativeHeight(20))];
    dwnleftmdLabel.backgroundColor = [UIColor clearColor];
    dwnleftmdLabel.text = @"本月总积分：";
    dwnleftmdLabel.adjustsFontSizeToFitWidth = YES;
    dwnleftmdLabel.textAlignment = NSTextAlignmentLeft;
    [_headView addSubview:dwnleftmdLabel];
    
    UILabel * dwnleftLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2+kRelativeWidth(105), kRelativeHeight(150), kRelativeWidth(30), kRelativeHeight(20))];
    dwnleftLabel.backgroundColor = [UIColor clearColor];
//    dwnleftLabel.text = @"800";
    dwnleftLabel.adjustsFontSizeToFitWidth = YES;
    dwnleftLabel.textAlignment = NSTextAlignmentCenter;
    [_headView addSubview:dwnleftLabel];

    [self createFstView];
    [self createSecView];
    [self createTrdView];
    [self createFurView];
    //[self createFivView];
    [self createSixView];
    
    UILabel * scanLabel = [[UILabel alloc]init];
    scanLabel.center =CGPointMake(Width/2, kRelativeHeight(1050));
    scanLabel.bounds = CGRectMake(0, 0, kRelativeWidth(250), kRelativeHeight(50));
    scanLabel.textAlignment = NSTextAlignmentCenter;
    scanLabel.textColor = [UIColor blueColor];
    scanLabel.text = @"获取新用户注册二维码";
    scanLabel.backgroundColor = [UIColor clearColor];
    scanLabel.font = [UIFont systemFontOfSize:20];
    [mainScrollview addSubview:scanLabel];
    


    // Do any additional setup after loading the view.
}

#pragma mark===================// 用户  
-(void)btnselfclick
{
    [self.navigationController pushViewController:[SelfViewController new] animated:YES];
}
-(void)btnmenclick
{
    [self.navigationController pushViewController:[CouponViewController new] animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)createFstView
{
    UIView * fstView =[[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(200), Width-kRelativeWidth(40), kRelativeHeight(80))];
    fstView .backgroundColor = [UIColor whiteColor];
    [mainScrollview addSubview:fstView];
    
    for (int i = 0; i<3; i++) {
        float width = (Width-kRelativeWidth(40))/3;
        NSArray * nameArray = [NSArray arrayWithObjects:@"完成订单总数",@"完成服务总数",@"完成派送总数", nil];
        UILabel * nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(20)+width*i, kRelativeHeight(5), kRelativeWidth(90), kRelativeHeight(20))];
        nameLabel.textAlignment = NSTextAlignmentCenter;
        nameLabel.textColor = [UIColor blackColor];
        nameLabel.text = [nameArray objectAtIndex:i];
        nameLabel.backgroundColor = [UIColor clearColor];
        nameLabel.font = [UIFont systemFontOfSize:14];
        [fstView addSubview:nameLabel];
        
        NSArray * numArray = [NSArray arrayWithObjects:@"61",@"26",@"35", nil];
        UILabel * numLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(40)+width*i, kRelativeHeight(30), kRelativeWidth(50), kRelativeHeight(40))];
        numLabel.textAlignment = NSTextAlignmentCenter;
        numLabel.textColor = [UIColor greenColor];
        numLabel.text = [numArray objectAtIndex:i];
        numLabel.font  = [UIFont systemFontOfSize:25];
        numLabel.backgroundColor = [UIColor clearColor];
        [fstView addSubview:numLabel];
        
    }
    UIImageView * lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake((Width-kRelativeWidth(40))/3, kRelativeHeight(5), kRelativeWidth(1), kRelativeHeight(70))];
    lineImageView.backgroundColor = [UIColor lightGrayColor];
    [fstView addSubview:lineImageView];
    
    UIImageView * line1ImageView = [[UIImageView alloc]initWithFrame:CGRectMake((Width-kRelativeWidth(40))*2/3, kRelativeHeight(5), kRelativeWidth(1), kRelativeHeight(70))];
    line1ImageView.backgroundColor = [UIColor lightGrayColor];
    [fstView addSubview:line1ImageView];
}
-(void)createSecView
{
    UIView * secView = [[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(300), Width-kRelativeWidth(40), kRelativeHeight(60))];
    secView.backgroundColor = [UIColor greenColor];
    [mainScrollview addSubview:secView];
    
    UILabel * textLabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 10, Width/2.5, 40)];
    textLabel.textAlignment = NSTextAlignmentLeft;
    textLabel.textColor = [UIColor whiteColor];
    textLabel.text = @"获取商品推荐券:";
    textLabel.backgroundColor = [UIColor clearColor];
    textLabel.font = [UIFont systemFontOfSize:18];
    [secView addSubview:textLabel];
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(Width/2.5-kRelativeWidth(15), kRelativeHeight(10), Width/2, kRelativeHeight(40))];
    [btn setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    btn.backgroundColor = [UIColor whiteColor];
    btn.layer.masksToBounds = YES;
    btn.layer.cornerRadius = 3;
//    [btn addTarget:self action:@selector(btnpush) forControlEvents:UIControlEventTouchUpInside];
    [secView addSubview:btn];
    
}


-(void)btnpush
{
    self.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:[LinkViewController new] animated:YES];
    self.hidesBottomBarWhenPushed = NO;
}
-(void)createTrdView
{
    UIView * trdView = [[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(380), Width-kRelativeWidth(40), kRelativeHeight(120))];
    trdView.backgroundColor = [UIColor whiteColor];
    [mainScrollview addSubview:trdView];
    
    UIImageView * headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(5), kRelativeWidth(30), kRelativeHeight(30))];
    headImageView.image = [UIImage imageNamed:@"我的积分"];
//    headImageView.backgroundColor = [UIColor redColor];
    [trdView addSubview:headImageView];
    
    UILabel * headLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(45), kRelativeHeight(5), kRelativeWidth(80), kRelativeHeight(30))];
    headLabel.textAlignment = NSTextAlignmentLeft;
    headLabel.textColor = [UIColor orangeColor];
    headLabel.text = @"我的积分";
    headLabel.backgroundColor = [UIColor clearColor];
    headLabel.font = [UIFont systemFontOfSize:18];
    [trdView addSubview:headLabel];
    
    UIImageView * lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(39), Width-kRelativeWidth(40), kRelativeHeight(1))];
    lineImageView.backgroundColor = [UIColor lightGrayColor];
    [trdView addSubview:lineImageView];
    
    UIImageView * linImageView = [[ UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(79), Width-kRelativeWidth(60), kRelativeHeight(1))];
    linImageView.backgroundColor = [UIColor lightGrayColor];
    [trdView addSubview:linImageView];
    
    UIImageView * midLineIamgeView = [[UIImageView alloc]initWithFrame:CGRectMake((Width-kRelativeWidth(40))/2, kRelativeHeight(40), kRelativeWidth(1), kRelativeHeight(40))];
    midLineIamgeView.backgroundColor = [UIColor lightGrayColor];
    [trdView addSubview:midLineIamgeView];
    
    for (int i =0 ; i<2; i++) {
        for (int j = 0; j<2; j++) {
            float width = (Width-kRelativeWidth(40))/2;
            float height = kRelativeHeight(40);
            NSArray * nameArray = [NSArray arrayWithObjects:@"获得的总积分",@"已使用积分", @"推荐积分",@"剩余可用积分",nil] ;
            UILabel * nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(10)+width*i, kRelativeHeight(45)+height*j, kRelativeWidth(90), kRelativeHeight(30))];
            nameLabel.textAlignment = NSTextAlignmentCenter;
            nameLabel.textColor = [UIColor blackColor];
            nameLabel.text = [nameArray objectAtIndex:(i*2+j)];
            nameLabel.font  = [UIFont systemFontOfSize:14];
            nameLabel.backgroundColor = [UIColor clearColor];
            [trdView addSubview:nameLabel];
            
            NSArray * numArray = [NSArray arrayWithObjects:@"0",@"0", @"0",@"0",nil];
            UILabel * numLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(105)+width*i, kRelativeHeight(45)+height*j, kRelativeWidth(60), kRelativeHeight(30))];
            numLabel.textAlignment = NSTextAlignmentCenter;
            numLabel.textColor = [UIColor blackColor];
            numLabel.text = [numArray objectAtIndex:(i*2+j)];
            numLabel.font  = [UIFont systemFontOfSize:15];
            numLabel.backgroundColor = [UIColor clearColor];
            [trdView addSubview:numLabel];
            
            
        }
    }
    
}
-(void)createFurView
{
    for (int i = 0; i< 2; i++) {
        float height = 180;
        NSArray * imageArray = [NSArray arrayWithObjects:@"汽车服务评价",@"商品派送评价", nil];

        UIView * furView = [[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(520)+height*i, Width-kRelativeWidth(40), kRelativeHeight(160))];
        furView.backgroundColor = [UIColor whiteColor];
        [mainScrollview addSubview:furView];
        UIImageView * headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(5), kRelativeWidth(30), kRelativeHeight(30))];
        headImageView.image = [UIImage imageNamed:imageArray[i]];
//        headImageView.backgroundColor = [UIColor redColor];
        [furView addSubview:headImageView];
        
        NSArray * titleArray = [NSArray arrayWithObjects:@"收获汽车服务评价",@"收获商品派送评价",  nil];
        
        UILabel * headLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(45), kRelativeHeight(5), kRelativeWidth(150), kRelativeHeight(30))];
        headLabel.textAlignment = NSTextAlignmentLeft;
        headLabel.textColor = [UIColor orangeColor];
        headLabel.text = [titleArray objectAtIndex:i];
        headLabel.backgroundColor = [UIColor clearColor];
        headLabel.font = [UIFont systemFontOfSize:18];
        [furView addSubview:headLabel];
        
        UILabel * niceLabel = [[UILabel alloc]initWithFrame:CGRectMake(Width-kRelativeWidth(160), kRelativeHeight(5), kRelativeWidth(80), kRelativeHeight(30))];
        niceLabel.textAlignment = NSTextAlignmentLeft;
        niceLabel.textColor = [UIColor blackColor];
        niceLabel.text = @"好评率：";
        niceLabel.backgroundColor = [UIColor clearColor];
        niceLabel.font = [UIFont systemFontOfSize:18];
        [furView addSubview:niceLabel];
        
        UILabel * pstLabel = [[UILabel alloc]initWithFrame:CGRectMake(Width-kRelativeWidth(90), kRelativeHeight(5), kRelativeWidth(60), kRelativeHeight(30))];
        pstLabel.textAlignment = NSTextAlignmentLeft;
        pstLabel.textColor = [UIColor redColor];
        pstLabel.text = @"100%";
        pstLabel.backgroundColor = [UIColor clearColor];
        pstLabel.font = [UIFont systemFontOfSize:18];
        [furView addSubview:pstLabel];
        
        
        UIImageView * lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, kRelativeHeight(39), Width-kRelativeWidth(40), kRelativeHeight(1))];
        lineImageView.backgroundColor = [UIColor lightGrayColor];
        [furView addSubview:lineImageView];
        
        for (int i =0 ; i<2; i++) {
            for (int j = 0; j<3; j++) {
                float width = (Width-kRelativeWidth(40))/2;
                float height = kRelativeHeight(40);
                NSArray * nameArray = [NSArray arrayWithObjects:@"5星好评",@"3星好评",@"1星好评",@"4星好评",@"2星好评",@"0星好评",nil] ;
                UILabel * nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(10)+width*i, kRelativeHeight(45)+height*j, kRelativeWidth(90), kRelativeHeight(30))];
                nameLabel.textAlignment = NSTextAlignmentCenter;
                nameLabel.textColor = [UIColor blackColor];
                nameLabel.text = [nameArray objectAtIndex:(i*2+j)];
                nameLabel.font  = [UIFont systemFontOfSize:15];
                nameLabel.backgroundColor = [UIColor clearColor];
                [furView addSubview:nameLabel];
                
                NSArray * numArray = [NSArray arrayWithObjects:@"16",@"7", @"3",@"0",@"0",@"0",nil];
                NSArray * num1Array = [NSArray arrayWithObjects:@"20", @"30",@"15",@"8",@"0",@"0",nil];
                UILabel * numLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(105)+width*i, kRelativeHeight(45)+height*j, kRelativeWidth(60), kRelativeHeight(30))];
                numLabel.textAlignment = NSTextAlignmentCenter;
                numLabel.textColor = [UIColor blackColor];
                
                numLabel.text = [numArray objectAtIndex:(i*2+j)];
                numLabel.font  = [UIFont systemFontOfSize:15];
                numLabel.backgroundColor = [UIColor clearColor];
                [furView addSubview:numLabel];
                
                
            }
        }

    }
    
    
}
//-(void)createFivView
//{
//    for (int i = 0; i<2; i++) {
//        float height = 45;
//        UIView * fivView = [[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(880)+height*i, Width-kRelativeWidth(40), kRelativeHeight(40))];
//        fivView.backgroundColor = [UIColor whiteColor];
//        [mainScrollview addSubview:fivView];
//        
//        NSArray * nameArray = [NSArray arrayWithObjects:@"我的销售",@"我的推荐", nil];
//        NSArray * timesArray = [NSArray arrayWithObjects:@"50次",@"30人", nil];
////        NSArray * picArray = [NSArray arrayWithObjects:@"下拉",@"back", nil];
//        
//        UILabel * nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(5), kRelativeWidth(80), kRelativeHeight(30))];
//        nameLabel.textAlignment = NSTextAlignmentCenter;
//        nameLabel.textColor = [UIColor blackColor];
//        nameLabel.text = [nameArray objectAtIndex:i];
//        nameLabel.font  = [UIFont systemFontOfSize:15];
//        nameLabel.backgroundColor = [UIColor clearColor];
//        [fivView addSubview:nameLabel];
//        
//        UILabel * numLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(100), kRelativeHeight(5), kRelativeWidth(50), kRelativeHeight(30))];
//        numLabel.textAlignment = NSTextAlignmentCenter;
//        numLabel.textColor = [UIColor blackColor];
//        
//        numLabel.text = [timesArray objectAtIndex:i];
//        numLabel.font  = [UIFont systemFontOfSize:15];
//        numLabel.backgroundColor = [UIColor clearColor];
//        [fivView addSubview:numLabel];
//        
//        UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0, kRelativeHeight(5), Width-kRelativeWidth(40), kRelativeHeight(30))];
////        [btn setImage:[UIImage imageNamed:[picArray objectAtIndex:i]] forState:UIControlStateNormal];
//        [btn addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
//        btn.backgroundColor = [UIColor clearColor];
//        btn.tag = 100+i;
//        [fivView addSubview:btn];
//        
//    }
//}
-(void)createSixView
{
    UIView * sixView = [[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(970), Width-kRelativeWidth(40), kRelativeHeight(40))];
    sixView.backgroundColor = [UIColor whiteColor];
    [mainScrollview addSubview:sixView];
    
    UILabel * nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(10), kRelativeHeight(5), kRelativeWidth(80), kRelativeHeight(30))];
    nameLabel.textAlignment = NSTextAlignmentCenter;
    nameLabel.textColor = [UIColor blackColor];
    nameLabel.text = @"我的资产";
    nameLabel.font  = [UIFont systemFontOfSize:15];
    nameLabel.backgroundColor = [UIColor clearColor];
    [sixView addSubview:nameLabel];
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0, kRelativeHeight(5), Width-kRelativeWidth(40), kRelativeHeight(30))];
    //        [btn setImage:[UIImage imageNamed:[picArray objectAtIndex:i]] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btndidclick) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = [UIColor clearColor];
   
    [sixView addSubview:btn];
}
-(void)btndidclick
{
    [self.navigationController pushViewController:[MyAssetsContoller new] animated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
