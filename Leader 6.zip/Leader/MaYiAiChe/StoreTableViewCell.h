//
//  StoreTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"
@protocol cellCusDelegate <NSObject>

-(void)cellDidClickWithIndexPath:(NSIndexPath *)indexpath;

@end

@interface StoreTableViewCell : UITableViewCell

@property (weak,nonatomic) id <cellCusDelegate>delegate;

-(void)reloadWithName:(NSString *)textLabel timeLabel:(NSString *)timeLabel headIamgeView:(UIImage *)headIamge;



@end
