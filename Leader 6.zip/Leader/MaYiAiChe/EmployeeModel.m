
//
//  EmployeeModel.m
//  MaYiAiChe
//
//  Created by xc on 17/1/17.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "EmployeeModel.h"

@implementation EmployeeModel

@end
