//
//  RealtimeViewController.h
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RealtimeViewController : UIViewController

@property(nonatomic,strong)NSString * status;           // 刷新哪一个页面的数据 状态  2

@end
