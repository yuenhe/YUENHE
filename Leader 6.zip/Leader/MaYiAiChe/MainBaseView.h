//
//  MainBaseView.h
//  MaYiAiChe
//
//  Created by xc on 17/1/9.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MyBasePhotoViewDelegate <NSObject>

-(void)clickDeleBtDelePhotoWithView:(UIView *) view;


@end

@interface MainBaseView : UIView

//图片视图
@property (nonatomic , strong) UIImageView *showImageView;
//删除按钮
@property (nonatomic , strong) UIButton *deleBt;
//图片宽高  按钮宽高
@property (nonatomic) CGFloat imageWidthAndHeight;
@property (nonatomic) CGFloat buttonWidthAndHeight;
//图片间隙
@property (nonatomic) CGFloat imageSpaces;


//代理
@property (nonatomic) id<MyBasePhotoViewDelegate>photoDelegate;


@end
