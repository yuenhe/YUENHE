//
//  ServiceTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 16/12/21.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ServiceModel.h"
@class ServiceTableViewCell;

@protocol cellServicDelegate <NSObject>

-(void)cellServicDidCLick:(ServiceTableViewCell*)cell WithBtn:(UIButton *)btn;

@end

@interface ServiceTableViewCell : UITableViewCell

 @property(nonatomic,strong)   UILabel * headLabel;
  @property(nonatomic,strong)  UILabel * fstLabel;          // 时间
   @property(nonatomic,strong) UILabel * fstrtLabel;
   @property(nonatomic,strong) UILabel * nameLabel;
  @property(nonatomic,strong)  UILabel * telLabel;
 @property(nonatomic,strong)   UILabel * adrLabel;
  @property(nonatomic,strong)  UILabel * rfLabel;
  @property(nonatomic,strong)  UILabel * rscLabel;
  @property(nonatomic,strong)  UILabel * dipLabel;
  @property(nonatomic,strong)  UILabel * timeLabel;
 @property(nonatomic,strong)   UIImageView * headImageView;
  @property(nonatomic,strong)  UIImageView * sexImageView;
   @property(nonatomic,strong) UIButton * selectedBtn;
 @property(nonatomic,strong)   NSIndexPath * indexpath;


@property (weak,nonatomic) id <cellServicDelegate>delegate;

-(void)reloadViewWithName:(NSString *)headLabel FirstLabel:(NSString*)firstLabel nameLabel:(NSString *)nameLabel  telLabel:(NSString *)telLabel adrLabel:(NSString *)adrLabel  headImageView:(UIImage *)headImageView titleImageView:(UIImage *)titleImageView addtime:(NSString *)addtime;

@property(nonatomic,strong)ServiceModel * model;

@end
