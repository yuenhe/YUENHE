// 开发者: NGeLB
// QQ交流群: 572296164
// GitHub 代码地址:https://github.com/NGeLB/LBSegmentControl




#import <UIKit/UIKit.h>

const CGFloat LBSegementViewBottomViewHeight = 4.0;

const CGFloat LBSegementViewTitlePadding = 60;

const CGFloat LBSegementViewTitleSelectMaxScale = 1.1;
