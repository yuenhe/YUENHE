//
//  MainScrollView.h
//  MaYiAiChe
//
//  Created by xc on 17/1/16.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MyScrollViewDelegate <NSObject>


@end
@interface MainScrollView : UIView<UIScrollViewDelegate,UITableViewDataSource,UITableViewDelegate>
{
    UIScrollView *_bigScrollView;
}

@property (weak, nonatomic) id <MyScrollViewDelegate>delegate;
@property (strong,nonatomic)     NSMutableArray * dataArray;    // 洗车数据源

@end
