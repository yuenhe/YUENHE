//
//  ShareTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 16/12/23.
//  Copyright © 2016年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CellCustomDelegate <NSObject>

-(void)cellDidClickWithIndexPath:(NSIndexPath *)indexpath;

@end
@interface ShareTableViewCell : UITableViewCell

@property (weak,nonatomic) id <CellCustomDelegate>delegate;
-(void)reloadViewWithName:(NSString *)headLabel headImageView:(UIImage *)headImageView nameLabel:(NSString *)nameLabel showStatus:(NSInteger)showstatus;
@end
