//
//  TreeTableView.m
//  MaYiAiChe
//
//  Created by xc on 17/2/15.
//  Copyright © 2017年 xc. All rights reserved.
//

#import "TreeTableView.h"
#import "Node.h"

@interface TreeTableView ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong)NSArray * data;//传递过来已经组织好的数据（全量数据）
@property (nonatomic,strong)NSMutableArray * tempData;


@end
@implementation TreeTableView
-(instancetype)initWithFrame:(CGRect)frame withData:(NSArray *)data
{
    self = [super initWithFrame:frame style:UITableViewStyleGrouped];
    if (self) {
        self.dataSource = self;
        self.delegate = self;
        _data = data;
        _tempData = [self createTempData:data];
    }
    return self;
}

/**
 * 初始化数据源
 */
-(NSMutableArray *)createTempData:(NSArray *)data
{
    NSMutableArray * tempArray = [NSMutableArray array];
    for (int i = 0; i<data.count; i++) {
        Node * node = [_data objectAtIndex:i];
        if (node.expand) {
            [tempArray addObject:node];
        }
    }
    return tempArray;
}
#pragma mark-uitableviewdatasource
#pragma mark - required
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _tempData.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cellId = @"cellCusId";
    UITableViewCell * cell =[tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    Node * node = [_tempData objectAtIndex:indexPath.row];
    NSMutableString * name = [NSMutableString string];
    for (int i = 0; i<node.depth; i++) {
        [name appendString:@" "];
        
    }
    [name appendString:node.name];
    cell.textLabel.text = name;
    return cell;
}
#pragma mark - optional
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.01;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01;
}
#pragma  mark - uitableViewDelegate

#pragma mark-optional
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //县修改数据源
    Node * parentNode = [_tempData objectAtIndex:indexPath.row];
    NSUInteger startPossion = indexPath.row+1;
    NSUInteger endPossion = startPossion;
    BOOL expand = NO;
    for (int i = 0; i<_data.count; i++) {
        Node * node = [_data objectAtIndex:i];
        if (node.parenrId == parentNode.nodeId) {
            node.expand = !node.expand;
            if (node.expand) {
                [_tempData insertObject:node atIndex:endPossion];
                expand = YES;
            }else
            {
                expand = NO;
                endPossion = [self removeAllNodesAtParentNode:parentNode];
                break;
            }
            endPossion++;
        }
    }
    //获取需要修正的indexpath
    NSMutableArray * indexPathArray = [NSMutableArray array];
    for (NSUInteger i = startPossion; i<endPossion; i++) {
        NSIndexPath * tempIndexPath = [NSIndexPath indexPathForRow:i inSection:0];
        [indexPathArray addObject:tempIndexPath];
    }
    
    //插入或者删除相关节点
    if (expand) {
        [self insertRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
    }else
    {
        [self deleteRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
        
    }
}
/**
 *  删除该父节点下的所有子节点（包括孙子节点）
 *
 *  @param parentNode 父节点
 *
 *  @return 邻接父节点的位置距离该父节点的长度，也就是该父节点下面所有的子孙节点的数量
 */
-(NSUInteger)removeAllNodesAtParentNode:(Node *)parentNode
{
    NSUInteger startPossion = [_tempData indexOfObject:parentNode];
    NSUInteger endPossion = startPossion;
    for (NSUInteger i = startPossion+1; i<_tempData.count; i++) {
        Node *node = [_tempData objectAtIndex:i];
        endPossion++;
        if (node.depth == parentNode.depth) {
            break;
        }
        node.expand = NO;
    }
    if (endPossion>startPossion) {
        [_tempData removeObjectsInRange:NSMakeRange(startPossion+1, endPossion-startPossion-1)];
    }
    return endPossion;
}
@end
