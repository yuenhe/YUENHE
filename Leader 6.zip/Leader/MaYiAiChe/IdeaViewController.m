//
//  IdeaViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/22.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "IdeaViewController.h"

@interface IdeaViewController ()<UITextViewDelegate>
{
    UIView *_mynavigationBar;
    UIButton * _backLabel;
    UILabel * _titleLabel;
    UITextView * menuTextview;
}
@end

@implementation IdeaViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor lightGrayColor];
    self.navigationController.navigationBar.hidden = YES;
    //自定义navigationbar
    _mynavigationBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, kRelativeHeight(64))];
    _mynavigationBar.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_mynavigationBar];
    //返回item
    _backLabel = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(5), kRelativeHeight(25), kRelativeWidth(30), kRelativeHeight(30))];
    _backLabel.backgroundColor = [UIColor clearColor];
    _backLabel.tag = 100;
    [_backLabel setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [_backLabel addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigationBar addSubview:_backLabel];
    
    //title
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-kRelativeWidth(100), kRelativeHeight(22), kRelativeWidth(200), kRelativeHeight(40))];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text =@"投诉";
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor blackColor];
    _titleLabel.font = [UIFont systemFontOfSize:25];
    [_mynavigationBar addSubview:_titleLabel];
    
    //投诉商家
    UILabel * titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(104), kRelativeWidth(100), kRelativeHeight(30))];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = @"投诉商家";
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.font = [UIFont systemFontOfSize:20];
    [self.view addSubview:titleLabel];
    
    UILabel * nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(130), kRelativeHeight(104), kRelativeWidth(300), kRelativeHeight(30))];
    nameLabel.backgroundColor = [UIColor clearColor];
    nameLabel.text = @"商家A";
    nameLabel.textAlignment = NSTextAlignmentLeft;
    nameLabel.textColor = [UIColor blackColor];
    nameLabel.font = [UIFont systemFontOfSize:20];
    [self.view addSubview:nameLabel];
    
    UIView * fstView = [[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(144), self.view.frame.size.width-kRelativeWidth(40), kRelativeHeight(40))];
    fstView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:fstView];
    
    UILabel * headLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(5), kRelativeHeight(5), kRelativeWidth(80), kRelativeHeight(30))];
    headLabel.backgroundColor = [UIColor clearColor];
    headLabel.text = @"投诉原因";
    headLabel.textAlignment = NSTextAlignmentLeft;
    headLabel.textColor = [UIColor blackColor];
    headLabel.font = [UIFont systemFontOfSize:20];
    [fstView addSubview:headLabel];
    
    UIButton * btn1 = [[UIButton alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-kRelativeWidth(35), kRelativeHeight(5), kRelativeWidth(30), kRelativeHeight(30))];
    btn1.backgroundColor = [UIColor clearColor];
    
    [btn1 setImage:[UIImage imageNamed:@"下拉"]forState:UIControlStateNormal];
    [btn1 addTarget:self action:@selector(btnpushclick:) forControlEvents:UIControlEventTouchUpInside];
    [fstView addSubview:btn1];

    [self createTextView];
    
    UIButton * btn2 = [[UIButton alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(574), self.view.frame.size.width-kRelativeWidth(40)  , kRelativeHeight(50))];
    btn2.backgroundColor = [UIColor greenColor];
    [btn2 setTitle:@"提交" forState:UIControlStateNormal];
    
    
    [btn2 addTarget:self action:@selector(btnupclick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn2];
    // Do any additional setup after loading the view.
}
-(void)createTextView
{
    UIView * textView = [[UIView alloc]initWithFrame:CGRectMake(kRelativeWidth(20), kRelativeHeight(194), self.view.frame.size.width-kRelativeWidth(40), kRelativeHeight(300))];
    textView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:textView];
    
    UILabel * titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(kRelativeWidth(5), kRelativeHeight(10), kRelativeWidth(80), kRelativeHeight(30))];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = @"投诉详情";
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.font = [UIFont systemFontOfSize:20];
    [textView addSubview:titleLabel];
    
    menuTextview = [[UITextView alloc]initWithFrame:CGRectMake(kRelativeWidth(5), kRelativeHeight(40), textView.frame.size.width-kRelativeWidth(10), kRelativeHeight(255))];
    //设置边框样式，只有设置了才会显示边框样式
    menuTextview.layer.borderWidth = 1.0f;
    menuTextview.layer.borderColor = [[UIColor blackColor]CGColor];
    menuTextview.font = [UIFont systemFontOfSize:15];
    menuTextview.textColor = [UIColor blackColor];
    
    //设置代理 用于实现协议
    menuTextview.delegate =self;
    menuTextview.returnKeyType = UIReturnKeyDone;//设置键盘retrun央视
    menuTextview.scrollEnabled = YES;
    menuTextview.autoresizingMask =  UIViewAutoresizingFlexibleWidth ;
    menuTextview.textAlignment = NSTextAlignmentLeft;
    menuTextview.text = @"输入原因";
    
    [textView addSubview:menuTextview];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)btnclick:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:YES];
}
//控制输入文字长度和内容
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if (range.location >=100) {
        return NO;
    }
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }else
    {
        return YES;
    }

}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
