//
//  ShareViewController.m
//  MaYiAiChe
//
//  Created by xc on 16/12/23.
//  Copyright © 2016年 xc. All rights reserved.
//

#import "ShareViewController.h"
#import "ShareoneTableViewCell.h"
@interface ShareViewController ()<UITableViewDataSource,UITableViewDelegate,CellCustomDelegate>
{
    UIView *_mynavigationBar;
    UIButton * _backLabel;
    UILabel * _titleLabel;
    UITableView * _listTableView;
}

@end

@implementation ShareViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];
    self.navigationController.navigationBar.hidden = YES;
    //自定义navigationbar
    _mynavigationBar = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 64)];
    _mynavigationBar.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_mynavigationBar];
    //返回item
    _backLabel = [[UIButton alloc]initWithFrame:CGRectMake(5, 25, 30, 30)];
    _backLabel.backgroundColor = [UIColor clearColor];
    _backLabel.tag = 100;
    [_backLabel setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [_backLabel addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    [_mynavigationBar addSubview:_backLabel];
    
    //title
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-100, 22, 200, 40)];
    _titleLabel.backgroundColor = [UIColor clearColor];
    _titleLabel.text =@"分红详情";
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.textColor = [UIColor blackColor];
    _titleLabel.font = [UIFont systemFontOfSize:25];
    [_mynavigationBar addSubview:_titleLabel];
    [self createTableView];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)btnclick
{
    [self.navigationController popViewControllerAnimated:YES];
}
//创建tableview
-(void)createTableView
{
    _listTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height-64)];
    _listTableView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_listTableView];
    _listTableView.delegate = self;
    _listTableView.dataSource = self;
    _listTableView.bounces = NO;
    _listTableView.showsVerticalScrollIndicator = NO;
}
#pragma mark -- 数据源
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cellId = @"cellCusID";
    ShareoneTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[ShareoneTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    NSString * namelabel;
    NSString * tellabel;
    NSString * investnumlabel;
    NSString * sharelabel;
    UIImage * headimage;
    NSArray * nameArray = [NSArray arrayWithObjects:@"李先生",@"陈先生", @"李先生",@"陈先生",nil];
    for (int i = 0; i<nameArray.count; i++) {
        namelabel = [nameArray objectAtIndex:i];
    }
    NSArray * telArray = [NSArray arrayWithObjects:@"18888888888",@"13234567891",@"18888888888",@"13234567891", nil];
    for (int t = 0 ; t < telArray.count; t++) {
        tellabel = [telArray objectAtIndex:t];
    }
    
    NSArray * imageArray = [NSArray arrayWithObjects:@"5@2x",@"6@2x",@"7@2x",@"1", nil];
    for (int t = 0; t< imageArray.count; t++) {
         headimage = [UIImage imageNamed:[imageArray objectAtIndex:t]];
    }
    NSArray * investArray = [NSArray arrayWithObjects:@"2000",@"3000",@"400",@"50000", nil];
    for (int t = 0; t < investArray.count; t++) {
        investnumlabel = [investArray objectAtIndex:t];
    }
    
    
    NSArray * shareArray = [NSArray arrayWithObjects:@"300",@"200",@"400",@"100", nil];
    for (int i = 0; i< shareArray.count; i++) {
        sharelabel = [shareArray objectAtIndex:i];

    }
    
    
    
   
    [cell  reloadViewWithName:namelabel telLabel:tellabel investnumLabel:investnumlabel shareLabel:sharelabel headImageView:headimage];
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 88;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
