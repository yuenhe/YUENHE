//
//  FinishServiceTableViewCell.h
//  MaYiAiChe
//
//  Created by xc on 17/1/9.
//  Copyright © 2017年 xc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScheduleModel.h"

@protocol MyCellDelegate <NSObject>
-(void)cellDidClickWithIndexPath:(NSIndexPath *)indexpath;
@end

@interface FinishServiceTableViewCell : UITableViewCell
@property (weak,nonatomic) id <MyCellDelegate>delegate;

@property(nonatomic,strong)   UILabel * headLabel;
@property(nonatomic,strong)  UILabel * fstLabel;          // 时间
@property(nonatomic,strong) UILabel * fstrtLabel;
@property(nonatomic,strong) UILabel * nameLabel;
@property(nonatomic,strong)  UILabel * telLabel;
@property(nonatomic,strong)   UILabel * adrLabel;
@property(nonatomic,strong)  UILabel * rfLabel;
@property(nonatomic,strong)  UILabel * rscLabel;
@property(nonatomic,strong)  UILabel * dipLabel;
@property(nonatomic,strong)  UILabel * timeLabel;
@property(nonatomic,strong)   UIImageView * headImageView;
@property(nonatomic,strong)  UIImageView * sexImageView;
@property(nonatomic,strong) UIButton * selectedBtn;
@property(nonatomic,strong)   NSIndexPath * indexpath;


-(void)reloadViewWithName:(NSString *)OrderID srvnameLabel:(NSString *)srvnameLabel textLabel:(NSString *)textLabel nameLabel:(NSString *)nameLabel telLabel:(NSString *)telLabel adrLabel:(NSString *)adrLabel OpinionLabel:(NSString *)opinionLabel headImage:(UIImage *)headImage;

@property(nonatomic,strong)ScheduleModel *  model ;     

@end
