//
//  DataCenter.m
//  NewHouse
//
//  Created by gaoyang on 14-9-9.
//  Copyright (c) 2014年 gaoyang. All rights reserved.
//

#import "DataCenter.h"

#define nicKEY @"nickname"
#define youKEY @"yourname"
#define headKEY @"image"


@interface DataCenter ()
{
//    NSMutableDictionary *_dataDic;
}
@end
@implementation DataCenter

+(id)shareDataCenter{                       //单利
    static DataCenter *data=nil;
    if (data==nil) {
        data=[[DataCenter alloc]init];
        NSString *documentDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)
                                 objectAtIndex:0];
        data.path= [documentDir stringByAppendingPathComponent:@"data.plist"];
        
    }
    return data;
}
//-(void)UIDset:(NSString *)uidstring{            //获取服务器分发的uid
//    [self writeData:uidstring withKey:UID];
//}

//-(NSString *)UIDget{
//
//    return [self getDataWithKey:UID];
//}

//-(id)getDataWithKey:(NSString *)key{                                                
//    _dataDic=[[NSMutableDictionary alloc]initWithContentsOfFile:self.path];
////    NSLog(@"{%@}--path:{%@}---%@",[_dataDic objectForKey:key],self.path,_dataDic);
//    return [_dataDic objectForKey:key];
//}
//-(void)writeData:(id)target withKey:(NSString *)key{
//    _dataDic=[[NSMutableDictionary alloc]initWithContentsOfFile:self.path];
//    if (!_dataDic) {
//        _dataDic=[[NSMutableDictionary alloc]init];
//    }
//    if (key) {
//        [_dataDic setObject:target forKey:key];
//        if ([_dataDic writeToFile:self.path atomically:YES]) {
//            NSLog(@"录入成功");
//        }
//        else NSLog(@"录入失败");
////        NSLog(@"录入data：%@:%@  data:%@",key,target,_dataDic);
//    }
//}
//
//-(id)init
//{
//    
//    
//    
//}

- (void)saveUserInofFromSanbox{
    
//    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
//    [defaults setValue:self.nickName forKey:nicKEY];
////    [defaults setValue:self.yourName forKey:youKEY];
//    [defaults setObject:self.imageData forKey:headKEY];
//    [defaults synchronize];
}

- (void)loadUserInofFromSanbox{
    
//    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
//    self.nickName = [defaults objectForKey:nicKEY];
////    self.yourName = [defaults objectForKey:youKEY];
//    self.imageData = [defaults objectForKey:headKEY];
}





@end
